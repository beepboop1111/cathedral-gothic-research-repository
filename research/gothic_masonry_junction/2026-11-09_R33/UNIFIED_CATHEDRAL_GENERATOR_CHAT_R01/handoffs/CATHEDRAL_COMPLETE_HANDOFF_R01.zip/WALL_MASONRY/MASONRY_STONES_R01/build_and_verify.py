import bpy,pathlib,json,hashlib,subprocess,math,collections
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent
SRC=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/PIERS_WALLS_R01/PIERS_WALLS_R01.blend')
parent_hash=hashlib.sha256(SRC.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(SRC))
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def signature(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
source=[];sides={}
for sign in (-1,1):
 data={'main':[],'base':[]}
 for o in bpy.context.scene.objects:
  if o.type!='MESH' or not o.name.startswith(('WALL_','CORE_','BASE_')):continue
  v=coords(o)
  if (sum(p[1] for p in v)/len(v)>0)!=(sign>0):continue
  ymin=min(p[1] for p in v)
  for f in o.data.polygons:
   pts=[v[i] for i in f.vertices]
   if all(abs(p[1]-ymin)<.001 for p in pts):data['base' if o.name.startswith('BASE_') else 'main'].append([[p[0],p[2]] for p in pts])
  if o not in source:source.append(o)
 sides[str(sign)]=data
retained=[o for o in bpy.context.scene.objects if o.type=='MESH' and o not in source]
before={o.name:signature(o) for o in retained}
(R/'SOURCE_SILHOUETTES.json').write_text(json.dumps(dict(source=str(SRC),sha256=parent_hash,sides=sides)))
subprocess.run(['/usr/bin/python3',str(R/'prepare_stones.py')],check=True)
for o in source:bpy.data.objects.remove(o,do_unlink=True)
def mat(name,c):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*c,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.82;return m
stone=[mat('ASHLAR_TONE_%d'%i,(.45+i*.022,.36+i*.019,.24+i*.016)) for i in range(5)]
mortar=mat('MORTAR',(.16,.14,.11));new=[]
for i,d in enumerate(json.loads((R/'STONE_MESHES.json').read_text())):
 me=bpy.data.meshes.new(d['name']);me.from_pydata(d['vertices'],[],d['faces']);me.update()
 o=bpy.data.objects.new(d['name'],me);bpy.context.scene.collection.objects.link(o);o.data.materials.append(mortar if d['kind']=='mortar' else stone[i%5]);o['construction_role']=d['kind'];new.append(o)
checks={}
checks['retained_ribs_webs_shafts_floor_unchanged']=all(signature(o)==before[o.name] for o in retained)
checks['parent_blend_hash_unchanged']=hashlib.sha256(SRC.read_bytes()).hexdigest()==parent_hash
def closed(o):
 c=collections.Counter()
 for p in o.data.polygons:
  f=list(p.vertices)
  for a,b in zip(f,f[1:]+f[:1]):c[tuple(sorted((a,b)))]+=1
 return all(n==2 for n in c.values())
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(x) for x in coords(o)];origin=v[0]
 return sum((v[t.vertices[0]]-origin).dot((v[t.vertices[1]]-origin).cross(v[t.vertices[2]]-origin))/6 for t in o.data.loop_triangles)
checks['all_new_meshes_closed']=all(closed(o) for o in new)
checks['all_new_meshes_finite']=all(math.isfinite(x) for o in new for v in coords(o) for x in v)
checks['all_new_meshes_positive_volume']=all(volume(o)>0 for o in new)
assert all(checks.values()),checks
bpy.ops.wm.save_as_mainfile(filepath=str(R/'MASONRY_STONES_R01.blend'))
def snapshot(obs):
 return {o.name:dict(bounds=[[min(v[k] for v in coords(o)) for k in range(3)],[max(v[k] for v in coords(o)) for k in range(3)]],triangles=sum(len(p.vertices)-2 for p in o.data.polygons)) for o in obs}
snap=snapshot(retained+new)
bpy.ops.export_scene.gltf(filepath=str(R/'MASONRY_STONES_R01.glb'),export_format='GLB',export_cameras=False,export_lights=False)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(R/'MASONRY_STONES_R01.glb'))
now=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
checks['glb_name_count_roundtrip']=set(snap)==set(now)
err=max(abs(snap[n]['bounds'][j][k]-now[n]['bounds'][j][k]) for n in snap for j in range(2) for k in range(3))
checks['glb_bounds_roundtrip_within_0_01']=err<.01
checks['glb_triangle_counts_roundtrip']=all(snap[n]['triangles']==now[n]['triangles'] for n in snap)
plan=json.loads((R/'PLAN_QA.json').read_text())
qa=dict(revision='MASONRY_STONES_R01_EXPERIMENTAL',source=str(SRC),source_sha256=parent_hash,checks={**plan['checks'],**checks},stone_counts=plan['counts'],glb_roundtrip_max_bounds_error=err,geometry_metrics=plan['metrics'],small_pieces_omitted_to_mortar=len(plan['omitted_small_pieces_to_mortar']),validation=dict(technical='Python/Blender execution and actual GLB reimport tested',geometric='source mass envelopes retained, disjoint stones and mortar, original rib/web/shaft arrays unchanged',architectural='EXPERIMENTAL local bay; course/bond/ring dimensions unapproved; compound profiles remain continuous',historical='not assessed; no claim of a historical bonding pattern',structural='not assessed; F5ZL-C support schedule missing; no capacity or mortar-property checks'))
qa['passed']=sum(qa['checks'].values());qa['total']=len(qa['checks'])
(R/'QA.json').write_text(json.dumps(qa,indent=2))
assert all(qa['checks'].values()),qa
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32
scene.render.resolution_x=1100;scene.render.resolution_y=1050;scene.render.resolution_percentage=100
scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX'
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(25200,-6500,4900));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=6100;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(29800,0,2050))
for loc,power,size in [((28000,-4000,8500),1800000000,5000),((33000,3500,6500),1300000000,4000)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(29800,0,1800))
scene.render.filepath=str(R/'ASSEMBLY.png');bpy.ops.render.render(write_still=True)
cam.location=(29800,-8000,3400);cam.data.ortho_scale=3650;aim(cam,(29800,-1400,2350))
scene.render.filepath=str(R/'STONE_DETAIL.png');bpy.ops.render.render(write_still=True)
print('RESULT',json.dumps(qa))
