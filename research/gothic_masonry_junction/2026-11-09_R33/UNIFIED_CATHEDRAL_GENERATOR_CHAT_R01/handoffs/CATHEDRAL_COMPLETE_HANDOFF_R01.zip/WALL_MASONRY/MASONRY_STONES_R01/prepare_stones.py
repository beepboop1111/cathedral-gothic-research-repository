import json,math,pathlib,collections
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles
from shapely.geometry.polygon import orient
R=pathlib.Path(__file__).resolve().parent
D=json.loads((R/'SOURCE_SILHOUETTES.json').read_text())
cfg=dict(course=200.,block=520.,joint=6.,arch_ring=120.,voussoirs_per_half=10,units='native project units; numerical 1:1; SI unresolved',status='EXPERIMENTAL')
items=[];metrics={};checks={};tiny=[]
def polygons(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for x in g.geoms for p in polygons(x)]
def add(name,g,ylo,yhi,kind):
 for i,p in enumerate(polygons(g)):
  if p.area>1e-5:items.append(dict(name=name+'_'+str(i),poly=p,ylo=ylo,yhi=yhi,kind=kind))
def courses(mask,label,ylo,yhi,course=200):
 stones=[]
 zmin,zmax=mask.bounds[1],mask.bounds[3];xmin,xmax=mask.bounds[0],mask.bounds[2]
 for row,z0 in enumerate(range(int(zmin//course)*course,int(zmax)+1,course)):
  shift=cfg['block']/2 if row%2 else 0
  for col in range(math.floor((xmin-shift)/cfg['block'])-1,math.ceil((xmax-shift)/cfg['block'])+1):
   x0=shift+col*cfg['block']
   stone=mask.intersection(box(x0,z0,x0+cfg['block'],z0+course)).buffer(-cfg['joint']/2,join_style=2)
   for p in polygons(stone):
    if p.area<500:tiny.append(dict(region=label,area=p.area));continue
    add(label+'_C%02d_B%03d'%(row,col),p,ylo,yhi,'ashlar');stones.append(p)
 return stones
for side,source in D['sides'].items():
 sign=int(side);full=unary_union([Polygon(p) for p in source['main']]);base=unary_union([Polygon(p) for p in source['base']])
 wall=full.difference(base)
 ylo,yhi=sorted([sign*1250,sign*1570]);blo,bhi=sorted([sign*1250,sign*1600])
 left,right,mid,spring=28840.,30760.,29800.,1800.
 h=(right-left)/2;rise=1350.;c=(rise*rise-h*h)/(2*h);radius=h+c;ringparts=[]
 for hand in (-1,1):
  cx=left+radius if hand<0 else right-radius
  apex=math.acos(-c/(radius+cfg['arch_ring']))
  for j in range(cfg['voussoirs_per_half']):
   a0=math.pi-(math.pi-apex)*j/cfg['voussoirs_per_half'];a1=math.pi-(math.pi-apex)*(j+1)/cfg['voussoirs_per_half']
   aa=[a0+(a1-a0)*k/12 for k in range(13)]
   def point(r,a):
    x=cx+r*math.cos(a);return (x if hand<0 else 2*cx-x,spring+r*math.sin(a))
   poly=Polygon([point(radius,a) for a in aa]+[point(radius+cfg['arch_ring'],a) for a in reversed(aa)])
   clip=box(left-200,spring,mid,4100) if hand<0 else box(mid,spring,right+200,4100)
   p=poly.intersection(clip).intersection(wall);ringparts.append(p)
   add('VOUSSOIR_S%s_H%s_%02d'%(side,hand,j),p.buffer(-cfg['joint']/2,join_style=2),ylo,yhi,'voussoir')
 ring=unary_union(ringparts)
 courses(wall.difference(ring),'WALL_S'+side,ylo,yhi)
 courses(base,'PLINTH_S'+side,blo,bhi,100)
 for label,mask,stones,a,b in [('MAIN',wall,[i['poly'] for i in items if i['ylo']==ylo and i['yhi']==yhi],ylo,yhi),('PLINTH',base,[i['poly'] for i in items if i['ylo']==blo and i['yhi']==bhi],blo,bhi)]:
  u=unary_union(stones);mortar=mask.difference(u);add('MORTAR_S'+side+'_'+label,mortar,a,b,'mortar')
  overlap=sum(p.area for p in stones)-u.area;outside=u.difference(mask).area;err=u.union(mortar).symmetric_difference(mask).area
  metrics[side+'_'+label]=dict(source_area=mask.area,stone_area=u.area,mortar_area=mortar.area,stone_overlap_area=overlap,outside_source_area=outside,envelope_difference_area=err)
  checks[side+'_'+label+'_no_stone_overlap']=abs(overlap)<.01
  checks[side+'_'+label+'_within_source']=outside<.01
  checks[side+'_'+label+'_envelope_retained']=err<.01
meshes=[]
for item in items:
 p=orient(item['poly'],sign=1);verts=[];index={}
 def vertex(x,z,layer):
  key=(float(x),item['ylo'] if layer==0 else item['yhi'],float(z))
  if key not in index:index[key]=len(verts);verts.append(key)
  return index[key]
 faces=[];ts=list(constrained_delaunay_triangles(p).geoms)
 assert abs(sum(t.area for t in ts)-p.area)<.01
 for tri in ts:
  co=list(orient(tri,sign=1).exterior.coords)[:-1]
  faces.extend([[vertex(x,z,0) for x,z in co],list(reversed([vertex(x,z,1) for x,z in co]))])
 for loop in [p.exterior,*p.interiors]:
  co=list(loop.coords)
  for a,b in zip(co,co[1:]):
   i,j=vertex(*a,0),vertex(*b,0);k,l=vertex(*a,1),vertex(*b,1);faces.append([j,i,k,l])
 count=collections.Counter()
 for f in faces:
  for a,b in zip(f,f[1:]+f[:1]):count[tuple(sorted((a,b)))]+=1
 assert all(n==2 for n in count.values()),item['name']
 meshes.append(dict(name=item['name'],vertices=verts,faces=faces,kind=item['kind']))
checks['all_caps_exactly_triangulated']=True;checks['all_prepared_meshes_closed']=True
(R/'STONE_MESHES.json').write_text(json.dumps(meshes,separators=(',',':')))
report=dict(config=cfg,checks=checks,metrics=metrics,counts=dict(collections.Counter(i['kind'] for i in items)),omitted_small_pieces_to_mortar=tiny)
(R/'PLAN_QA.json').write_text(json.dumps(report,indent=2))
assert all(checks.values()),report
print('PREPARED',len(meshes),report['counts'])
