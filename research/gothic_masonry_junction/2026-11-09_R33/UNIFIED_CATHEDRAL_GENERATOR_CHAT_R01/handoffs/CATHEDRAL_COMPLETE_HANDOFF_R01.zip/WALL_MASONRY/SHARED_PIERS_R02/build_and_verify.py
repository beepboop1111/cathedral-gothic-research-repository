import bpy,json,pathlib,hashlib,math,collections,subprocess
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text())
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert digest(D['parent'])==D['parent_sha256'] and digest(D['bay2_source'])==D['bay2_source_sha256']
bpy.ops.wm.open_mainfile(filepath=str(R/'ASSEMBLED_INPUT.blend'))
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def signature(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
remove=[o for o in bpy.context.scene.objects if o.type=='MESH' and (o.name in ['COMPOUND_PIER_1','COMPOUND_PIER_2'] or 'SHAFT' in o.name)]
assert len(remove)==8
retained=[o for o in bpy.context.scene.objects if o.type=='MESH' and o not in remove]
before={o.name:signature(o) for o in retained};checks={}
expect={**D['parent_mesh_signatures'],**D['imported_mesh_signatures']}
checks['all_retained_meshes_match_their_saved_sources']=all(before[n]==expect[n] for n in before)
# Independent matched web-shell edge comparison across X31000.
edge=[]
for name in ['BAY1_WEB_1','BAY2_WEB_3']:
 edge.append([Vector(p) for p in coords(bpy.data.objects[name]) if abs(p[0]-31000)<.001])
edge_error=max(max(min((p-q).length for q in edge[1]) for p in edge[0]),max(min((p-q).length for q in edge[0]) for p in edge[1]))
checks['two_web_shared_shell_edges_match_within_0_005']=edge_error<.005
checks['single_retained_shared_transverse_arch']=sum(o.name=='CHAPEL_TRANSVERSE_31000' for o in retained)==1
for o in remove:bpy.data.objects.remove(o,do_unlink=True)
m=bpy.data.materials.new('R02_COMPOUND_PIERS');m.diffuse_color=(.66,.51,.32,1);m.use_nodes=True
m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.66,.51,.32,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.8
piers=[]
for p in json.loads((R/'PIER_MESHES.json').read_text()):
 me=bpy.data.meshes.new(p['name']);me.from_pydata(p['vertices'],[],p['faces']);me.update()
 o=bpy.data.objects.new(p['name'],me);bpy.context.scene.collection.objects.link(o);o.data.materials.append(m);o['node_id']=p['key'];piers.append(o)
# A separate display floor extension is not architectural floor geometry.
v=[(x,y,z) for z in (-80,-30) for x,y in [(31400,-1800),(33800,-1800),(33800,1800),(31400,1800)]]
me=bpy.data.meshes.new('DISPLAY_FLOOR_EXTENSION');me.from_pydata(v,[],[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]);me.update()
floor=bpy.data.objects.new('DISPLAY_FLOOR_EXTENSION',me);bpy.context.scene.collection.objects.link(floor);floor.data.materials.append(bpy.data.objects['DISPLAY_FLOOR'].data.materials[0])
def topology(o):
 edges=collections.defaultdict(list)
 for p in o.data.polygons:
  v=list(p.vertices)
  for a,b in zip(v,v[1:]+v[:1]):edges[tuple(sorted((a,b)))].append(a<b)
 return all(len(v)==2 and v[0]!=v[1] for v in edges.values())
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(p) for p in coords(o)];c=v[0]
 return sum((v[t.vertices[0]]-c).dot((v[t.vertices[1]]-c).cross(v[t.vertices[2]]-c))/6 for t in o.data.loop_triangles)
checks['new_piers_closed_consistently_wound']=all(topology(o) for o in piers)
checks['new_piers_positive_volume']=all(volume(o)>0 for o in piers)
checks['vertical_extrusion_no_bends']=all(all(any(abs(a[0]-b[0])<1e-8 and abs(a[1]-b[1])<1e-8 and abs(a[2]-b[2])>1799 for b in coords(o)) for a in coords(o)) for o in piers)
checks['six_total_piers_two_shared_nodes_once_each']=len([o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith(('COMPOUND_PIER_','SHARED_PIER_','END_PIER_'))])==6
checks['retained_geometry_unchanged_after_build']=all(signature(o)==before[o.name] for o in retained)
checks['parent_and_R04_files_unchanged']=digest(D['parent'])==D['parent_sha256'] and digest(D['bay2_source'])==D['bay2_source_sha256']
tops={}
for o in piers:
 o.data.calc_loop_triangles();v=coords(o);tops[o['node_id']]=[[v[i][:2] for i in t.vertices] for t in o.data.loop_triangles if all(abs(v[i][2]-1800)<.001 for i in t.vertices)]
(R/'BLENDER_TOP_CAPS.json').write_text(json.dumps(tops));subprocess.run(['/usr/bin/python3',str(R/'verify_contacts.py')],check=True)
contacts=json.loads((R/'CONTACT_QA.json').read_text());section=json.loads((R/'SECTION_QA.json').read_text())
checks.update(contacts['checks']);checks.update(section['checks']);assert all(checks.values()),checks
bpy.ops.wm.save_as_mainfile(filepath=str(R/'SHARED_PIERS_R02.blend'))
def snapshot(obs):
 out={}
 for o in obs:
  v=coords(o);o.data.calc_loop_triangles();tri=[]
  for t in o.data.loop_triangles:
   pts=[tuple(round(v[i][k],3) for k in range(3)) for i in t.vertices]
   tri.append(min(tuple(pts[j:]+pts[:j]) for j in range(3)))
  out[o.name]=dict(bounds=[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]],triangles=sorted(tri))
 return out
snap=snapshot(retained+piers+[floor])
bpy.ops.export_scene.gltf(filepath=str(R/'SHARED_PIERS_R02.glb'),export_format='GLB',export_cameras=False,export_lights=False)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(R/'SHARED_PIERS_R02.glb'))
now=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
checks['GLB_object_names_and_count']=set(snap)==set(now)
err=max(abs(snap[n]['bounds'][j][k]-now[n]['bounds'][j][k]) for n in snap for j in range(2) for k in range(3))
checks['GLB_bounds_within_0_01']=err<.01
checks['GLB_oriented_triangle_signatures_at_0_001']=all(snap[n]['triangles']==now[n]['triangles'] for n in snap)
qa=dict(revision='SHARED_PIERS_R02_EXPERIMENTAL',parent=D['parent'],parent_sha256=D['parent_sha256'],bay2_source=D['bay2_source'],bay2_source_sha256=D['bay2_source_sha256'],checks=checks,passed=sum(checks.values()),total=len(checks),retained_mesh_count=len(retained),total_piers=6,shared_piers=2,bearings_per_shared_pier=5,source_contact_sections=16,clear_rectangles=section['clear_rectangles'],web_shared_edge_error=edge_error,glb_bounds_error=err,contact_metrics=contacts['metrics'],validation=dict(technical='scripts, mesh topology/volume, actual GLB reimport and oriented triangle signatures',geometric='actual spring section containment, shared shell-edge fit, straight extrusion, original masonry/vault mesh preservation, conservative clear rectangles',architectural='experimental two-bay chapel fixture; bay1 wall 320, source bay2 wall170 retained; original backing cores intentionally overlap new core; no transition redesign or tas-de-charge above spring',historical='not assessed; experimental profiles/bond retained',structural='not assessed; source support areas/capacity unverified; missing F5ZL-C schedule unresolved'))
(R/'QA.json').write_text(json.dumps(qa,indent=2));assert all(checks.values()),qa
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX'
scene.render.resolution_x=1400;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(26200,-8200,5800));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=8200;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(31000,0,2200))
for loc,power,size in [((28000,-4000,8500),2200000000,5000),((34000,3500,6500),1700000000,4000)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(31000,0,1800))
scene.render.filepath=str(R/'ASSEMBLY.png');bpy.ops.render.render(write_still=True)
for o in scene.objects:
 if o.type=='MESH':o.hide_render=o.name!='SHARED_PIER_S'
cam.location=(31800,250,2900);cam.data.ortho_scale=2300;aim(cam,(31000,-1250,900));scene.render.resolution_x=1000;scene.render.resolution_y=1000
scene.render.filepath=str(R/'SHARED_PIER_DETAIL.png');bpy.ops.render.render(write_still=True)
print('RESULT',json.dumps(qa))
