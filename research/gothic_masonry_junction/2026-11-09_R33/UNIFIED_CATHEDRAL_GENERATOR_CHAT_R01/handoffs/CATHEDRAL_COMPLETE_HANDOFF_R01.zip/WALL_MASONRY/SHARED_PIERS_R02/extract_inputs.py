import bpy,pathlib,json,hashlib,math
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent
P=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/COMPOUND_PIERS_R01/COMPOUND_PIERS_R01.blend')
S=pathlib.Path('/home/christopher/Downloads/F5ZP_Axial_Chapel_R04_EXPERIMENTAL/Axial_Chapel_R04_EXPERIMENTAL.blend')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(P));parent={o.name:sig(o) for o in bpy.context.scene.objects if o.type=='MESH'}
with bpy.data.libraries.load(str(S),link=False) as (src,dst):
 names=[n for n in src.objects if n.startswith(('BAY2_','CHAPEL_TRANSVERSE_33400','SIDE_-1_BAY2','SIDE_1_BAY2')) or n.startswith('CHAPEL_CORE_') and '33400' in n]
 dst.objects=names
for o in dst.objects:
 if o:bpy.context.scene.collection.objects.link(o)
bpy.context.view_layer.update()
imported={o.name:sig(o) for o in dst.objects if o}
# Walls/core backing remain source geometry; linked profiles are independently sectioned.
nodes={'S':(31000.,-1250.),'N':(31000.,1250.),'ES':(33400.,-1250.),'EN':(33400.,1250.)}
sections={k:dict(node=list(v),sections=[]) for k,v in nodes.items()}
names=['BAY1_RIB_1','BAY1_RIB_2']+['BAY2_RIB_'+str(i) for i in range(4)]+['BAY1_FORMERET_0','BAY1_FORMERET_2','BAY2_FORMERET_0','BAY2_FORMERET_2','CHAPEL_TRANSVERSE_31000','CHAPEL_TRANSVERSE_33400']
for name in names:
 o=bpy.data.objects[name];vs=coords(o);near={k:[] for k in nodes}
 for index,p in enumerate(vs):
  if abs(p[2]-1800)<.002:
   k=min(nodes,key=lambda k:math.dist(p[:2],nodes[k]))
   if math.dist(p[:2],nodes[k])<300:near[k].append(list(p[:2]))
 for k,arr in near.items():
  if len(arr)<3:continue
  x,y=nodes[k]
  if 'RIB' in name:target=(29800. if 'BAY1' in name else 32200.,0.)
  elif 'FORMERET' in name:target=(28600. if 'BAY1' in name else (33400. if x==31000 else 31000.),y)
  else:target=(x,-y)
  h=Vector((target[0]-x,target[1]-y));h.normalize()
  sections[k]['sections'].append(dict(name=name,polygon=arr,direction=list(h),bearing_degrees=math.degrees(math.atan2(h.y,h.x))))
# Derive floor-plan backing reservations from actual source masonry projections.
reservations=[]
for o in bpy.context.scene.objects:
 if o.type=='MESH' and o.name not in ['COMPOUND_PIER_0','COMPOUND_PIER_1','COMPOUND_PIER_2','COMPOUND_PIER_3'] and o.name.startswith(('WALL_','PLINTH_','MORTAR_','SIDE_','CHAPEL_CORE_')):
  reservations.append([list(v[:2]) for v in coords(o)])
data=dict(parent=str(P),parent_sha256=digest(P),bay2_source=str(S),bay2_source_sha256=digest(S),parent_mesh_signatures=parent,imported_mesh_signatures=imported,nodes=sections,reservation_pointclouds=reservations)
(R/'INPUTS.json').write_text(json.dumps(data))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'ASSEMBLED_INPUT.blend'))
print(json.dumps(dict(imported=list(imported),sections={k:[dict(name=s['name'],bearing=s['bearing_degrees'],count=len(s['polygon'])) for s in v['sections']] for k,v in sections.items()})))
