import pathlib,json
from shapely.geometry import Polygon
from shapely.ops import unary_union
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());tops=json.loads((R/'BLENDER_TOP_CAPS.json').read_text())
checks={};metrics={}
for key,node in D['nodes'].items():
 cap=unary_union([Polygon(t) for t in tops[key]]);metrics[key]=[]
 for s in node['sections']:
  p=Polygon(s['polygon']);gap=max(cap.distance(p.exterior.interpolate(p.exterior.length*j/300)) for j in range(301))
  checks[key+'_'+s['name']+'_contact_gap_within_0_005']=gap<=.005
  metrics[key].append(dict(source=s['name'],bearing=s['bearing_degrees'],max_boundary_gap=gap,unreceived_area=p.difference(cap).area))
(R/'CONTACT_QA.json').write_text(json.dumps(dict(checks=checks,metrics=metrics),indent=2))
assert all(checks.values()),metrics
