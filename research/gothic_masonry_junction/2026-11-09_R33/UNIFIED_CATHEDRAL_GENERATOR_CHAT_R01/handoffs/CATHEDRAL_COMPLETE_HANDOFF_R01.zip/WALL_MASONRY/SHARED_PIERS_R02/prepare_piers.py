import json,pathlib,collections
from shapely.geometry import Polygon,MultiPoint,box
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text())
reserve=unary_union([MultiPoint(p).convex_hull for p in D['reservation_pointclouds']])
out=[];checks={};metrics={};sections={}
for key,node in D['nodes'].items():
 x,y=node['node'];sign=1 if y>0 else -1;polys=[];back=[]
 for s in node['sections']:
  p=Polygon(s['polygon']);assert p.is_valid;polys.append(p);h=s['direction'];depth=[(a-x)*h[0]+(b-y)*h[1] for a,b in s['polygon']]
  back += [p for p,d in zip(s['polygon'],depth) if d<=min(depth)+.003]
 half=max(abs(a-x) for a,b in back)
 core=MultiPoint(back+[[x-half*.75,y+sign*320],[x+half*.75,y+sign*320]]).convex_hull
 core=core.intersection(reserve).intersection(box(x-220,min(y,y+sign*320),x+220,max(y,y+sign*320)))
 full=unary_union([*polys,core]);assert full.geom_type=='Polygon' and full.is_valid
 sections[key]=full
 checks[key+'_expected_bearing_count']=len(polys)==(5 if key in ('S','N') else 3)
 checks[key+'_profile_containment']=all(p.difference(full).area<.001 for p in polys)
 checks[key+'_connected_pier_section']=full.geom_type=='Polygon'
 checks[key+'_core_within_recovered_backing_reservation']=core.difference(reserve).area<.001
 checks[key+'_core_outside_protected_vault_plan']=core.intersection(box(28600,-1250,33400,1250)).area<.001
 p=orient(full,sign=1);verts=[];indices={};faces=[]
 def vertex(a,b,k):
  t=(float(a),float(b),1800. if k else 0.)
  if t not in indices:indices[t]=len(verts);verts.append(t)
  return indices[t]
 triangles=list(constrained_delaunay_triangles(p).geoms)
 assert abs(sum(t.area for t in triangles)-p.area)<.001
 for t in triangles:
  c=list(orient(t,sign=1).exterior.coords)[:-1];faces.extend([list(reversed([vertex(a,b,0) for a,b in c])),[vertex(a,b,1) for a,b in c]])
 for loop in [p.exterior,*p.interiors]:
  c=list(loop.coords)
  for a,b in zip(c,c[1:]):faces.append([vertex(*a,0),vertex(*b,0),vertex(*b,1),vertex(*a,1)])
 name=('SHARED_PIER_' if key in ('S','N') else 'END_PIER_')+key
 out.append(dict(name=name,key=key,node=[x,y],vertices=verts,faces=faces,section=list(p.exterior.coords),core=list(core.exterior.coords),bearings=[s['bearing_degrees'] for s in node['sections']]))
 metrics[key]=dict(section_area=p.area,core_area=core.area,bounds=list(p.bounds),bearings=[s['bearing_degrees'] for s in node['sections']])
old=json.loads(pathlib.Path('/home/christopher/Documents/Cathedral/experimental/COMPOUND_PIERS_R01/PIER_MESHES.json').read_text())
westS=Polygon(old[0]['section']);westN=Polygon(old[3]['section'])
def clear(a,b,c,d):
 return [min(b.bounds[0],c.bounds[0])-max(a.bounds[2],d.bounds[2]),min(c.bounds[1],d.bounds[1])-max(a.bounds[3],b.bounds[3])]
gaps=dict(bay1=clear(westS,sections['S'],sections['N'],westN),bay2=clear(sections['S'],sections['ES'],sections['EN'],sections['N']))
checks['positive_conservative_clear_rectangles']=all(v>0 for a in gaps.values() for v in a)
checks['new_piers_pairwise_disjoint']=all(sections[a].intersection(sections[b]).area<.001 for i,a in enumerate(sections) for b in list(sections)[i+1:])
(R/'PIER_MESHES.json').write_text(json.dumps(out))
(R/'SECTION_QA.json').write_text(json.dumps(dict(checks=checks,metrics=metrics,clear_rectangles=gaps),indent=2))
assert all(checks.values())
print('SECTIONS',gaps)
