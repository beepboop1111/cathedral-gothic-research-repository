import subprocess
from pathlib import Path
p=Path('/home/christopher/Documents/Cathedral/experimental')
r=p/'SHARED_PIERS_R02'
commands=[['blender','-b','-t','4','--python',str(p/'SHARED_PIERS_R02_extract.py')],['python3',str(r/'prepare_piers.py')],['blender','-b','-t','4','--python',str(r/'build_and_verify.py')]]
for i,cmd in enumerate(commands):
 with (r/('STAGE_'+str(i)+'.log')).open('w') as out:
  subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=True)
print('PIPELINE_FINISHED')
