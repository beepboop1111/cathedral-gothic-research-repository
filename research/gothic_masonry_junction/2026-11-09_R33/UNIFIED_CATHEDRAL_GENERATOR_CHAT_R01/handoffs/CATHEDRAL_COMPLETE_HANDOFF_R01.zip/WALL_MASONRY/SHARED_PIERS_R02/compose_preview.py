from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
p=Path('/home/christopher/Documents/Cathedral/experimental/SHARED_PIERS_R02');q=json.loads((p/'QA.json').read_text());D=json.loads((p/'INPUTS.json').read_text());m=json.loads((p/'PIER_MESHES.json').read_text())[0];x,y=m['node']
fig,ax=plt.subplots(figsize=(6.2,3.1),dpi=150);fig.patch.set_facecolor('#eeeae2');ax.set_facecolor('#eeeae2')
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="-180 -190 360 550">','<g fill="none" stroke="#999" stroke-width="0.8" stroke-dasharray="4 4"><path d="M -180 0 L 180 0 M 0 -190 L 0 360"/></g>']
def path(poly):return 'M '+' L '.join(str(a-x)+','+str(-(b-y)) for a,b in poly)+' Z'
a,b=zip(*m['core']);ax.fill([v-x for v in a],[v-y for v in b],color='#d8c7ac',alpha=.5);ax.plot([v-x for v in a],[v-y for v in b],color='#b33',linewidth=1,linestyle='--')
svg.append('<path d="'+path(m['core'])+'" fill="#d8c7ac" fill-opacity=".5" stroke="#b33" stroke-width="1" stroke-dasharray="4 3"/>')
for s in D['nodes']['S']['sections']:
 a,b=zip(*(s['polygon']+[s['polygon'][0]]));ax.plot([v-x for v in a],[v-y for v in b],color='black',linewidth=1)
 svg.append('<path d="'+path(s['polygon'])+'" fill="none" stroke="black" stroke-width="1"/>')
svg.append('</svg>');(p/'SHARED_S_SECTION_NATIVE.svg').write_text(''.join(svg))
ax.axhline(0,color='#999',linewidth=.6,linestyle='--');ax.axvline(0,color='#999',linewidth=.6,linestyle='--');ax.set_aspect('equal');ax.set_xlim(-180,180);ax.set_ylim(-350,175);ax.tick_params(labelsize=7)
ax.set_xlabel('Local X / native units',fontsize=8);ax.set_ylabel('Local Y',fontsize=8);ax.set_title('SHARED SECTION / 5 source profiles; dashed red: trial core',fontsize=9)
fig.tight_layout();fig.savefig(p/'SECTION.png',facecolor=fig.get_facecolor());plt.close(fig)
im=Image.new('RGB',(1800,1100),'#eeeae2');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font=ImageFont.truetype(f,25);small=ImageFont.truetype(f,17)
d.text((26,16),'TWO CONNECTED BAYS / SHARED COMPOUND PIERS R02 EXPERIMENTAL',fill='#28251f',font=font)
d.text((26,53),'2 shared piers | 5 actual bearings each | one shared arch | original vaults and masonry retained',fill='#49443b',font=small)
a=Image.open(p/'ASSEMBLY.png').convert('RGB');a.thumbnail((1150,930));im.paste(a,(10,100))
a=Image.open(p/'SHARED_PIER_DETAIL.png').convert('RGB');a.thumbnail((600,600));im.paste(a,(1185,85))
a=Image.open(p/'SECTION.png').convert('RGB');a.thumbnail((620,310));im.paste(a,(1170,725))
d.text((26,1040),'EXISTING WALLS RETAINED - bay 1: 320 units / bay 2: 170 units; architectural transition unresolved',fill='#28251f',font=small)
d.text((1180,698),'ISOLATED SHARED PIER - five engaged responds',fill='#28251f',font=small)
d.text((26,1070),str(q['passed'])+'/'+str(q['total'])+' technical/geometric checks | architectural review pending | historical and structural validation not performed',fill='#49443b',font=small)
im.save(p/'SHARED_PIERS_R02_RESULT.png')
print(json.dumps(dict(passed=q['passed'],total=q['total'],edge_error=q['web_shared_edge_error'],retained=q['retained_mesh_count'],max_cap_gap=max(z['max_boundary_gap'] for v in q['contact_metrics'].values() for z in v))))
