import bpy,json,pathlib,hashlib,math,collections,subprocess
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());P=json.loads((R/'PLAN.json').read_text())
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert digest(D['source'])==D['source_sha256'];bpy.ops.wm.open_mainfile(filepath=D['source']);bpy.context.view_layer.update()
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
def triangles(o):
 o.data.calc_loop_triangles();v=coords(o);return [[list(v[i]) for i in t.vertices] for t in o.data.loop_triangles]
protected={n:bpy.data.objects[n] for n in D['protected_signatures']};checks={}
checks['protected_vaults_windows_and_shared_piers_match_R02']=all(sig(o)==D['protected_signatures'][n] for n,o in protected.items())
cutters=[]
for s in [-1,1]:
 bpy.ops.mesh.primitive_cube_add(size=1,location=((D['x0']+D['x1'])/2,s*1425,2050));o=bpy.context.object;o.name='TEMP_STUDY_CUT';o.dimensions=(D['x1']-D['x0'],350,4100)
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);cutters.append(o)
removed=[]
for name in D['affected']:
 o=bpy.data.objects[name];ys=[v[1] for v in coords(o)];cut=cutters[1] if sum(ys)>0 else cutters[0]
 mod=o.modifiers.new('LOCAL_BACKING_REPLACEMENT','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cut
 bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 if not o.data.polygons:removed.append(name);bpy.data.objects.remove(o,do_unlink=True)
for o in cutters:bpy.data.objects.remove(o,do_unlink=True)
mat=bpy.data.materials.new('R03_RECEIVING_MASONRY');mat.diffuse_color=(.61,.44,.25,1);mat.use_nodes=True
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.61,.44,.25,1);mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.85
new=[]
for m in json.loads((R/'RECEIVING_MESHES.json').read_text()):
 me=bpy.data.meshes.new(m['name']);me.from_pydata(m['vertices'],[],m['faces']);me.update();o=bpy.data.objects.new(m['name'],me);bpy.context.scene.collection.objects.link(o);o.data.materials.append(mat);new.append(o)
checks['protected_geometry_unchanged_after_local_replacement']=all(sig(o)==D['protected_signatures'][n] for n,o in protected.items())
def topology(o):
 edges=collections.defaultdict(list)
 for p in o.data.polygons:
  v=list(p.vertices)
  for a,b in zip(v,v[1:]+v[:1]):edges[tuple(sorted((a,b)))].append(a<b)
 return all(len(v)==2 and v[0]!=v[1] for v in edges.values())
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(p) for p in coords(o)];c=v[0]
 return sum((v[t.vertices[0]]-c).dot((v[t.vertices[1]]-c).cross(v[t.vertices[2]]-c))/6 for t in o.data.loop_triangles)
remaining=[bpy.data.objects[n] for n in D['affected'] if n in bpy.data.objects];affected=remaining+new
checks['cut_backing_and_new_receivers_closed_consistently_wound']=all(topology(o) for o in affected)
checks['cut_backing_and_new_receivers_positive_volume']=all(volume(o)>0 for o in affected)
checks['new_receivers_finite']=all(math.isfinite(v) for o in affected for p in coords(o) for v in p)
actual=dict(backing={o.name:triangles(o) for o in affected},piers={n:triangles(bpy.data.objects[n]) for n in ['SHARED_PIER_S','SHARED_PIER_N']})
(R/'ACTUAL_MESHES.json').write_text(json.dumps(actual))
subprocess.run(['/usr/bin/python3',str(R/'verify_sections.py')],check=True)
reg=json.loads((R/'SECTION_REGRESSION.json').read_text());checks.update(reg['checks']);checks.update(P['checks'])
checks['R02_source_file_hash_unchanged']=digest(D['source'])==D['source_sha256']
assert all(checks.values()),checks
bpy.ops.wm.save_as_mainfile(filepath=str(R/'WALL_PIER_JUNCTION_R03.blend'))
def snapshot(obs):
 out={}
 for o in obs:
  v=coords(o);o.data.calc_loop_triangles();tri=[]
  for t in o.data.loop_triangles:
   pts=[tuple(round(v[i][k],3) for k in range(3)) for i in t.vertices];tri.append(min(tuple(pts[j:]+pts[:j]) for j in range(3)))
  out[o.name]=dict(bounds=[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]],triangles=sorted(tri))
 return out
snap=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
bpy.ops.export_scene.gltf(filepath=str(R/'WALL_PIER_JUNCTION_R03.glb'),export_format='GLB',export_cameras=False,export_lights=False)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(R/'WALL_PIER_JUNCTION_R03.glb'))
now=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
checks['GLB_object_names_and_count']=set(snap)==set(now)
err=max(abs(snap[n]['bounds'][j][k]-now[n]['bounds'][j][k]) for n in snap for j in range(2) for k in range(3))
checks['GLB_world_bounds_within_0_01']=err<.01
checks['GLB_oriented_triangle_signatures_at_0_001']=all(snap[n]['triangles']==now[n]['triangles'] for n in snap)
qa=dict(revision='WALL_PIER_JUNCTION_R03_EXPERIMENTAL',source=D['source'],source_sha256=D['source_sha256'],checks=checks,passed=sum(checks.values()),total=len(checks),config=P['config'],protected_mesh_count=len(protected),source_backing_meshes_affected=len(D['affected']),fully_replaced_meshes=removed,new_receiving_solids=len(new),glb_bounds_error=err,section_metrics=reg['metrics'],validation=dict(technical='scripts, boolean output mesh topology/volume, GLB actual reimport and oriented triangles',geometric='eight horizontal section regressions, outside-study retention, local envelope/overlap checks; shared pier/vault meshes unchanged',architectural='experimental128-unit plan taper in source240-unit window jamb; local stone pattern replaced by receiving envelopes; no design approval',historical='not assessed; numerical taper not sourced from historical construction',structural='not assessed; capacity, bonding, above-spring arch engagement unresolved; F5ZL-C schedule missing'))
(R/'QA.json').write_text(json.dumps(qa,indent=2));assert all(checks.values()),qa
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX'
scene.render.resolution_x=1400;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(26200,-8200,5800));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=8200;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(31000,0,2200))
for loc,power,size in [((28000,-4000,8500),2200000000,5000),((34000,3500,6500),1700000000,4000)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(31000,0,1800))
scene.render.filepath=str(R/'ASSEMBLY.png');bpy.ops.render.render(write_still=True)
for o in scene.objects:
 if o.type=='MESH':o.hide_render=not (o.name.startswith('RECEIVING_S_') or o.name=='SHARED_PIER_S')
cam.location=(32000,-2750,2500);cam.data.ortho_scale=4700;aim(cam,(31000,-1400,2050));scene.render.resolution_x=1000;scene.render.resolution_y=1000
scene.render.filepath=str(R/'JUNCTION_DETAIL.png');bpy.ops.render.render(write_still=True)
print('RESULT',json.dumps(qa))
