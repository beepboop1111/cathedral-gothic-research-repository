from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
import json
# Reuse section extraction functions without rerunning their QA entry point.
p=Path(__file__).resolve().parent
namespace={'__file__':str(p/'verify_sections.py')}
exec((p/'verify_sections.py').read_text().split('checks={};metrics={}')[0],namespace)
section=namespace['section'];D=namespace['D'];A=namespace['A'];P=namespace['P'];unary_union=namespace['unary_union']
q=json.loads((p/'QA.json').read_text())
old=unary_union([section(t,925) for t in D['original_triangles'].values()])
new=unary_union([section(t,925) for t in A['backing'].values()])
pier=unary_union([section(t,925) for t in A['piers'].values()])
clip=namespace['box'](D['x0'],-1600,D['x1'],-1050)
old=old.intersection(clip);new=new.intersection(clip);pier=pier.intersection(clip)
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
def plot(ax,g,fc,ec,ls='-'):
 for a in parts(g):
  xy=[(x-31000,y+1250) for x,y in a.exterior.coords]
  ax.add_patch(Patch(xy,facecolor=fc,edgecolor=ec,linewidth=.9,linestyle=ls))
  for ring in a.interiors:ax.add_patch(Patch([(x-31000,y+1250) for x,y in ring.coords],facecolor='#eeeae2',edgecolor=ec,linewidth=.6,linestyle=ls))
fig,axes=plt.subplots(1,2,figsize=(6.2,3.45),dpi=150);fig.patch.set_facecolor('#eeeae2')
for i,(ax,g,title) in enumerate(zip(axes,[old,new],['R02 / overlapping backing','R03 / partitioned backing'])):
 ax.set_facecolor('#eeeae2');plot(ax,g,'#cbc4b8' if i==0 else '#d7b479','black' if i==0 else '#a33','-' if i==0 else '--');plot(ax,pier,'#a9bfbe','black')
 if i==0:plot(ax,old.intersection(pier),'#cb8278','#a33')
 ax.axhline(0,color='#999',linewidth=.6,linestyle='--');ax.axvline(0,color='#999',linewidth=.6,linestyle='--')
 ax.set_aspect('equal');ax.set_xlim(-250,250);ax.set_ylim(-370,180);ax.set_title(title,fontsize=9);ax.tick_params(labelsize=7);ax.set_xlabel('Local X / native units',fontsize=8)
axes[0].set_ylabel('Local Y / room above zero',fontsize=8)
fig.tight_layout();fig.savefig(p/'PLAN_COMPARISON.png',facecolor=fig.get_facecolor());plt.close(fig)
# Native-coordinate SVG: preserve exact geometry, translate only for local plotting.
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="-260 -200 520 600">']
def path(poly):return 'M '+' L '.join(str(x-31000)+','+str(-(y+1250)) for x,y in poly)+' Z'
for a in parts(new):
 ds=path(a.exterior.coords)+' '+' '.join(path(r.coords) for r in a.interiors)
 svg.append('<path d="'+ds+'" fill="#d7b479" fill-rule="evenodd" stroke="#a33" stroke-width="1" stroke-dasharray="4 3"/>')
for a in parts(pier):svg.append('<path d="'+path(a.exterior.coords)+'" fill="#a9bfbe" stroke="black" stroke-width="1"/>')
svg.append('<path d="M -260 0 L 260 0 M 0 -200 L 0 400" fill="none" stroke="#999" stroke-dasharray="4 4" stroke-width="0.8"/></svg>')
(p/'JUNCTION_SECTION_NATIVE.svg').write_text(''.join(svg))
im=Image.new('RGB',(1800,1150),'#eeeae2');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font=ImageFont.truetype(f,25);small=ImageFont.truetype(f,17)
d.text((26,16),'WALL + PIER JUNCTION / R03 EXPERIMENTAL',fill='#28251f',font=font)
d.text((26,53),'Continuous 320-to-170 outside transition | original shared piers and vaults unchanged | native scale 1:1',fill='#49443b',font=small)
a=Image.open(p/'ASSEMBLY.png').convert('RGB');a.thumbnail((1150,930));im.paste(a,(10,100))
a=Image.open(p/'JUNCTION_DETAIL.png').convert('RGB');a.thumbnail((560,560));im.paste(a,(1205,85))
a=Image.open(p/'PLAN_COMPARISON.png').convert('RGB');a.thumbnail((620,345));im.paste(a,(1170,725))
d.text((1180,658),'ISOLATED JUNCTION - receiving masonry highlighted',fill='#28251f',font=small)
d.text((1180,691),'PLAN AT Z925 - red overlap removed; pier in blue-gray',fill='#28251f',font=small)
d.text((26,1040),'LOCAL RECEIVING ENVELOPES - 128-unit taper stays within the existing window jamb',fill='#28251f',font=small)
d.text((26,1075),'Stone bonding, above-spring arch engagement and structural capacity remain unresolved.',fill='#49443b',font=small)
d.text((26,1110),str(q['passed'])+'/'+str(q['total'])+' technical/geometric checks | architectural review pending | historical and structural validation not performed',fill='#49443b',font=small)
im.save(p/'WALL_PIER_JUNCTION_R03_RESULT.png')
print(json.dumps(dict(passed=q['passed'],total=q['total'],affected=q['source_backing_meshes_affected'],protected=q['protected_mesh_count'],metrics=q['section_metrics']['925'])))
