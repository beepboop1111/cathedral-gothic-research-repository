import bpy,pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/SHARED_PIERS_R02/SHARED_PIERS_R02.blend')
bpy.ops.wm.open_mainfile(filepath=str(S));bpy.context.view_layer.update()
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
def bounds(o):
 v=coords(o);return [[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]]
jamb=[]
for o in bpy.context.scene.objects:
 if o.type=='MESH' and o.name.startswith('SIDE_-1_BAY2_WALL'):
  a,b=bounds(o)
  if abs(a[0]-31000)<.01 and 100<b[0]-a[0]<500:jamb.append(b[0])
assert len(jamb)==1
x0=62000-jamb[0];x1=jamb[0];limit=4100.;affected=[];triangles={};protected={};piers={}
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 a,b=bounds(o);v=coords(o)
 isback=o.name.startswith(('WALL_','PLINTH_','MORTAR_','SIDE_','CHAPEL_CORE_')) and 'GLASS' not in o.name
 hit=isback and b[0]>x0+.001 and a[0]<x1-.001 and b[2]>.001 and a[2]<limit-.001 and (b[1]>1250+.001 or a[1]<-1250-.001)
 if hit:
  affected.append(o.name);o.data.calc_loop_triangles();triangles[o.name]=[[list(v[i]) for i in t.vertices] for t in o.data.loop_triangles]
 else:protected[o.name]=sig(o)
 if o.name.startswith('SHARED_PIER_'):
  o.data.calc_loop_triangles();piers[o.name]=[[list(v[i][:2]) for i in t.vertices] for t in o.data.loop_triangles if all(abs(v[i][2]-1800)<.001 for i in t.vertices)]
D=dict(source=str(S),source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),x0=x0,x1=x1,zmax=limit,affected=affected,original_triangles=triangles,protected_signatures=protected,pier_caps=piers)
(R/'INPUTS.json').write_text(json.dumps(D))
print('STUDY',x0,x1,'affected',len(affected),'protected',len(protected))
