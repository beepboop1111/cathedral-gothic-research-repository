import json,pathlib,math
from shapely.geometry import Polygon,box,LineString
from shapely.ops import unary_union,polygonize
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text())
x0,x1=D['x0'],D['x1'];joint=31000.;checks={};meshes=[];plans={}
piers={k:unary_union([Polygon(t) for t in v]) for k,v in D['pier_caps'].items()}
start=joint+math.ceil(max(p.bounds[2]-joint for p in piers.values())/16)*16
assert start<x1
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
def add(name,g,zlo,zhi):
 for j,p in enumerate(parts(g)):
  p=orient(p,sign=1);v=[];ind={};faces=[]
  def vertex(x,y,k):
   q=(float(x),float(y),float(zhi if k else zlo))
   if q not in ind:ind[q]=len(v);v.append(q)
   return ind[q]
  ts=list(constrained_delaunay_triangles(p).geoms)
  assert abs(sum(t.area for t in ts)-p.area)<.01
  for t in ts:
   c=list(orient(t,sign=1).exterior.coords)[:-1];faces.extend([list(reversed([vertex(a,b,0) for a,b in c])),[vertex(a,b,1) for a,b in c]])
  for ring in [p.exterior,*p.interiors]:
   c=list(ring.coords)
   for a,b in zip(c,c[1:]):faces.append([vertex(*a,0),vertex(*b,0),vertex(*b,1),vertex(*a,1)])
  meshes.append(dict(name=name+'_'+str(j),vertices=v,faces=faces))
for side in ('S','N'):
 s=-1 if side=='S' else 1;pier=piers['SHARED_PIER_'+side]
 target=Polygon([(x0,s*1250),(x1,s*1250),(x1,s*1420),(start,s*1570),(x0,s*1570)])
 base=box(x0,min(s*1250,s*1600),x1,max(s*1250,s*1600))
 for layer,mask,a,b in [('PLINTH',base,0,100),('LOWER',target,100,1800),('UPPER',target,1800,4100)]:
  backing=mask.difference(pier) if layer!='UPPER' else mask
  add('RECEIVING_'+side+'_'+layer,backing,a,b)
  checks[side+'_'+layer+'_backing_connected_to_envelope']=backing.is_valid
  if layer!='UPPER':
   checks[side+'_'+layer+'_no_pier_duplicate']=backing.intersection(pier).area<.001
   checks[side+'_'+layer+'_envelope_complete']=unary_union([backing,pier.intersection(mask)]).symmetric_difference(mask).area<.001
 checks[side+'_no_backing_in_reserved_vault_plan']=target.intersection(box(28600,-1250,33400,1250)).area<.001
 checks[side+'_pier_kept_inside_new_backing_envelope']=pier.intersection(box(x0,min(s*1250,s*1600),x1,max(s*1250,s*1600))).difference(target).area<.001
 plans[side]=dict(target=list(target.exterior.coords),base=list(base.exterior.coords),pier=[list(p.exterior.coords) for p in parts(pier)])
config=dict(revision='WALL_PIER_JUNCTION_R03_EXPERIMENTAL',study_x=[x0,x1],plateau_end=start,taper_end=x1,taper_run=x1-start,wall_depths=[320,170],plinth_depth=350,layers=[[0,100],[100,1800],[1800,4100]],strategy='Keep actual shared piers; continuous outside 320-to170 taper contained within existing window jamb; remove old backing only in study boxes and partition new backing away from piers')
(R/'RECEIVING_MESHES.json').write_text(json.dumps(meshes))
(R/'PLAN.json').write_text(json.dumps(dict(config=config,plans=plans,checks=checks),indent=2))
assert all(checks.values()),checks
print('PLAN',json.dumps(config),'meshes',len(meshes))
