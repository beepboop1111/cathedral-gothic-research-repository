import json,pathlib
from shapely.geometry import Polygon,LineString,box
from shapely.ops import unary_union,polygonize
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());A=json.loads((R/'ACTUAL_MESHES.json').read_text());P=json.loads((R/'PLAN.json').read_text())
def section(tris,z):
 seg=[]
 for t in tris:
  pts=[]
  for a,b in zip(t,t[1:]+t[:1]):
   if (a[2]<z<b[2]) or (b[2]<z<a[2]):
    f=(z-a[2])/(b[2]-a[2]);pts.append((round(a[0]+f*(b[0]-a[0]),6),round(a[1]+f*(b[1]-a[1]),6)))
  if len(pts)==2 and pts[0]!=pts[1]:seg.append(pts)
 if not seg:return Polygon()
 polygons=list(polygonize(unary_union([LineString(s) for s in seg])))
 def inside(p):
  x,y=p.x,p.y;hits=[]
  for a,b in seg:
   if (a[1]>y)!=(b[1]>y):
    hit=a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1])
    if hit>x:hits.append(round(hit,5))
  return len(set(hits))%2==1
 return unary_union([p for p in polygons if inside(p.representative_point())])
checks={};metrics={}
boxes=unary_union([box(D['x0'],-1600,D['x1'],-1250),box(D['x0'],1250,D['x1'],1600)])
for z in [50,150,575,925,1775,1825,3100,4025]:
 old=[section(t,z) for t in D['original_triangles'].values()]
 new=[section(t,z) for t in A['backing'].values()]
 pier=unary_union([section(t,z) for t in A['piers'].values()])
 oldunion=unary_union(old);newunion=unary_union(new)
 outside=oldunion.difference(boxes).symmetric_difference(newunion.difference(boxes)).area
 local=[p.intersection(boxes) for p in new];localunion=unary_union(local)
 duplicate=sum(p.area for p in local)-localunion.area
 overlap=localunion.intersection(pier).area
 target=unary_union([Polygon(v['base' if z<100 else 'target']) for v in P['plans'].values()])
 actual=localunion.union(pier.intersection(boxes)) if z<1800 else localunion
 envelope=actual.symmetric_difference(target).area
 metrics[str(z)]=dict(outside_study_difference_area=outside,local_backing_duplicate_area=duplicate,pier_backing_overlap_area=overlap,envelope_difference_area=envelope,original_pier_backing_overlap_area=oldunion.intersection(pier).area,original_backing_duplicate_area=sum(p.intersection(boxes).area for p in old)-oldunion.intersection(boxes).area)
 checks[str(z)+'_outside_study_unchanged_within_2_area_units']=outside<=2
 checks[str(z)+'_no_local_backing_duplicates_within_2_area_units']=abs(duplicate)<=2
 checks[str(z)+'_no_pier_backing_overlap_within_2_area_units']=overlap<=2
 checks[str(z)+'_target_envelope_complete_within_2_area_units']=envelope<=2
(R/'SECTION_REGRESSION.json').write_text(json.dumps(dict(checks=checks,metrics=metrics,tolerance_square_native_units=2),indent=2))
assert all(checks.values()),metrics
print('SECTION_REGRESSION_PASS',len(checks))
