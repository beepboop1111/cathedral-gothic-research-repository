# Wall and pier junction R03 — EXPERIMENTAL

## Scope and baseline
Parent: saved SHARED_PIERS_R02.blend, exact path and SHA256 in QA below. Experimental adjoining axial chapel bays, not approved cathedral architecture. Native numerical 1:1, X east/Y north/Z up; physical SI calibration unresolved. Approved architecture, authoritative generators, historical originals, inner/middle ambulatory work and Pass6J remain untouched. No promotion.

GitHub governance was read at the beginning of this task. The user subsequently instructed: no GitHub reads or writes unless explicitly asked. No GitHub checkpoint was written for R03. All sources, outputs and this handoff are retained locally on MR COMPUTER. Do not automatically sync or inspect GitHub in future tasks without a new explicit request; this supersedes the earlier automatic-governance/sync workflow.

## Bounded change
Replace receiving backing only in two local boxes: X30760–31240, Y1250–1600 or Y−1600–−1250, Z0–4100. These align with the existing shared window jambs. Source boxes are removed from 84 intersecting backing meshes using Blender exact Boolean differences; empty remnants are removed. All 205 protected mesh objects, including the shared piers, all arches/ribs/webs, windows and unrelated masonry, retain identical world vertex arrays and polygon connectivity.

Preserve original five-bearing shared pier geometry. The 320-deep receiving zone extends to X31112 (past the actual pier-section extent, rounded outward on a16-unit construction step), then tapers over128 native units to the existing170-depth wall at X31240. The wall inner face stays at Y±1250. The taper is a provisional geometric choice, not a historical or structural prescription. The 350-deep existing plinth reservation is retained in Z0–100. Layers Z0–100 and Z100–1800 partition backing away from the actual shared pier cap projections. Above Z1800, receiving-wall envelopes continue to Z4100. Eight new receiving solids own these local wall regions; the original pier owns its core/respond volume. Detailed stone courses inside the study boxes are replaced by trial receiving envelopes; they need later bonding design. Outside the boxes the existing stones/mortar are retained.

## Validation actually run
59/59 technical/geometric checks pass. Exact protected-mesh/source-hash checks, new/cut mesh closure, consistent winding, positive volume, finite coordinates, and actual GLB reimport tested. Export/import matches all object names/counts, world bounds (error0; tolerance0.01 native units) and oriented world-triangle signatures at0.001 quantization.

Independent horizontal section extraction from actual Blender triangles at Z50,150,575,925,1775,1825,3100,4025 checks local envelope completion, local backing duplicates, pier/backing overlap and outside-study retention. Area tolerance is2 square native units, stated explicitly; this is a numerical tolerance, not a dimensional construction allowance. Original source mesh slices are independently reconstructed using segment polygonization and parity tests. Outside-study section symmetric differences are reported per level. Checks sample eight sections, not every possible height or all whole-model collisions.

At Z925, original local backing duplicates totaled74800 square native units and original pier/backing overlap92708.191338. New local backing duplicate area0; residual pier/backing overlap0.0000081682; envelope difference0.000369659; outside-study difference0. The residuals arise from numerical coordinate storage/sectioning. These figures concern both shared junction study boxes together. Receiving geometry is classified separately from intentional arch embedding above springing, which remains unresolved and was not comprehensively collision-tested.

## Architectural and other limits
The former abrupt wall-depth change now has a continuous experimental outside face within each existing jamb. This is a geometric resolution only; design approval, stone bonding, course transitions, above-spring arch engagement, base detailing and load-bearing areas remain unresolved. Historical construction: not assessed. Structural capacity: not assessed; F5ZL-C support schedule remains missing. No historic or structural validation follows from the geometric checks. Existing vault dimensions and spring sections remain unchanged.

## Reproduce
Save the five scripts below together in a new experimental directory, with the exact parent .blend available. Requires Blender5.0.1, system Python3 with Shapely2.1.2; Pillow and matplotlib for the composite. Run:

1. `blender -b -t 4 --python extract_inputs.py`
2. `python3 prepare_junction.py`
3. `blender -b -t 4 --python build_and_verify.py`
4. `python3 compose_preview.py`

The builder invokes verify_sections.py automatically. Outputs retained at `/home/christopher/Documents/Cathedral/experimental/WALL_PIER_JUNCTION_R03`: WALL_PIER_JUNCTION_R03.blend and .glb, INPUTS.json, PLAN.json, RECEIVING_MESHES.json, ACTUAL_MESHES.json, SECTION_REGRESSION.json, QA.json, JUNCTION_SECTION_NATIVE.svg, before/after plan PNG, assembly/detail renders and final composite. Native SVG uses one SVG user unit per native project unit, with a documented local translation/reflection. Black contours are recovered source geometry, dashed gray axes construction, dashed red trial receiver outlines. The final composite was visually inspected; user-facing upload is PNG only.

## QA
```json
{
  "revision": "WALL_PIER_JUNCTION_R03_EXPERIMENTAL",
  "source": "/home/christopher/Documents/Cathedral/experimental/SHARED_PIERS_R02/SHARED_PIERS_R02.blend",
  "source_sha256": "f789eed33b7bf2d4a9214fdbbf4f2454c0d745bd10533eee93f237193fa521eb",
  "checks": {
    "protected_vaults_windows_and_shared_piers_match_R02": true,
    "protected_geometry_unchanged_after_local_replacement": true,
    "cut_backing_and_new_receivers_closed_consistently_wound": true,
    "cut_backing_and_new_receivers_positive_volume": true,
    "new_receivers_finite": true,
    "50_outside_study_unchanged_within_2_area_units": true,
    "50_no_local_backing_duplicates_within_2_area_units": true,
    "50_no_pier_backing_overlap_within_2_area_units": true,
    "50_target_envelope_complete_within_2_area_units": true,
    "150_outside_study_unchanged_within_2_area_units": true,
    "150_no_local_backing_duplicates_within_2_area_units": true,
    "150_no_pier_backing_overlap_within_2_area_units": true,
    "150_target_envelope_complete_within_2_area_units": true,
    "575_outside_study_unchanged_within_2_area_units": true,
    "575_no_local_backing_duplicates_within_2_area_units": true,
    "575_no_pier_backing_overlap_within_2_area_units": true,
    "575_target_envelope_complete_within_2_area_units": true,
    "925_outside_study_unchanged_within_2_area_units": true,
    "925_no_local_backing_duplicates_within_2_area_units": true,
    "925_no_pier_backing_overlap_within_2_area_units": true,
    "925_target_envelope_complete_within_2_area_units": true,
    "1775_outside_study_unchanged_within_2_area_units": true,
    "1775_no_local_backing_duplicates_within_2_area_units": true,
    "1775_no_pier_backing_overlap_within_2_area_units": true,
    "1775_target_envelope_complete_within_2_area_units": true,
    "1825_outside_study_unchanged_within_2_area_units": true,
    "1825_no_local_backing_duplicates_within_2_area_units": true,
    "1825_no_pier_backing_overlap_within_2_area_units": true,
    "1825_target_envelope_complete_within_2_area_units": true,
    "3100_outside_study_unchanged_within_2_area_units": true,
    "3100_no_local_backing_duplicates_within_2_area_units": true,
    "3100_no_pier_backing_overlap_within_2_area_units": true,
    "3100_target_envelope_complete_within_2_area_units": true,
    "4025_outside_study_unchanged_within_2_area_units": true,
    "4025_no_local_backing_duplicates_within_2_area_units": true,
    "4025_no_pier_backing_overlap_within_2_area_units": true,
    "4025_target_envelope_complete_within_2_area_units": true,
    "S_PLINTH_backing_connected_to_envelope": true,
    "S_PLINTH_no_pier_duplicate": true,
    "S_PLINTH_envelope_complete": true,
    "S_LOWER_backing_connected_to_envelope": true,
    "S_LOWER_no_pier_duplicate": true,
    "S_LOWER_envelope_complete": true,
    "S_UPPER_backing_connected_to_envelope": true,
    "S_no_backing_in_reserved_vault_plan": true,
    "S_pier_kept_inside_new_backing_envelope": true,
    "N_PLINTH_backing_connected_to_envelope": true,
    "N_PLINTH_no_pier_duplicate": true,
    "N_PLINTH_envelope_complete": true,
    "N_LOWER_backing_connected_to_envelope": true,
    "N_LOWER_no_pier_duplicate": true,
    "N_LOWER_envelope_complete": true,
    "N_UPPER_backing_connected_to_envelope": true,
    "N_no_backing_in_reserved_vault_plan": true,
    "N_pier_kept_inside_new_backing_envelope": true,
    "R02_source_file_hash_unchanged": true,
    "GLB_object_names_and_count": true,
    "GLB_world_bounds_within_0_01": true,
    "GLB_oriented_triangle_signatures_at_0_001": true
  },
  "passed": 59,
  "total": 59,
  "config": {
    "revision": "WALL_PIER_JUNCTION_R03_EXPERIMENTAL",
    "study_x": [
      30760,
      31240
    ],
    "plateau_end": 31112,
    "taper_end": 31240,
    "taper_run": 128,
    "wall_depths": [
      320,
      170
    ],
    "plinth_depth": 350,
    "layers": [
      [
        0,
        100
      ],
      [
        100,
        1800
      ],
      [
        1800,
        4100
      ]
    ],
    "strategy": "Keep actual shared piers; continuous outside 320-to170 taper contained within existing window jamb; remove old backing only in study boxes and partition new backing away from piers"
  },
  "protected_mesh_count": 205,
  "source_backing_meshes_affected": 84,
  "fully_replaced_meshes": [
    "WALL_S-1_C00_B060_0",
    "WALL_S-1_C01_B059_0",
    "WALL_S-1_C02_B060_0",
    "WALL_S-1_C03_B058_0",
    "WALL_S-1_C03_B059_0",
    "WALL_S-1_C04_B059_0",
    "WALL_S-1_C04_B060_0",
    "WALL_S-1_C05_B058_0",
    "WALL_S-1_C05_B059_0",
    "WALL_S-1_C06_B059_0",
    "WALL_S-1_C06_B060_0",
    "WALL_S-1_C07_B058_0",
    "WALL_S-1_C07_B059_0",
    "WALL_S-1_C08_B059_0",
    "WALL_S-1_C08_B060_0",
    "WALL_S-1_C09_B058_0",
    "WALL_S-1_C09_B059_0",
    "WALL_S-1_C10_B059_0",
    "WALL_S-1_C11_B058_0",
    "WALL_S-1_C11_B059_0",
    "WALL_S-1_C13_B059_0",
    "WALL_S-1_C15_B059_0",
    "WALL_S-1_C17_B059_0",
    "WALL_S-1_C19_B059_0",
    "WALL_S1_C00_B060_0",
    "WALL_S1_C01_B059_0",
    "WALL_S1_C02_B060_0",
    "WALL_S1_C03_B058_0",
    "WALL_S1_C03_B059_0",
    "WALL_S1_C04_B059_0",
    "WALL_S1_C04_B060_0",
    "WALL_S1_C05_B058_0",
    "WALL_S1_C05_B059_0",
    "WALL_S1_C06_B059_0",
    "WALL_S1_C06_B060_0",
    "WALL_S1_C07_B058_0",
    "WALL_S1_C07_B059_0",
    "WALL_S1_C08_B059_0",
    "WALL_S1_C08_B060_0",
    "WALL_S1_C09_B058_0",
    "WALL_S1_C09_B059_0",
    "WALL_S1_C10_B059_0",
    "WALL_S1_C11_B058_0",
    "WALL_S1_C11_B059_0",
    "WALL_S1_C13_B059_0",
    "WALL_S1_C15_B059_0",
    "WALL_S1_C17_B059_0",
    "WALL_S1_C19_B059_0",
    "SIDE_1_BAY2_WALL.001",
    "SIDE_-1_BAY2_WALL.001"
  ],
  "new_receiving_solids": 8,
  "glb_bounds_error": 0,
  "section_metrics": {
    "50": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": -5.820766091346741e-11,
      "pier_backing_overlap_area": 0.000030552434739632844,
      "envelope_difference_area": 0.00000904618332883255,
      "original_pier_backing_overlap_area": 92708.19133879364,
      "original_backing_duplicate_area": 81600
    },
    "150": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": 0,
      "pier_backing_overlap_area": 0.00006372369477519041,
      "envelope_difference_area": 0.0000811525154822551,
      "original_pier_backing_overlap_area": 92708.1913181382,
      "original_backing_duplicate_area": 74800
    },
    "575": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": 2.9103830456733704e-11,
      "pier_backing_overlap_area": 0.0003933854217207655,
      "envelope_difference_area": 0.00008658500030445798,
      "original_pier_backing_overlap_area": 92708.19164348723,
      "original_backing_duplicate_area": 74800
    },
    "925": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": 0,
      "pier_backing_overlap_area": 0.000008168164433188766,
      "envelope_difference_area": 0.00036965887308175536,
      "original_pier_backing_overlap_area": 92708.19133806985,
      "original_backing_duplicate_area": 74800
    },
    "1775": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": 0,
      "pier_backing_overlap_area": 0.0001573326238017694,
      "envelope_difference_area": 0.00020893639919678853,
      "original_pier_backing_overlap_area": 92708.19131648417,
      "original_backing_duplicate_area": 74800
    },
    "1825": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": 0,
      "pier_backing_overlap_area": 0,
      "envelope_difference_area": 0.00007999990339158103,
      "original_pier_backing_overlap_area": 0,
      "original_backing_duplicate_area": 0
    },
    "3100": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": 0,
      "pier_backing_overlap_area": 0,
      "envelope_difference_area": 0.00005199985025683418,
      "original_pier_backing_overlap_area": 0,
      "original_backing_duplicate_area": 0
    },
    "4025": {
      "outside_study_difference_area": 0,
      "local_backing_duplicate_area": 0,
      "pier_backing_overlap_area": 0,
      "envelope_difference_area": 0.000037999809137545526,
      "original_pier_backing_overlap_area": 0,
      "original_backing_duplicate_area": 0
    }
  },
  "validation": {
    "technical": "scripts, boolean output mesh topology/volume, GLB actual reimport and oriented triangles",
    "geometric": "eight horizontal section regressions, outside-study retention, local envelope/overlap checks; shared pier/vault meshes unchanged",
    "architectural": "experimental128-unit plan taper in source240-unit window jamb; local stone pattern replaced by receiving envelopes; no design approval",
    "historical": "not assessed; numerical taper not sourced from historical construction",
    "structural": "not assessed; capacity, bonding, above-spring arch engagement unresolved; F5ZL-C schedule missing"
  }
}
```

## extract_inputs.py
```python
import bpy,pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/SHARED_PIERS_R02/SHARED_PIERS_R02.blend')
bpy.ops.wm.open_mainfile(filepath=str(S));bpy.context.view_layer.update()
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
def bounds(o):
 v=coords(o);return [[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]]
jamb=[]
for o in bpy.context.scene.objects:
 if o.type=='MESH' and o.name.startswith('SIDE_-1_BAY2_WALL'):
  a,b=bounds(o)
  if abs(a[0]-31000)<.01 and 100<b[0]-a[0]<500:jamb.append(b[0])
assert len(jamb)==1
x0=62000-jamb[0];x1=jamb[0];limit=4100.;affected=[];triangles={};protected={};piers={}
for o in bpy.context.scene.objects:
 if o.type!='MESH':continue
 a,b=bounds(o);v=coords(o)
 isback=o.name.startswith(('WALL_','PLINTH_','MORTAR_','SIDE_','CHAPEL_CORE_')) and 'GLASS' not in o.name
 hit=isback and b[0]>x0+.001 and a[0]<x1-.001 and b[2]>.001 and a[2]<limit-.001 and (b[1]>1250+.001 or a[1]<-1250-.001)
 if hit:
  affected.append(o.name);o.data.calc_loop_triangles();triangles[o.name]=[[list(v[i]) for i in t.vertices] for t in o.data.loop_triangles]
 else:protected[o.name]=sig(o)
 if o.name.startswith('SHARED_PIER_'):
  o.data.calc_loop_triangles();piers[o.name]=[[list(v[i][:2]) for i in t.vertices] for t in o.data.loop_triangles if all(abs(v[i][2]-1800)<.001 for i in t.vertices)]
D=dict(source=str(S),source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),x0=x0,x1=x1,zmax=limit,affected=affected,original_triangles=triangles,protected_signatures=protected,pier_caps=piers)
(R/'INPUTS.json').write_text(json.dumps(D))
print('STUDY',x0,x1,'affected',len(affected),'protected',len(protected))

```

## prepare_junction.py
```python
import json,pathlib,math
from shapely.geometry import Polygon,box,LineString
from shapely.ops import unary_union,polygonize
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text())
x0,x1=D['x0'],D['x1'];joint=31000.;checks={};meshes=[];plans={}
piers={k:unary_union([Polygon(t) for t in v]) for k,v in D['pier_caps'].items()}
start=joint+math.ceil(max(p.bounds[2]-joint for p in piers.values())/16)*16
assert start<x1
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
def add(name,g,zlo,zhi):
 for j,p in enumerate(parts(g)):
  p=orient(p,sign=1);v=[];ind={};faces=[]
  def vertex(x,y,k):
   q=(float(x),float(y),float(zhi if k else zlo))
   if q not in ind:ind[q]=len(v);v.append(q)
   return ind[q]
  ts=list(constrained_delaunay_triangles(p).geoms)
  assert abs(sum(t.area for t in ts)-p.area)<.01
  for t in ts:
   c=list(orient(t,sign=1).exterior.coords)[:-1];faces.extend([list(reversed([vertex(a,b,0) for a,b in c])),[vertex(a,b,1) for a,b in c]])
  for ring in [p.exterior,*p.interiors]:
   c=list(ring.coords)
   for a,b in zip(c,c[1:]):faces.append([vertex(*a,0),vertex(*b,0),vertex(*b,1),vertex(*a,1)])
  meshes.append(dict(name=name+'_'+str(j),vertices=v,faces=faces))
for side in ('S','N'):
 s=-1 if side=='S' else 1;pier=piers['SHARED_PIER_'+side]
 target=Polygon([(x0,s*1250),(x1,s*1250),(x1,s*1420),(start,s*1570),(x0,s*1570)])
 base=box(x0,min(s*1250,s*1600),x1,max(s*1250,s*1600))
 for layer,mask,a,b in [('PLINTH',base,0,100),('LOWER',target,100,1800),('UPPER',target,1800,4100)]:
  backing=mask.difference(pier) if layer!='UPPER' else mask
  add('RECEIVING_'+side+'_'+layer,backing,a,b)
  checks[side+'_'+layer+'_backing_connected_to_envelope']=backing.is_valid
  if layer!='UPPER':
   checks[side+'_'+layer+'_no_pier_duplicate']=backing.intersection(pier).area<.001
   checks[side+'_'+layer+'_envelope_complete']=unary_union([backing,pier.intersection(mask)]).symmetric_difference(mask).area<.001
 checks[side+'_no_backing_in_reserved_vault_plan']=target.intersection(box(28600,-1250,33400,1250)).area<.001
 checks[side+'_pier_kept_inside_new_backing_envelope']=pier.intersection(box(x0,min(s*1250,s*1600),x1,max(s*1250,s*1600))).difference(target).area<.001
 plans[side]=dict(target=list(target.exterior.coords),base=list(base.exterior.coords),pier=[list(p.exterior.coords) for p in parts(pier)])
config=dict(revision='WALL_PIER_JUNCTION_R03_EXPERIMENTAL',study_x=[x0,x1],plateau_end=start,taper_end=x1,taper_run=x1-start,wall_depths=[320,170],plinth_depth=350,layers=[[0,100],[100,1800],[1800,4100]],strategy='Keep actual shared piers; continuous outside 320-to170 taper contained within existing window jamb; remove old backing only in study boxes and partition new backing away from piers')
(R/'RECEIVING_MESHES.json').write_text(json.dumps(meshes))
(R/'PLAN.json').write_text(json.dumps(dict(config=config,plans=plans,checks=checks),indent=2))
assert all(checks.values()),checks
print('PLAN',json.dumps(config),'meshes',len(meshes))

```

## verify_sections.py
```python
import json,pathlib
from shapely.geometry import Polygon,LineString,box
from shapely.ops import unary_union,polygonize
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());A=json.loads((R/'ACTUAL_MESHES.json').read_text());P=json.loads((R/'PLAN.json').read_text())
def section(tris,z):
 seg=[]
 for t in tris:
  pts=[]
  for a,b in zip(t,t[1:]+t[:1]):
   if (a[2]<z<b[2]) or (b[2]<z<a[2]):
    f=(z-a[2])/(b[2]-a[2]);pts.append((round(a[0]+f*(b[0]-a[0]),6),round(a[1]+f*(b[1]-a[1]),6)))
  if len(pts)==2 and pts[0]!=pts[1]:seg.append(pts)
 if not seg:return Polygon()
 polygons=list(polygonize(unary_union([LineString(s) for s in seg])))
 def inside(p):
  x,y=p.x,p.y;hits=[]
  for a,b in seg:
   if (a[1]>y)!=(b[1]>y):
    hit=a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1])
    if hit>x:hits.append(round(hit,5))
  return len(set(hits))%2==1
 return unary_union([p for p in polygons if inside(p.representative_point())])
checks={};metrics={}
boxes=unary_union([box(D['x0'],-1600,D['x1'],-1250),box(D['x0'],1250,D['x1'],1600)])
for z in [50,150,575,925,1775,1825,3100,4025]:
 old=[section(t,z) for t in D['original_triangles'].values()]
 new=[section(t,z) for t in A['backing'].values()]
 pier=unary_union([section(t,z) for t in A['piers'].values()])
 oldunion=unary_union(old);newunion=unary_union(new)
 outside=oldunion.difference(boxes).symmetric_difference(newunion.difference(boxes)).area
 local=[p.intersection(boxes) for p in new];localunion=unary_union(local)
 duplicate=sum(p.area for p in local)-localunion.area
 overlap=localunion.intersection(pier).area
 target=unary_union([Polygon(v['base' if z<100 else 'target']) for v in P['plans'].values()])
 actual=localunion.union(pier.intersection(boxes)) if z<1800 else localunion
 envelope=actual.symmetric_difference(target).area
 metrics[str(z)]=dict(outside_study_difference_area=outside,local_backing_duplicate_area=duplicate,pier_backing_overlap_area=overlap,envelope_difference_area=envelope,original_pier_backing_overlap_area=oldunion.intersection(pier).area,original_backing_duplicate_area=sum(p.intersection(boxes).area for p in old)-oldunion.intersection(boxes).area)
 checks[str(z)+'_outside_study_unchanged_within_2_area_units']=outside<=2
 checks[str(z)+'_no_local_backing_duplicates_within_2_area_units']=abs(duplicate)<=2
 checks[str(z)+'_no_pier_backing_overlap_within_2_area_units']=overlap<=2
 checks[str(z)+'_target_envelope_complete_within_2_area_units']=envelope<=2
(R/'SECTION_REGRESSION.json').write_text(json.dumps(dict(checks=checks,metrics=metrics,tolerance_square_native_units=2),indent=2))
assert all(checks.values()),metrics
print('SECTION_REGRESSION_PASS',len(checks))

```

## build_and_verify.py
```python
import bpy,json,pathlib,hashlib,math,collections,subprocess
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());P=json.loads((R/'PLAN.json').read_text())
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert digest(D['source'])==D['source_sha256'];bpy.ops.wm.open_mainfile(filepath=D['source']);bpy.context.view_layer.update()
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
def triangles(o):
 o.data.calc_loop_triangles();v=coords(o);return [[list(v[i]) for i in t.vertices] for t in o.data.loop_triangles]
protected={n:bpy.data.objects[n] for n in D['protected_signatures']};checks={}
checks['protected_vaults_windows_and_shared_piers_match_R02']=all(sig(o)==D['protected_signatures'][n] for n,o in protected.items())
cutters=[]
for s in [-1,1]:
 bpy.ops.mesh.primitive_cube_add(size=1,location=((D['x0']+D['x1'])/2,s*1425,2050));o=bpy.context.object;o.name='TEMP_STUDY_CUT';o.dimensions=(D['x1']-D['x0'],350,4100)
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);cutters.append(o)
removed=[]
for name in D['affected']:
 o=bpy.data.objects[name];ys=[v[1] for v in coords(o)];cut=cutters[1] if sum(ys)>0 else cutters[0]
 mod=o.modifiers.new('LOCAL_BACKING_REPLACEMENT','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cut
 bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 if not o.data.polygons:removed.append(name);bpy.data.objects.remove(o,do_unlink=True)
for o in cutters:bpy.data.objects.remove(o,do_unlink=True)
mat=bpy.data.materials.new('R03_RECEIVING_MASONRY');mat.diffuse_color=(.61,.44,.25,1);mat.use_nodes=True
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.61,.44,.25,1);mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.85
new=[]
for m in json.loads((R/'RECEIVING_MESHES.json').read_text()):
 me=bpy.data.meshes.new(m['name']);me.from_pydata(m['vertices'],[],m['faces']);me.update();o=bpy.data.objects.new(m['name'],me);bpy.context.scene.collection.objects.link(o);o.data.materials.append(mat);new.append(o)
checks['protected_geometry_unchanged_after_local_replacement']=all(sig(o)==D['protected_signatures'][n] for n,o in protected.items())
def topology(o):
 edges=collections.defaultdict(list)
 for p in o.data.polygons:
  v=list(p.vertices)
  for a,b in zip(v,v[1:]+v[:1]):edges[tuple(sorted((a,b)))].append(a<b)
 return all(len(v)==2 and v[0]!=v[1] for v in edges.values())
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(p) for p in coords(o)];c=v[0]
 return sum((v[t.vertices[0]]-c).dot((v[t.vertices[1]]-c).cross(v[t.vertices[2]]-c))/6 for t in o.data.loop_triangles)
remaining=[bpy.data.objects[n] for n in D['affected'] if n in bpy.data.objects];affected=remaining+new
checks['cut_backing_and_new_receivers_closed_consistently_wound']=all(topology(o) for o in affected)
checks['cut_backing_and_new_receivers_positive_volume']=all(volume(o)>0 for o in affected)
checks['new_receivers_finite']=all(math.isfinite(v) for o in affected for p in coords(o) for v in p)
actual=dict(backing={o.name:triangles(o) for o in affected},piers={n:triangles(bpy.data.objects[n]) for n in ['SHARED_PIER_S','SHARED_PIER_N']})
(R/'ACTUAL_MESHES.json').write_text(json.dumps(actual))
subprocess.run(['/usr/bin/python3',str(R/'verify_sections.py')],check=True)
reg=json.loads((R/'SECTION_REGRESSION.json').read_text());checks.update(reg['checks']);checks.update(P['checks'])
checks['R02_source_file_hash_unchanged']=digest(D['source'])==D['source_sha256']
assert all(checks.values()),checks
bpy.ops.wm.save_as_mainfile(filepath=str(R/'WALL_PIER_JUNCTION_R03.blend'))
def snapshot(obs):
 out={}
 for o in obs:
  v=coords(o);o.data.calc_loop_triangles();tri=[]
  for t in o.data.loop_triangles:
   pts=[tuple(round(v[i][k],3) for k in range(3)) for i in t.vertices];tri.append(min(tuple(pts[j:]+pts[:j]) for j in range(3)))
  out[o.name]=dict(bounds=[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]],triangles=sorted(tri))
 return out
snap=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
bpy.ops.export_scene.gltf(filepath=str(R/'WALL_PIER_JUNCTION_R03.glb'),export_format='GLB',export_cameras=False,export_lights=False)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.ops.import_scene.gltf(filepath=str(R/'WALL_PIER_JUNCTION_R03.glb'))
now=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
checks['GLB_object_names_and_count']=set(snap)==set(now)
err=max(abs(snap[n]['bounds'][j][k]-now[n]['bounds'][j][k]) for n in snap for j in range(2) for k in range(3))
checks['GLB_world_bounds_within_0_01']=err<.01
checks['GLB_oriented_triangle_signatures_at_0_001']=all(snap[n]['triangles']==now[n]['triangles'] for n in snap)
qa=dict(revision='WALL_PIER_JUNCTION_R03_EXPERIMENTAL',source=D['source'],source_sha256=D['source_sha256'],checks=checks,passed=sum(checks.values()),total=len(checks),config=P['config'],protected_mesh_count=len(protected),source_backing_meshes_affected=len(D['affected']),fully_replaced_meshes=removed,new_receiving_solids=len(new),glb_bounds_error=err,section_metrics=reg['metrics'],validation=dict(technical='scripts, boolean output mesh topology/volume, GLB actual reimport and oriented triangles',geometric='eight horizontal section regressions, outside-study retention, local envelope/overlap checks; shared pier/vault meshes unchanged',architectural='experimental128-unit plan taper in source240-unit window jamb; local stone pattern replaced by receiving envelopes; no design approval',historical='not assessed; numerical taper not sourced from historical construction',structural='not assessed; capacity, bonding, above-spring arch engagement unresolved; F5ZL-C schedule missing'))
(R/'QA.json').write_text(json.dumps(qa,indent=2));assert all(checks.values()),qa
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX'
scene.render.resolution_x=1400;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(26200,-8200,5800));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=8200;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(31000,0,2200))
for loc,power,size in [((28000,-4000,8500),2200000000,5000),((34000,3500,6500),1700000000,4000)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(31000,0,1800))
scene.render.filepath=str(R/'ASSEMBLY.png');bpy.ops.render.render(write_still=True)
for o in scene.objects:
 if o.type=='MESH':o.hide_render=not (o.name.startswith('RECEIVING_S_') or o.name=='SHARED_PIER_S')
cam.location=(32000,-2750,2500);cam.data.ortho_scale=4700;aim(cam,(31000,-1400,2050));scene.render.resolution_x=1000;scene.render.resolution_y=1000
scene.render.filepath=str(R/'JUNCTION_DETAIL.png');bpy.ops.render.render(write_still=True)
print('RESULT',json.dumps(qa))

```

## compose_preview.py
```python
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
import json
# Reuse section extraction functions without rerunning their QA entry point.
p=Path(__file__).resolve().parent
namespace={'__file__':str(p/'verify_sections.py')}
exec((p/'verify_sections.py').read_text().split('checks={};metrics={}')[0],namespace)
section=namespace['section'];D=namespace['D'];A=namespace['A'];P=namespace['P'];unary_union=namespace['unary_union']
q=json.loads((p/'QA.json').read_text())
old=unary_union([section(t,925) for t in D['original_triangles'].values()])
new=unary_union([section(t,925) for t in A['backing'].values()])
pier=unary_union([section(t,925) for t in A['piers'].values()])
clip=namespace['box'](D['x0'],-1600,D['x1'],-1050)
old=old.intersection(clip);new=new.intersection(clip);pier=pier.intersection(clip)
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
def plot(ax,g,fc,ec,ls='-'):
 for a in parts(g):
  xy=[(x-31000,y+1250) for x,y in a.exterior.coords]
  ax.add_patch(Patch(xy,facecolor=fc,edgecolor=ec,linewidth=.9,linestyle=ls))
  for ring in a.interiors:ax.add_patch(Patch([(x-31000,y+1250) for x,y in ring.coords],facecolor='#eeeae2',edgecolor=ec,linewidth=.6,linestyle=ls))
fig,axes=plt.subplots(1,2,figsize=(6.2,3.45),dpi=150);fig.patch.set_facecolor('#eeeae2')
for i,(ax,g,title) in enumerate(zip(axes,[old,new],['R02 / overlapping backing','R03 / partitioned backing'])):
 ax.set_facecolor('#eeeae2');plot(ax,g,'#cbc4b8' if i==0 else '#d7b479','black' if i==0 else '#a33','-' if i==0 else '--');plot(ax,pier,'#a9bfbe','black')
 if i==0:plot(ax,old.intersection(pier),'#cb8278','#a33')
 ax.axhline(0,color='#999',linewidth=.6,linestyle='--');ax.axvline(0,color='#999',linewidth=.6,linestyle='--')
 ax.set_aspect('equal');ax.set_xlim(-250,250);ax.set_ylim(-370,180);ax.set_title(title,fontsize=9);ax.tick_params(labelsize=7);ax.set_xlabel('Local X / native units',fontsize=8)
axes[0].set_ylabel('Local Y / room above zero',fontsize=8)
fig.tight_layout();fig.savefig(p/'PLAN_COMPARISON.png',facecolor=fig.get_facecolor());plt.close(fig)
# Native-coordinate SVG: preserve exact geometry, translate only for local plotting.
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="-260 -200 520 600">']
def path(poly):return 'M '+' L '.join(str(x-31000)+','+str(-(y+1250)) for x,y in poly)+' Z'
for a in parts(new):
 ds=path(a.exterior.coords)+' '+' '.join(path(r.coords) for r in a.interiors)
 svg.append('<path d="'+ds+'" fill="#d7b479" fill-rule="evenodd" stroke="#a33" stroke-width="1" stroke-dasharray="4 3"/>')
for a in parts(pier):svg.append('<path d="'+path(a.exterior.coords)+'" fill="#a9bfbe" stroke="black" stroke-width="1"/>')
svg.append('<path d="M -260 0 L 260 0 M 0 -200 L 0 400" fill="none" stroke="#999" stroke-dasharray="4 4" stroke-width="0.8"/></svg>')
(p/'JUNCTION_SECTION_NATIVE.svg').write_text(''.join(svg))
im=Image.new('RGB',(1800,1150),'#eeeae2');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font=ImageFont.truetype(f,25);small=ImageFont.truetype(f,17)
d.text((26,16),'WALL + PIER JUNCTION / R03 EXPERIMENTAL',fill='#28251f',font=font)
d.text((26,53),'Continuous 320-to-170 outside transition | original shared piers and vaults unchanged | native scale 1:1',fill='#49443b',font=small)
a=Image.open(p/'ASSEMBLY.png').convert('RGB');a.thumbnail((1150,930));im.paste(a,(10,100))
a=Image.open(p/'JUNCTION_DETAIL.png').convert('RGB');a.thumbnail((560,560));im.paste(a,(1205,85))
a=Image.open(p/'PLAN_COMPARISON.png').convert('RGB');a.thumbnail((620,345));im.paste(a,(1170,725))
d.text((1180,658),'ISOLATED JUNCTION - receiving masonry highlighted',fill='#28251f',font=small)
d.text((1180,691),'PLAN AT Z925 - red overlap removed; pier in blue-gray',fill='#28251f',font=small)
d.text((26,1040),'LOCAL RECEIVING ENVELOPES - 128-unit taper stays within the existing window jamb',fill='#28251f',font=small)
d.text((26,1075),'Stone bonding, above-spring arch engagement and structural capacity remain unresolved.',fill='#49443b',font=small)
d.text((26,1110),str(q['passed'])+'/'+str(q['total'])+' technical/geometric checks | architectural review pending | historical and structural validation not performed',fill='#49443b',font=small)
im.save(p/'WALL_PIER_JUNCTION_R03_RESULT.png')
print(json.dumps(dict(passed=q['passed'],total=q['total'],affected=q['source_backing_meshes_affected'],protected=q['protected_mesh_count'],metrics=q['section_metrics']['925'])))

```
