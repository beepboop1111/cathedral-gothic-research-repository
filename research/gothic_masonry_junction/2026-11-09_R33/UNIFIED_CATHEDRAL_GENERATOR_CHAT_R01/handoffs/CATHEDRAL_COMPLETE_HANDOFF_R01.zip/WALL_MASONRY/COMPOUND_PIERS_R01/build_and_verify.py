import bpy,json,pathlib,hashlib,math,collections,subprocess
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent
D=json.loads((R/'SPRING_SECTIONS.json').read_text());SRC=pathlib.Path(D['source'])
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==D['source_sha256']
bpy.ops.wm.open_mainfile(filepath=str(SRC))
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
removed=[o for o in bpy.context.scene.objects if o.type=='MESH' and 'SHAFT' in o.name]
assert len(removed)==8
retained=[o for o in bpy.context.scene.objects if o.type=='MESH' and o not in removed]
before={o.name:sig(o) for o in retained}
for o in removed:bpy.data.objects.remove(o,do_unlink=True)
material=bpy.data.materials.new('NEW_COMPOUND_PIERS');material.diffuse_color=(.70,.60,.43,1);material.use_nodes=True
material.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.70,.60,.43,1)
material.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.8
piers=[]
for d in json.loads((R/'PIER_MESHES.json').read_text()):
 me=bpy.data.meshes.new(d['name']);me.from_pydata(d['vertices'],[],d['faces']);me.update()
 o=bpy.data.objects.new(d['name'],me);bpy.context.scene.collection.objects.link(o);o.data.materials.append(material);o['source_bearings_degrees']=d['bearings'];piers.append(o)
def topology(o):
 edges=collections.Counter();directions=collections.defaultdict(list)
 for p in o.data.polygons:
  v=list(p.vertices)
  for a,b in zip(v,v[1:]+v[:1]):
   key=tuple(sorted((a,b)));edges[key]+=1;directions[key].append(a<b)
 return all(n==2 for n in edges.values()) and all(x[0]!=x[1] for x in directions.values())
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(p) for p in coords(o)];center=v[0]
 return sum((v[t.vertices[0]]-center).dot((v[t.vertices[1]]-center).cross(v[t.vertices[2]]-center))/6 for t in o.data.loop_triangles)
section=json.loads((R/'SECTION_QA.json').read_text());checks=section['checks']
checks['retained_vault_and_all_masonry_geometry_unchanged']=all(sig(o)==before[o.name] for o in retained)
checks['four_new_piers_closed_consistently_wound']=all(topology(o) for o in piers)
checks['four_new_piers_positive_volume']=all(volume(o)>0 for o in piers)
checks['vertical_extrusion_without_bends']=all(all(any(abs(a[0]-b[0])<1e-8 and abs(a[1]-b[1])<1e-8 and abs(a[2]-b[2])>1799 for b in coords(o)) for a in coords(o)) for o in piers)
checks['source_masonry_file_hash_unchanged']=hashlib.sha256(SRC.read_bytes()).hexdigest()==D['source_sha256']
# Re-evaluate containment against the actual Blender float32 top cap, not just the host polygons.
tops={}
for o in piers:
 o.data.calc_loop_triangles();v=coords(o)
 tops[o.name]=[[v[i][:2] for i in t.vertices] for t in o.data.loop_triangles if all(abs(v[i][2]-1800)<.001 for i in t.vertices)]
(R/'BLENDER_TOP_CAPS.json').write_text(json.dumps(tops))
subprocess.run(['/usr/bin/python3',str(R/'verify_contacts.py')],check=True)
contact=json.loads((R/'CONTACT_QA.json').read_text());checks.update(contact['checks'])
assert all(checks.values()),checks
bpy.ops.wm.save_as_mainfile(filepath=str(R/'COMPOUND_PIERS_R01.blend'))
def snapshot(obs):
 result={}
 for o in obs:
  v=coords(o);o.data.calc_loop_triangles();tris=[]
  for t in o.data.loop_triangles:
   pts=[tuple(round(v[i][k],3) for k in range(3)) for i in t.vertices]
   tris.append(min(tuple(pts[j:]+pts[:j]) for j in range(3)))
  result[o.name]=dict(bounds=[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]],triangles=sorted(tris))
 return result
snap=snapshot(retained+piers)
bpy.ops.export_scene.gltf(filepath=str(R/'COMPOUND_PIERS_R01.glb'),export_format='GLB',export_cameras=False,export_lights=False)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(R/'COMPOUND_PIERS_R01.glb'))
now=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
checks['glb_object_names_and_count']=set(snap)==set(now)
error=max(abs(snap[n]['bounds'][j][k]-now[n]['bounds'][j][k]) for n in snap for j in range(2) for k in range(3))
checks['glb_world_bounds_within_0_01']=error<.01
checks['glb_oriented_triangle_signatures_at_0_001']=all(snap[n]['triangles']==now[n]['triangles'] for n in snap)
qa=dict(revision='COMPOUND_PIERS_R01_EXPERIMENTAL',source=str(SRC),source_sha256=D['source_sha256'],checks=checks,passed=sum(checks.values()),total=len(checks),source_sections=12,piers=4,added_formeret_responds=4,replaced_source_shafts=8,retained_mesh_objects=len(retained),clear_rectangle_native=section['conservative_clear_rectangle'],contact_metrics=contact['metrics'],roundtrip_bounds_max_error=error,validation=dict(technical='scripts, mesh winding/closure/volume, actual GLB reimport and oriented triangle comparison',geometric='12 actual spring section containment, straight vertical extrusion, protected masonry/vault arrays unchanged, conservative clear rectangle',architectural='experimental 3-bearing chapel bay piers; outside core derived from source backlines; backing masonry retained; no common tas-de-charge added above spring',historical='not assessed; source profile designs are experimental, not authenticated historical traces',structural='not assessed; core sizes/bearing areas and capacities not certified; F5ZL-C schedule unresolved'))
(R/'QA.json').write_text(json.dumps(qa,indent=2));assert all(checks.values()),qa
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX'
scene.render.resolution_x=1100;scene.render.resolution_y=1100;scene.render.resolution_percentage=100
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(25200,-6500,4900));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=6100;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(29800,0,2050))
for loc,power,size in [((28000,-4000,8500),1800000000,5000),((33000,3500,6500),1300000000,4000)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(29800,0,1800))
scene.render.filepath=str(R/'ASSEMBLY.png');bpy.ops.render.render(write_still=True)
for o in scene.objects:
 if o.type=='MESH':o.hide_render=o.name!='COMPOUND_PIER_0'
cam.location=(29300,50,2900);cam.data.ortho_scale=2300;aim(cam,(28600,-1250,900))
scene.render.filepath=str(R/'PIER_DETAIL.png');bpy.ops.render.render(write_still=True)
print('RESULT',json.dumps(qa))
