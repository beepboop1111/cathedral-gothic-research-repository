import json,pathlib,math,collections
from shapely.geometry import Polygon,MultiPoint,box
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles
from shapely.geometry.polygon import orient
R=pathlib.Path(__file__).resolve().parent
D=json.loads((R/'SPRING_SECTIONS.json').read_text())
out=[];checks={};measurements={};unions={}
for nodeid,node in D['nodes'].items():
 x,y=node['node'];sign=1 if y>0 else -1;polys=[];backs=[]
 for sec in node['sections']:
  p=Polygon(sec['polygon']);assert p.is_valid and p.area>0,sec['name'];polys.append(p)
  h=sec['direction'];depth=[(a-x)*h[0]+(b-y)*h[1] for a,b in sec['polygon']];minimum=min(depth)
  backs.extend([pt for pt,d in zip(sec['polygon'],depth) if d<=minimum+.003])
 xmin,xmax=min(p[0] for p in backs),max(p[0] for p in backs)
 half=max(x-xmin,xmax-x)
 # Core comes after source-section overlay; it stays in the existing outside wall reservation.
 core=MultiPoint(backs+[[x-half*.75,y+sign*320],[x+half*.75,y+sign*320]]).convex_hull
 core=core.intersection(box(x-220,min(y,y+sign*320),x+220,max(y,y+sign*320)))
 profiles=unary_union(polys);whole=unary_union([profiles,core])
 assert whole.geom_type=='Polygon' and whole.is_valid
 checks['pier'+nodeid+'_three_source_bearings']=len(polys)==3
 checks['pier'+nodeid+'_all_sections_received']=all(p.difference(whole).area<.001 for p in polys)
 checks['pier'+nodeid+'_core_outside_vault_reservation']=core.intersection(box(28600,-1250,31000,1250)).area<.001
 checks['pier'+nodeid+'_connected_section']=whole.geom_type=='Polygon'
 p=orient(whole,sign=1);v=[];index={};faces=[]
 def vertex(a,b,level):
  key=(float(a),float(b),0. if level==0 else 1800.)
  if key not in index:index[key]=len(v);v.append(key)
  return index[key]
 tris=list(constrained_delaunay_triangles(p).geoms)
 assert abs(sum(t.area for t in tris)-p.area)<.001
 for t in tris:
  co=list(orient(t,sign=1).exterior.coords)[:-1]
  faces.extend([list(reversed([vertex(a,b,0) for a,b in co])),[vertex(a,b,1) for a,b in co]])
 for loop in [p.exterior,*p.interiors]:
  co=list(loop.coords)
  for a,b in zip(co,co[1:]):faces.append([vertex(*a,0),vertex(*b,0),vertex(*b,1),vertex(*a,1)])
 unions[nodeid]=p
 out.append(dict(name='COMPOUND_PIER_'+nodeid,vertices=v,faces=faces,section=list(p.exterior.coords),core=list(core.exterior.coords),node=[x,y],bearings=[s['bearing_degrees'] for s in node['sections']]))
 measurements[nodeid]=dict(node=[x,y],bearings=[s['bearing_degrees'] for s in node['sections']],source_profile_union_area=profiles.area,core_area=core.area,compound_area=p.area,section_bounds=list(p.bounds),core_rule='convex hull of actual section backing points and two outward anchors; clipped to prior 320-deep reservation')
# Conservative clear rectangle between the four complete section bounding boxes.
clearx=min(unions['1'].bounds[0],unions['2'].bounds[0])-max(unions['0'].bounds[2],unions['3'].bounds[2])
cleary=min(unions['2'].bounds[1],unions['3'].bounds[1])-max(unions['0'].bounds[3],unions['1'].bounds[3])
checks['positive_clear_longitudinal_gap']=clearx>0
checks['positive_clear_transverse_gap']=cleary>0
checks['pairwise_piers_disjoint']=all(unions[str(a)].intersection(unions[str(b)]).area<.001 for a in range(4) for b in range(a+1,4))
report=dict(checks=checks,piers=measurements,conservative_clear_rectangle=[clearx,cleary],units='native project units, numerical 1:1; physical SI unresolved',basis='three actual R04-source profiles per bay corner; NOT Pass6J representative eight-bearing pier')
(R/'PIER_MESHES.json').write_text(json.dumps(out,separators=(',',':')))
(R/'SECTION_QA.json').write_text(json.dumps(report,indent=2))
# Measurable local SVG: black source profiles, dashed gray axes, dashed red experimental core.
p=out[0];x,y=p['node']
def path(poly):return 'M '+' L '.join(str(a-x)+','+str(-(b-y)) for a,b in poly)+' Z'
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="-180 -200 400 580" width="600" height="870">']
svg.append('<g fill="none" stroke="#999" stroke-width="0.8" stroke-dasharray="4 4"><path d="M -180 0 L 220 0 M 0 -200 L 0 380"/></g>')
svg.append('<path d="'+path(p['core'])+'" fill="#e6d6bd" fill-opacity=".5" stroke="#b33" stroke-width="1" stroke-dasharray="4 3"/>')
for s in D['nodes']['0']['sections']:svg.append('<path d="'+path(s['polygon'])+'" fill="none" stroke="black" stroke-width="1.2"/>')
svg.append('</svg>');(R/'PIER_0_SECTION_NATIVE.svg').write_text(''.join(svg))
assert all(checks.values()),report
print('SECTIONS_READY',clearx,cleary)
