import json,pathlib
from shapely.geometry import Polygon,Point
from shapely.ops import unary_union
R=pathlib.Path(__file__).resolve().parent
D=json.loads((R/'SPRING_SECTIONS.json').read_text());tops=json.loads((R/'BLENDER_TOP_CAPS.json').read_text());checks={};metrics={}
for i,node in D['nodes'].items():
 cap=unary_union([Polygon(t) for t in tops['COMPOUND_PIER_'+i]]);errors=[]
 for s in node['sections']:
  p=Polygon(s['polygon'])
  # Vertex + independently sampled boundary containment against exported-to-Blender top triangles.
  pts=[p.exterior.interpolate(p.exterior.length*j/300) for j in range(301)]
  maxgap=max(cap.distance(q) for q in pts)
  errors.append(dict(source=s['name'],bearing=s['bearing_degrees'],max_boundary_gap=maxgap,unreceived_area=p.difference(cap).area))
  checks['pier'+i+'_'+s['name']+'_cap_gap_within_0_005']=maxgap<=.005
 metrics[i]=errors
(R/'CONTACT_QA.json').write_text(json.dumps(dict(checks=checks,metrics=metrics),indent=2))
assert all(checks.values()),metrics
