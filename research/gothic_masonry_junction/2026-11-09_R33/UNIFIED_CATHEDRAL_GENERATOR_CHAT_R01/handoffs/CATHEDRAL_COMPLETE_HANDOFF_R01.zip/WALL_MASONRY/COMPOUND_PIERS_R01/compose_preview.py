from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
p=Path('/home/christopher/Documents/Cathedral/experimental/COMPOUND_PIERS_R01')
q=json.loads((p/'QA.json').read_text());D=json.loads((p/'SPRING_SECTIONS.json').read_text());m=json.loads((p/'PIER_MESHES.json').read_text())[0];x,y=m['node']
fig,ax=plt.subplots(figsize=(6.4,3.2),dpi=150)
fig.patch.set_facecolor('#eeeae2');ax.set_facecolor('#eeeae2')
for sec in D['nodes']['0']['sections']:
 a,b=zip(*(sec['polygon']+[sec['polygon'][0]]));ax.plot([v-x for v in a],[v-y for v in b],color='black',linewidth=1.0)
a,b=zip(*m['core']);ax.fill([v-x for v in a],[v-y for v in b],color='#d8c7ac',alpha=.45)
ax.plot([v-x for v in a],[v-y for v in b],color='#b33',linewidth=1,linestyle='--',label='Experimental core')
ax.axhline(0,color='#999',linewidth=.6,linestyle='--');ax.axvline(0,color='#999',linewidth=.6,linestyle='--')
ax.set_aspect('equal');ax.set_xlim(-160,225);ax.set_ylim(-350,175);ax.tick_params(labelsize=7)
ax.set_xlabel('Local X / native units',fontsize=8);ax.set_ylabel('Local Y',fontsize=8)
ax.set_title('SPRING SECTION / black: source profiles; red: trial core',fontsize=9)
fig.tight_layout();fig.savefig(p/'SECTION.png',facecolor=fig.get_facecolor());plt.close(fig)
im=Image.new('RGB',(1600,1100),'#eeeae2');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font=ImageFont.truetype(f,25);small=ImageFont.truetype(f,17)
d.text((26,16),'COMPOUND PIER GENERATOR / R01 EXPERIMENTAL',fill='#28251f',font=font)
d.text((26,53),'4 piers | 3 actual bearings per corner | ribs, webs and masonry retained | native scale 1:1',fill='#49443b',font=small)
a=Image.open(p/'ASSEMBLY.png').convert('RGB');a.thumbnail((930,930));im.paste(a,(10,95))
a=Image.open(p/'PIER_DETAIL.png').convert('RGB');a.thumbnail((630,600));im.paste(a,(975,85))
a=Image.open(p/'SECTION.png').convert('RGB');a.thumbnail((640,320));im.paste(a,(950,725))
d.text((26,1040),'COMPLETE BAY - existing masonry backing remains unchanged',fill='#28251f',font=small)
d.text((968,698),'ISOLATED PIER - unified core and three responds',fill='#28251f',font=small)
d.text((26,1070),str(q['passed'])+'/'+str(q['total'])+' technical/geometric checks | architectural review pending | historical and structural validation not performed',fill='#49443b',font=small)
im.save(p/'COMPOUND_PIERS_R01_RESULT.png')
print(json.dumps(dict(passed=q['passed'],total=q['total'],retained=q['retained_mesh_objects'],clear_rectangle=q['clear_rectangle_native'],max_cap_gap=max(z['max_boundary_gap'] for v in q['contact_metrics'].values() for z in v))))
