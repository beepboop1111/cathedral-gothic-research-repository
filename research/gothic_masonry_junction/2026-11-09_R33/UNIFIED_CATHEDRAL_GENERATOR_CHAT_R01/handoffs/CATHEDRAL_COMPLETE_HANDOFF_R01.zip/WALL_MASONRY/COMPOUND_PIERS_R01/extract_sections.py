import bpy,json,pathlib,hashlib,math
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/MASONRY_STONES_R01/MASONRY_STONES_R01.blend')
bpy.ops.wm.open_mainfile(filepath=str(S))
nodes=[(28600.,-1250.),(31000.,-1250.),(31000.,1250.),(28600.,1250.)]
groups={str(i):dict(node=list(p),sections=[]) for i,p in enumerate(nodes)}
names=['BAY1_RIB_'+str(i) for i in range(4)]+['BAY1_FORMERET_0','BAY1_FORMERET_2','ENTRANCE_ORDER_4','CHAPEL_TRANSVERSE_31000']
for name in names:
 o=bpy.data.objects[name];pts=[tuple(o.matrix_world@v.co) for v in o.data.vertices]
 matches={i:[] for i in range(4)}
 for index,p in enumerate(pts):
  if abs(p[2]-1800.)<.002:
   ni=min(range(4),key=lambda i:math.dist(p[:2],nodes[i]))
   if math.dist(p[:2],nodes[ni])<300:matches[ni].append((index,list(p[:2])))
 for ni,arr in matches.items():
  if len(arr)<3:continue
  center=nodes[ni]
  if 'RIB' in name:target=(29800.,0.)
  elif 'FORMERET' in name:target=(31000. if center[0]==28600 else 28600.,center[1])
  else:target=(center[0],-center[1])
  h=Vector((target[0]-center[0],target[1]-center[1]));h.normalize()
  groups[str(ni)]['sections'].append(dict(name=name,polygon=[p for j,p in arr],bearing_degrees=math.degrees(math.atan2(h.y,h.x)),direction=list(h)))
data=dict(source=str(S),source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),spring=1800.,nodes=groups)
(R/'SPRING_SECTIONS.json').write_text(json.dumps(data,indent=2))
print(json.dumps({k:dict(node=v['node'],profiles=[dict(name=s['name'],vertices=len(s['polygon']),bearing=s['bearing_degrees']) for s in v['sections']]) for k,v in groups.items()}))
