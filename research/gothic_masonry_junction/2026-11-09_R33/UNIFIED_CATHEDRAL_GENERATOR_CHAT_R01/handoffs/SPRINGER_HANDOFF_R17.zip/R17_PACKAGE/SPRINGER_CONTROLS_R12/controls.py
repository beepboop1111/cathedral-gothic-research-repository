#!/usr/bin/env python3
"""Copy and validate explicit edits to one experimental springer manifest."""
import argparse,copy,hashlib,json,math,pathlib,sys
CORE=pathlib.Path(__file__).resolve().parent.parent/'SPRINGER_ENGINE_R06';sys.path.insert(0,str(CORE));import springer_core as engine

def pairs(values,label):
 out={}
 for x in values:
  if '=' not in x:raise ValueError(f'{label}: use MEMBER=VALUE')
  k,v=x.split('=',1)
  if not k or not v or k in out:raise ValueError(f'{label}: empty or repeated member')
  out[k]=v
 return out

def configure(src,library,bearings,carriers,levels,spring,backing):
 c=copy.deepcopy(src);before=copy.deepcopy(src);members={m['id']:m for m in c['members']}
 if len(members)!=len(c['members']):raise ValueError('Duplicate IDs in source')
 if spring is not None and (not math.isfinite(spring) or abs(spring-c['spring'])>1e-8):raise ValueError('Changing spring elevation requires transformed source geometry; this tool does not move it')
 for ident,value in bearings.items():
  if ident not in members or members[ident]['kind']!='sweep':raise ValueError(f'{ident}: bearing requires a sweep member; mesh bearings cannot be edited here')
  v=float(value)
  if not math.isfinite(v):raise ValueError('Bearing must be finite')
  members[ident]['bearing_degrees']=v
 for ident,value in carriers.items():
  if ident not in members or members[ident]['kind']!='sweep':raise ValueError(f'{ident}: carrier requires a sweep member')
  if value not in library['carriers']:raise ValueError(f'Unknown carrier {value}')
  members[ident]['carrier_ref']=value
 if levels is not None:
  levels=[float(x) for x in levels]
  if len(levels)<2 or any(not math.isfinite(x) for x in levels) or any(a>=b for a,b in zip(levels,levels[1:])):raise ValueError('Course elevations must be finite and strictly increasing')
  if abs(levels[0]-before['course_levels'][0])>1e-8 or abs(levels[-1]-before['course_levels'][-1])>1e-8:raise ValueError('Course endpoints must match the existing spring and study region; source geometry is not shifted')
  c['course_levels']=levels
 if backing is not None:
  if backing=='none':c.pop('backing',None)
  elif backing not in library['meshes']:raise ValueError(f'Unknown backing mesh {backing}')
  else:c['backing']={'mesh_key':backing}
 engine.validate_manifest(c)
 for m in c['members']:
  if m['kind']=='sweep':
   if m['section_ref'] not in library['sections']:raise ValueError('Unknown section '+m['section_ref'])
   carrier=library['carriers'].get(m['carrier_ref'])
   if carrier is None or 'bearing_degrees' not in carrier:raise ValueError('Carrier must declare its original bearing')
   engine.resolve_member(m,library)
  elif m['mesh_key'] not in library['meshes']:raise ValueError('Unknown mesh '+m['mesh_key'])
 c.pop('change',None)
 c['controls_change']={'bearing_edits':bearings,'carrier_edits':carriers,'course_levels_before':before['course_levels'],'course_levels_after':c['course_levels'],'spring':c['spring'],'backing_before':before.get('backing'),'backing_after':c.get('backing'),'note':'experimental; spring/source geometry not moved; mesh bearings unchanged'}
 return c

def main():
 p=argparse.ArgumentParser();p.add_argument('--fixture',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);p.add_argument('--bearing',action='append',default=[],metavar='MEMBER=DEGREES');p.add_argument('--carrier',action='append',default=[],metavar='MEMBER=KEY');p.add_argument('--courses',nargs='+');p.add_argument('--spring',type=float);p.add_argument('--backing',help='existing mesh key, or none');a=p.parse_args();src=json.loads(a.fixture.read_text());libpath=pathlib.Path(src['input_library']);libpath=(a.fixture.parent/libpath).resolve() if not libpath.is_absolute() else libpath.resolve();lib=json.loads(libpath.read_text());result=configure(src,lib,pairs(a.bearing,'bearing'),pairs(a.carrier,'carrier'),a.courses,a.spring,a.backing);result['input_library']=str(libpath);result['controls_change']['source_manifest_sha256']=hashlib.sha256(a.fixture.read_bytes()).hexdigest();a.out.parent.mkdir(parents=True,exist_ok=True)
 with a.out.open('x') as f:json.dump(result,f,indent=2)
 print(json.dumps(result['controls_change'],indent=2));print('New manifest:',a.out)
if __name__=='__main__':
 try:main()
 except (ValueError,KeyError,OSError,TypeError) as e:print('CONTROLS ERROR:',e,file=sys.stderr);sys.exit(2)
