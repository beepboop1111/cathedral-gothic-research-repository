from pathlib import Path
import sys,json
import springer_core as core
out=Path(sys.argv[1]);raw=json.loads((out/'raw_geometry.json').read_text())
mesh,report=core.fill_pockets(raw['common'],progress=lambda a,b:print('POCKET_INTERVAL',a,b,flush=True))
(out/'filled_mesh.json').write_text(json.dumps(mesh));(out/'FILL_REPORT.json').write_text(json.dumps(report,indent=2))
print('FILLED_CORE_READY',flush=True)
