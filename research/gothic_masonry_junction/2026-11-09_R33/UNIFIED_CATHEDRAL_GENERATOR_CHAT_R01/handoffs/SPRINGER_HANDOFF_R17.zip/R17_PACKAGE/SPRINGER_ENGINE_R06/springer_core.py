import collections
import numpy as np
import shapely
from shapely.geometry import Polygon,Point,LineString
from shapely.ops import unary_union,polygonize
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles
def polygon_parts(g):
    if g.is_empty:return []
    if g.geom_type=='Polygon':return [g]
    return [p for a in g.geoms for p in polygon_parts(a)]
def fill_pockets(triangles,progress=None):
    tri=np.asarray(triangles,float)
    if tri.ndim!=3 or tri.shape[1:]!=(3,3) or not np.isfinite(tri).all():raise ValueError('Expected finite Nx3x3 triangles')
    mins=tri[:,:,2].min(axis=1);maxs=tri[:,:,2].max(axis=1);levels=np.unique(tri[:,:,2]);runs=[[] for _ in tri];last=np.full(len(tri),-2,int)
    def parts(g):
     if g.is_empty:return []
     if g.geom_type=='Polygon':return [g]
     return [p for a in g.geoms for p in parts(a)]
    def horizontal(z):
     ids=np.flatnonzero((mins<z)&(maxs>z));ts=tri[ids];a=ts;b=np.roll(ts,-1,axis=1)
     mask=(a[:,:,2]<z)&(b[:,:,2]>z)|(a[:,:,2]>z)&(b[:,:,2]<z)
     rows,cols=np.nonzero(mask);aa=a[rows,cols];bb=b[rows,cols];f=(z-aa[:,2])/(bb[:,2]-aa[:,2])
     pts=np.round(aa[:,:2]+f[:,None]*(bb[:,:2]-aa[:,:2]),7).reshape(-1,2,2)
     assert len(pts)==len(ids)
     candidates=list(polygonize(unary_union(shapely.linestrings(pts))))
     aa=pts[:,0];bb=pts[:,1]
     good=[]
     for p in candidates:
      q=p.representative_point();cross=(aa[:,1]>q.y)!=(bb[:,1]>q.y)
      x=aa[cross,0]+(q.y-aa[cross,1])*(bb[cross,0]-aa[cross,0])/(bb[cross,1]-aa[cross,1])
      if len(np.unique(np.round(x[x>q.x],6)))%2:good.append(p)
     g=unary_union(good)
     assert not g.is_empty,z
     outer=unary_union([p.exterior for p in parts(g)])
     midpoint=pts.mean(axis=1)
     dist=shapely.distance(shapely.points(midpoint),outer)
     return ids[dist<.00001],g
    for k,(lo,hi) in enumerate(zip(levels,levels[1:])):
     ids,g=horizontal((lo+hi)/2)
     for i in ids:
      if last[i]==k-1:runs[i][-1][1]=float(hi)
      else:runs[i].append([float(lo),float(hi)])
      last[i]=k
     if progress and k%250==0:progress(k,len(levels)-1)
    critical=set()
    for i,spans in enumerate(runs):
     for lo,hi in spans:
      if lo>mins[i]+1e-6:critical.add(lo)
      if hi<maxs[i]-1e-6:critical.add(hi)
    critical=sorted(critical)
    def clip(poly,z,above):
     result=[]
     for a,b in zip(poly,poly[1:]+poly[:1]):
      ina=a[2]>=z-1e-10 if above else a[2]<=z+1e-10;inb=b[2]>=z-1e-10 if above else b[2]<=z+1e-10
      if ina:result.append(a)
      if ina!=inb:
       f=(z-a[2])/(b[2]-a[2]);result.append([a[0]+f*(b[0]-a[0]),a[1]+f*(b[1]-a[1]),z])
     return result
    vertices=[];lookup={};faces=[];original_triangles_retained=0
    def vertex(v):
     key=tuple(round(float(x),7) for x in v)
     if key not in lookup:lookup[key]=len(vertices);vertices.append(list(key))
     return lookup[key]
    for i,spans in enumerate(runs):
     for lo,hi in spans:
      cuts=[lo]+[z for z in critical if lo+1e-7<z<hi-1e-7]+[hi]
      for a,b in zip(cuts,cuts[1:]):
       p=clip(clip(tri[i].tolist(),a,True),b,False)
       ids=[vertex(v) for v in p];ids=[x for j,x in enumerate(ids) if j==0 or x!=ids[j-1]]
       if len(ids)>1 and ids[0]==ids[-1]:ids.pop()
       for j in range(1,len(ids)-1):
        if len({ids[0],ids[j],ids[j+1]})==3:faces.append([ids[0],ids[j],ids[j+1]])
    counts=collections.Counter()
    for f in faces:
     for a,b in zip(f,f[1:]+f[:1]):counts[tuple(sorted((a,b)))]+=1
    boundary=[e for e,n in counts.items() if n==1]
    nonhorizontal=[e for e in boundary if abs(vertices[e[0]][2]-vertices[e[1]][2])>1e-5]
    report=dict(method='Exact source-triangle exterior classification in every vertex-height interval; split only at topological pocket/recess transitions; no outer contour interpolation',intervals=len(levels)-1,critical_levels=critical,source_triangles=len(tri),inner_triangles_removed=sum(not a for a in runs),side_triangles=len(faces),boundary_edges=len(boundary),nonhorizontal_boundary_edges=len(nonhorizontal),nonhorizontal_examples=[[vertices[i] for i in e] for e in nonhorizontal[:10]])
    return dict(vertices=vertices,faces=faces),report

def section_geometry(triangles,z):
    tri=np.asarray(triangles,float)
    mins=tri[:,:,2].min(axis=1);maxs=tri[:,:,2].max(axis=1)
    def parts(g):
     if g.is_empty:return []
     if g.geom_type=='Polygon':return [g]
     return [p for a in g.geoms for p in parts(a)]
    def horizontal(z):
     ids=np.flatnonzero((mins<z)&(maxs>z));ts=tri[ids];a=ts;b=np.roll(ts,-1,axis=1)
     mask=(a[:,:,2]<z)&(b[:,:,2]>z)|(a[:,:,2]>z)&(b[:,:,2]<z)
     rows,cols=np.nonzero(mask);aa=a[rows,cols];bb=b[rows,cols];f=(z-aa[:,2])/(bb[:,2]-aa[:,2])
     pts=np.round(aa[:,:2]+f[:,None]*(bb[:,:2]-aa[:,:2]),7).reshape(-1,2,2)
     assert len(pts)==len(ids)
     candidates=list(polygonize(unary_union(shapely.linestrings(pts))))
     aa=pts[:,0];bb=pts[:,1]
     good=[]
     for p in candidates:
      q=p.representative_point();cross=(aa[:,1]>q.y)!=(bb[:,1]>q.y)
      x=aa[cross,0]+(q.y-aa[cross,1])*(bb[cross,0]-aa[cross,0])/(bb[cross,1]-aa[cross,1])
      if len(np.unique(np.round(x[x>q.x],6)))%2:good.append(p)
     g=unary_union(good)
     assert not g.is_empty,z
     outer=unary_union([p.exterior for p in parts(g)])
     midpoint=pts.mean(axis=1)
     dist=shapely.distance(shapely.points(midpoint),outer)
     return ids[dist<.00001],g
    return horizontal(z)[1]

def cap_geometry(triangles,height,tolerance=.0001):
    return unary_union([Polygon([p[:2] for p in t]) for t in triangles if all(abs(p[2]-height)<tolerance for p in t)])
def vertical_prism(poly,lo,hi):
    poly=orient(poly,sign=1);vertices=[];lookup={};faces=[]
    def vertex(x,y,k):
        key=(float(x),float(y),float(hi if k else lo))
        if key not in lookup:lookup[key]=len(vertices);vertices.append(key)
        return lookup[key]
    for t in constrained_delaunay_triangles(poly).geoms:
        pts=list(orient(t,sign=1).exterior.coords)[:-1]
        faces.extend([list(reversed([vertex(x,y,0) for x,y in pts])),[vertex(x,y,1) for x,y in pts]])
    for ring in [poly.exterior,*poly.interiors]:
        pts=list(ring.coords)
        for a,b in zip(pts,pts[1:]):faces.append([vertex(*a,0),vertex(*b,0),vertex(*b,1),vertex(*a,1)])
    return dict(vertices=vertices,faces=faces)
def profile_sweep(points,centers,width_axes,depth_axes,bearing_degrees=0):
    p=np.asarray(points,float)
    if p.ndim!=2 or p.shape[1]!=2 or not np.isfinite(p).all():raise ValueError('Profile must be Nx2')
    if np.linalg.norm(p[0]-p[-1])<1e-10:p=p[:-1]
    poly=Polygon(p)
    if not poly.is_valid or poly.area<=1e-8 or poly.interiors:raise ValueError('Expected one valid solid closed outer section')
    p=np.array(orient(poly,sign=1).exterior.coords[:-1])
    c=np.asarray(centers,float);w=np.asarray(width_axes,float);d=np.asarray(depth_axes,float)
    if c.ndim!=2 or c.shape[1]!=3 or c.shape!=w.shape or c.shape!=d.shape or len(c)<2 or not all(np.isfinite(a).all() for a in (c,w,d)):raise ValueError('Carrier centers and axes must share Nx3 shape')
    if max(np.abs(np.linalg.norm(w,axis=1)-1).max(),np.abs(np.linalg.norm(d,axis=1)-1).max(),np.abs(np.sum(w*d,axis=1)).max())>1e-5:raise ValueError('Carrier axes must be orthonormal')
    if not np.isfinite(bearing_degrees):raise ValueError('Bearing must be finite degrees')
    if np.any(np.sum(w[1:]*w[:-1],axis=1)<0) or np.any(np.sum(d[1:]*d[:-1],axis=1)<0):raise ValueError('Carrier frame reverses between stations')
    angle=np.deg2rad(bearing_degrees);r=np.array([[np.cos(angle),-np.sin(angle),0],[np.sin(angle),np.cos(angle),0],[0,0,1]])
    anchor=c[0].copy();c=(c-anchor)@r.T+anchor;w=w@r.T;d=d@r.T
    vertices=(c[:,None,:]+p[None,:,0,None]*w[:,None,:]+p[None,:,1,None]*d[:,None,:]).reshape(-1,3).tolist()
    n=len(p);faces=[]
    for i in range(len(c)-1):
        for j in range(n):faces.append([i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j])
    lookup={tuple(q):i for i,q in enumerate(p)}
    for t in constrained_delaunay_triangles(Polygon(p)).geoms:
        ids=[lookup[tuple(q)] for q in list(orient(t,sign=1).exterior.coords)[:-1]]
        faces.extend([list(reversed(ids)),[(len(c)-1)*n+j for j in ids]])
    return dict(vertices=vertices,faces=faces),dict(profile_area=Polygon(p).area,profile_bounds=list(Polygon(p).bounds),bearing_rotation_degrees=bearing_degrees,stations=len(c))
def validate_manifest(config):
    if config.get('axes')!='Z_UP':raise ValueError('Normalize source coordinates to canonical Z_UP explicitly')
    levels=np.asarray(config['course_levels'],float)
    if len(levels)<2 or not np.isfinite(levels).all() or np.any(np.diff(levels)<=0):raise ValueError('Course levels must increase')
    region=np.asarray(config['study_region'],float)
    if region.shape!=(6,) or not np.isfinite(region).all() or any(region[i]>=region[i+1] for i in (0,2,4)):raise ValueError('Expected finite ordered XYZ bounds')
    if abs(levels[0]-region[4])>1e-8 or abs(levels[-1]-region[5])>1e-8 or abs(levels[0]-config['spring'])>1e-8:raise ValueError('Course range, region and spring must agree')
    if not config['members'] or len({m['id'] for m in config['members']})!=len(config['members']):raise ValueError('Member IDs must be nonempty and unique')
    if any(m['kind'] not in ('mesh','sweep') for m in config['members']):raise ValueError('Unknown member input kind')
    return levels.tolist()
def resolve_member(spec,library):
    if spec['kind']=='mesh':return library['meshes'][spec['mesh_key']],dict(kind='mesh')
    carrier=library['carriers'][spec['carrier_ref']]
    return profile_sweep(library['sections'][spec['section_ref']],carrier['centers'],carrier['width_axes'],carrier['depth_axes'],spec.get('bearing_degrees',carrier.get('bearing_degrees',0))-carrier.get('bearing_degrees',0))
