import unittest,json
import numpy as np
from shapely.geometry import Polygon
import springer_core as core
def triangulate(mesh):
    v=np.asarray(mesh['vertices'],float)
    return np.array([[v[f[0]],v[f[i]],v[f[i+1]]] for f in mesh['faces'] for i in range(1,len(f)-1)])
class GeometryContract(unittest.TestCase):
    def config(self,count=3):
        return dict(axes='Z_UP',spring=0,course_levels=[0,5,10],study_region=[-10,10,-10,10,0,10],members=[dict(id=str(i),kind='mesh') for i in range(count)])
    def test_member_counts_are_not_fixed(self):
        for n in [2,5,8]:self.assertEqual(core.validate_manifest(self.config(n)),[0,5,10])
    def test_bad_joint_order_rejected(self):
        c=self.config();c['course_levels']=[0,7,6,10]
        with self.assertRaises(ValueError):core.validate_manifest(c)
    def test_coordinate_axis_must_be_explicit(self):
        c=self.config();c['axes']='Y_UP'
        with self.assertRaises(ValueError):core.validate_manifest(c)
    def test_duplicate_member_identity_rejected(self):
        c=self.config();c['members'][1]['id']='0'
        with self.assertRaises(ValueError):core.validate_manifest(c)
    def test_vector_profile_sweep_and_bearing(self):
        p=[[-1,0],[1,0],[1,3],[-1,3]];c=[[0,0,0],[0,0,10]];w=[[1,0,0]]*2;d=[[0,1,0]]*2
        mesh,meta=core.profile_sweep(p,c,w,d,90)
        t=triangulate(mesh);volume=np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6
        self.assertAlmostEqual(volume,60)
        self.assertAlmostEqual(meta['profile_area'],6)
        self.assertLess(np.linalg.norm(np.asarray(mesh['vertices'][0])-[0,-1,0]),1e-10)
    def test_profile_self_intersection_rejected(self):
        with self.assertRaises(ValueError):core.profile_sweep([[0,0],[1,1],[0,1],[1,0]],[[0,0,0],[0,0,1]],[[1,0,0]]*2,[[0,1,0]]*2)
    def test_orthogonal_frame_required(self):
        with self.assertRaises(ValueError):core.profile_sweep([[0,0],[1,0],[0,1]],[[0,0,0],[0,0,1]],[[1,0,0]]*2,[[1,0,0]]*2)
    def test_pocket_filling_retains_external_section(self):
        poly=Polygon([[-2,-2],[2,-2],[2,2],[-2,2]],[ [[-1,-1],[-1,1],[1,1],[1,-1]] ])
        original=triangulate(core.vertical_prism(poly,0,10));mesh,report=core.fill_pockets(original)
        filled=core.section_geometry(triangulate(mesh),5)
        self.assertAlmostEqual(filled.area,16)
        self.assertEqual(len(filled.interiors),0)
        self.assertAlmostEqual(filled.exterior.hausdorff_distance(poly.exterior),0)
        self.assertGreater(report['inner_triangles_removed'],0)
if __name__=='__main__':unittest.main()
