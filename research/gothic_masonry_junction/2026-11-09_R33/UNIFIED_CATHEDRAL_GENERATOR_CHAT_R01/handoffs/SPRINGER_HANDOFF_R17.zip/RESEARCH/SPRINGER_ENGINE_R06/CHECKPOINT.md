# R06 checkpoint

Status: reusable experimental input engine completed and locally packaged; no promotion of a generator or architecture.
Preserved: approved cathedral geometry, F5ZK-C/F5ZN-A, original source profiles/generators, Pass6J records, R04 and R05 saved files. Hash-preservation checks pass. Missing F5ZL-C support schedule unresolved. Native numerical1:1; normalized Z_UP; no physical SI conversion inferred.

Accepted test: changed_case_03. Inputs: four reused saved mesh members, one closed-vector/carrier member with0.90 width factor,1.05 depth factor and+8-degree bearing change. Course inputs changed explicitly to local Z0–600/five120-unit beds. R04/R05 are comparison references, not rewritten.

Validation:92 fixture checks and8 API regression tests passed. All four internal beds: contact fraction1 within floating arithmetic, unsupported area0, cap symmetric difference0. Base full contact. Actual top profile boundary gap0.0000052931 native unit, uncovered area0.0000294611 square native units. GLB export/reimport bounds error0; oriented triangle signatures checked at0.0001.61 section preservation/pocket tests passed. Original four reused input dictionaries remain exact; source files retain SHA256 identities.

Technical: scripts/API guards, source-frame recovery, topology/positive volume, course reconstruction, GLB export/reimport.
Geometric: modified input contours/bearing, pocket removal, independent bedding/base/rib contacts and source-vs-filled exterior checks.
Architectural: isolated experimental fixture; no cathedral fit/adoption, course-size or pier-design approval.
Historical: not assessed; changed profile is derived experimental geometry, not an authenticated historical trace.
Structural: not assessed; bearing stress, load paths, masonry capacities and F5ZL-C data unresolved.

Runtime public API, schema, requirements and reproduction are in README.md. Failed setup folders01/02 are not accepted results. Staged processing was used to avoid regenerating already-validated geometry. A missing import, a frame-extraction precision issue, per-course Boolean instability and a render-world default were corrected; final artifacts pass the stated checks. The reusable course stage now uses shared bed-plane partitioning. The CLI orchestration wrapper compiles; its constituent stages were exercised on the accepted fixture without repeating a full fresh wrapper build.

One comparison PNG visually inspected: R05 archived reference, R06 GLB render, changed vector contour and metrics. No GitHub operations. All source/tests/JSON/.blend/.glb retained in this directory; only PNG uploaded. Next scope is another genuinely different profile family or a different actual bearing network, with fresh geometric validation and no assumption of architectural approval.
