import pathlib,textwrap,json,bpy
ROOT=pathlib.Path(__file__).resolve().parent
s=(ROOT/'blender_runner.py').read_text()
exec(s.split("if stage=='raw':")[0])
qa=json.loads((OUT/'QA.json').read_text())
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(OUT/'springer_variant.glb'))
exec(textwrap.dedent(s[s.index(' # Crop imported geometry'):]))
