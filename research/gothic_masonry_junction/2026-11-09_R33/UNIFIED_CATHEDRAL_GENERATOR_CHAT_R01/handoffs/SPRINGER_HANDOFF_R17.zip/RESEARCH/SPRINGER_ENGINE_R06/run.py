from pathlib import Path
import argparse,json,subprocess,hashlib,sys
import springer_core as core
def prepare(manifest_path,output):
    manifest_path=Path(manifest_path).resolve();config=json.loads(manifest_path.read_text());core.validate_manifest(config)
    library_path=(manifest_path.parent/config['input_library']).resolve();library=json.loads(library_path.read_text())
    members=[];metadata={}
    for spec in config['members']:
        mesh,info=core.resolve_member(spec,library);members.append(dict(id=spec['id'],mesh=mesh));metadata[spec['id']]=info
    config['input_library']=str(library_path)
    output=Path(output).resolve();output.mkdir(parents=True,exist_ok=False)
    data=dict(members=members,backing=library['meshes'][config['backing']['mesh_key']] if config.get('backing') else None,metadata=metadata,source_files=library.get('source_files',[]))
    (output/'config.json').write_text(json.dumps(config,indent=2));(output/'resolved_inputs.json').write_text(json.dumps(data))
    (output/'INPUT_QA.json').write_text(json.dumps(dict(checks=dict(manifest_valid=True,all_member_inputs_resolved=True),input_library_sha256=hashlib.sha256(library_path.read_bytes()).hexdigest()),indent=2))
    return output
def main():
    parser=argparse.ArgumentParser();parser.add_argument('manifest');parser.add_argument('--out',required=True);parser.add_argument('--blender',default='blender');parser.add_argument('--threads',type=int,default=4);args=parser.parse_args()
    out=prepare(args.manifest,args.out);root=Path(__file__).resolve().parent
    commands=[([args.blender,'-b','-t',str(args.threads),'--python',str(root/'blender_runner.py'),'--','raw',str(out)],'RAW_BUILD.log'),([sys.executable,str(root/'fill_case.py'),str(out)],'FILL.log'),([args.blender,'-b','-t',str(args.threads),'--python',str(root/'blender_runner.py'),'--','finish',str(out)],'FINISH.log')]
    for command,log in commands:
        with (out/log).open('w') as stream:subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True)
    print(out/'QA.json')
if __name__=='__main__':
    import sys
    main()
