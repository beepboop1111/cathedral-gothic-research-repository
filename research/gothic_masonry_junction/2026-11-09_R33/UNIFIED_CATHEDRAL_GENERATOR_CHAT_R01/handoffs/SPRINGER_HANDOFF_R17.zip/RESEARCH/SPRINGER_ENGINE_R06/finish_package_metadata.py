from pathlib import Path
import json,py_compile,hashlib
R=Path('/home/christopher/Documents/Cathedral/experimental/SPRINGER_ENGINE_R06')
p=R/'run.py';s=p.read_text().replace('import argparse,json,subprocess,hashlib','import argparse,json,subprocess,hashlib,sys').replace("    output=Path(output).resolve();output.mkdir", "    config['input_library']=str(library_path)\n    output=Path(output).resolve();output.mkdir");p.write_text(s)
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','title':'Springer engine input manifest','type':'object','required':['schema_version','axes','units','input_library','spring','course_levels','study_region','members'],'properties':{'schema_version':{'const':1},'axes':{'const':'Z_UP'},'units':{'type':'string'},'input_library':{'type':'string'},'spring':{'type':'number'},'course_levels':{'type':'array','minItems':2,'items':{'type':'number'}},'study_region':{'type':'array','minItems':6,'maxItems':6,'items':{'type':'number'}},'members':{'type':'array','minItems':1,'items':{'type':'object','required':['id','kind'],'properties':{'id':{'type':'string'},'kind':{'enum':['mesh','sweep']},'mesh_key':{'type':'string'},'section_ref':{'type':'string'},'carrier_ref':{'type':'string'},'bearing_degrees':{'type':'number'}},'allOf':[{'if':{'properties':{'kind':{'const':'mesh'}}},'then':{'required':['mesh_key']}},{'if':{'properties':{'kind':{'const':'sweep'}}},'then':{'required':['section_ref','carrier_ref']}}]}},'backing':{'type':'object','required':['mesh_key'],'properties':{'mesh_key':{'type':'string'}}},'tolerances':{'type':'object','properties':{'length':{'type':'number','exclusiveMinimum':0},'area':{'type':'number','exclusiveMinimum':0}}}}}
(R/'INPUT_SCHEMA.json').write_text(json.dumps(schema,indent=2))
q=json.loads((R/'changed_case_03/QA.json').read_text())
record=dict(core_regression_tests=dict(command='python3 test_springer_core.py',passed=8,total=8),actual_fixture=dict(path='changed_case_03',passed=q['passed'],total=q['total']),limitations=['One five-member structural fixture tested; 2/5/8 member counts checked at API level only','Closed contours accepted as numeric arrays, not arbitrary unparsed SVG/raster files','Single solid section outer loop; profiles with intentional internal holes require a separate policy','Coordinates must be explicitly normalized to Z_UP and declared native units','No historical or structural-capacity validation; no architectural approval'])
(R/'VALIDATION_RECORD.json').write_text(json.dumps(record,indent=2))
# Bootstrap scripts are retained as development history, not executable public entry points.
history=R/'development_history';history.mkdir(exist_ok=True)
for n in ['create_reusable_core.py','prepare_test_case.py']:
 p=R/n
 if p.exists():p.rename(history/n)
(history/'README.md').write_text('One-off extraction/bootstrap and failed setup history. Do not use these to regenerate the tested core. Use ../run.py with a manifest. Original R04/R05 files are never modified.\n')
for f in [R/'springer_core.py',R/'run.py',R/'blender_runner.py',R/'case_tools.py',R/'fill_case.py',R/'render_review.py',R/'test_springer_core.py']:py_compile.compile(str(f),doraise=True)
print('SCHEMA_API_AND_VALIDATION_RECORD_SAVED',q['passed'],q['total'])
