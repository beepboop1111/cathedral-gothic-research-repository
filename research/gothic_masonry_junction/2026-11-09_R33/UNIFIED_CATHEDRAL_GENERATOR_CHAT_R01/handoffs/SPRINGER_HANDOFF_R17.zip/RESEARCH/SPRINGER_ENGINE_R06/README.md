# Springer engine R06 — reusable experimental prototype

Purpose: R05 profile-aware common-masonry/pocket filling and coursing, with geometry supplied through a manifest instead of cathedral object names. The runtime core has no project paths, source-object names, fixed pier coordinates or fixed member count. Original R04/R05 files are protected and unchanged.

## Public files
- springer_core.py: pure numeric geometry functions; no import-time file I/O.
- run.py: guarded CLI; creates a NEW output directory and orchestrates staged execution.
- blender_runner.py: input meshes, common-block union, course partitioning and GLB roundtrip.
- fill_case.py and case_tools.py: geometry stages and independent contact/section checks.
- INPUT_SCHEMA.json: manifest shape; additional geometric constraints are checked at runtime.
- test_springer_core.py: eight meaningful API/geometry regression tests.
- changed_profile_and_bearing.json + fixture_inputs.json: complete tested numerical example.
- changed_case_03/: accepted physical test outputs, .blend/.glb/QA and one review render.

development_history/ contains bootstrap/extraction helpers, not runtime entry points. changed_case_01 and02 are rejected setup attempts, not accepted model variants. Do not use bootstrap helpers to overwrite the tested module.

## Run
With source-file integrity references available at their recorded locations:

python3 run.py changed_profile_and_bearing.json --out NEW_OUTPUT_DIRECTORY --blender blender --threads 4

Requires Python with numpy and Shapely>=2.1; Blender5.0.1 was tested. Pillow/matplotlib are used by the separate comparison script, not core geometry. Existing output directories are rejected. No GitHub operation or installation is performed. Source input libraries are never written by the public runner.

The component stages were executed and verified separately on the accepted case. The orchestration wrapper was compiled; the same physical geometry was not regenerated just to repeat the wrapper invocation.

## Input contract
Numerical coordinates must already be explicitly normalized to Z_UP, a declared origin and declared native units. No automatic unit conversion, LittleTiles scaling or SI calibration is inferred. The fixture is numerically1:1; physical SI conversion is unresolved.

Each member has an arbitrary unique ID and one of:
- kind=mesh, mesh_key=...: an existing closed triangle/polygon mesh from library.meshes.
- kind=sweep, section_ref=..., carrier_ref=..., optional bearing_degrees: a closed numeric2D outer contour mapped along explicit carrier centers/width_axes/depth_axes.

A section is an ordered array of[x,y] coordinates; implicit closure or a repeated final endpoint is accepted. It must form one valid solid polygon. SVG/raster parsing is NOT provided here; convert those files to measured contour coordinates separately. Intentional profile-internal holes need an explicit future policy and are not claimed as supported input.

Carrier centers and both axis arrays must share Nx3 shape; width/depth axes must be unit, orthogonal and consistently oriented between stations. A carrier's bearing_degrees declares the original plan bearing. The member's bearing_degrees is an absolute requested bearing; the difference rotates that carrier and its frames about its first station. Supply the carrier bearing explicitly when using an absolute bearing. Without a member override, the original frames are retained.

course_levels are absolute elevations in the normalized frame and strictly increase. Their first/last levels must equal the study-region vertical limits; spring equals the first level. The study region is[xmin,xmax,ymin,ymax,zmin,zmax]. Members outside that local common-block region remain as source-shaped branches. An optional backing references a source mesh, not a guessed circular core. The current fixture creates a review respond from the filled bottom footprint,300 native units below spring; this is a test support, not an approved cathedral pier.

Optional library.source_files records local paths and expected SHA256 hashes. They are verified at completion. Missing or changed referenced sources fail verification instead of being silently substituted.

## Algorithm and geometry controls
Profiles are swept through supplied frames. Existing mesh members are copied, not refitted. The raw common block is the actual local union with the supplied backing. Pocket filling classifies original triangle surfaces across all vertex-height intervals, retaining exterior recesses and filling enclosed horizontal pockets. The pure fill function returns a boundary mesh requiring cap closure in the Blender adapter; its own return value is not claimed already watertight.

All internal bed planes are split into the same filled source mesh first. Each course is selected between successive shared planes and capped. This replaces an unstable per-course Boolean intersection encountered in the input-variation trial; no new radial approximation or exterior outline was introduced. Runtime checks cover mesh topology, volume reconstruction, independent bed-cap contact, bottom seating, actual rib-top contact and GLB reimport.

New geometries can still be incompatible: invalid contours, frame flips, disconnected receiving clusters or excessive contact loss must fail rather than be promoted. This is not a universal architectural-design or structural solver.

## Accepted test
One five-member fixture reused four original input meshes. One diagonal was supplied as a closed contour/carrier input, width x0.90, depth x1.05, bearing46.169... to54.169... degrees. Its station frames were recovered and checked against the source geometry within0.005 native unit. Source-member paths not selected for change were reused without refitting.

The new isolated fixture uses local Z0–600 and five120-unit courses; R05's Z1800–2475/five135-unit geometry is retained unchanged for comparison. The different course input is an additional API exercise, not a revised cathedral elevation. R06 is not silently substituted into the cathedral.

92/92 fixture technical/geometric checks plus8/8 independent API regression tests passed. All four internal beds have full contact, zero unsupported area and zero contour symmetric difference. Base unsupported area0. Actual top-rib uncovered area0.0000294611 square native units; maximum top boundary gap0.0000052931 native unit. Maximum source-vs-filled boundary difference0.0000145094 native unit over61 sampled sections; no enclosed pockets remain at those samples. GLB reimport verifies object names/counts, bounds and oriented triangles at0.0001 quantization.

Only this five-member physical fixture has been tested. Member counts2/5/8 are API-tested, not physical-assembly-certified. Architectural review is pending. Historical construction and structural capacity are not validated. F5ZL-C support schedule remains unresolved. Geometric contact is not bearing-stress or masonry approval.

## Review outputs and limits
SPRINGER_ENGINE_R06_RESULT.png compares the archived R05 review render with one new Blender GLB-reimport render at the same display scale. It records the altered contour, bearing and course inputs. Preview cropping and camera defaults are review-only and do not alter saved model geometry. Camera defaults are tailored to the supplied local-origin fixture; other extents may need a camera adjustment.

Only the final comparison PNG is uploaded for review. Sources, model, schema, tests and QA stay local. No GitHub use unless explicitly requested.
