from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json,numpy as np
R=Path(__file__).resolve().parent;case=R/'changed_case_03';q=json.loads((case/'QA.json').read_text());lib=json.loads((R/'fixture_inputs.json').read_text());c=json.loads((case/'config.json').read_text())
fig,ax=plt.subplots(figsize=(3.4,1.8),dpi=150);fig.patch.set_facecolor('#eeeae2');ax.set_facecolor('#eeeae2')
for key,color,style,label in [('original','black','-','Source section'),('changed','#b33','--','Changed section')]:
 p=np.array(lib['sections'][key]);p=np.vstack([p,p[0]]);ax.plot(p[:,0],p[:,1],color=color,ls=style,lw=1,label=label)
ax.set_aspect('equal');ax.axis('off');ax.set_title('Closed-vector input comparison',fontsize=9);ax.legend(loc='upper left',bbox_to_anchor=(1.0,1),fontsize=7,frameon=False);fig.tight_layout(pad=.4);fig.savefig(R/'PROFILE_INPUT_COMPARISON.png',facecolor=fig.get_facecolor());plt.close(fig)
im=Image.new('RGB',(1800,1180),'#eeeae2');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';title=ImageFont.truetype(f,25);small=ImageFont.truetype(f,17);med=ImageFont.truetype(f,20)
d.text((26,16),'REUSABLE PROFILE + BEARING INPUTS / R06 EXPERIMENTAL',fill='#28251f',font=title)
d.text((26,53),'Saved meshes or closed 2D sections + carrier frames | explicit bearings and course levels | native scale 1:1',fill='#49443b',font=small)
d.text((26,90),'R05 WORKING FIXTURE / preserved reference',fill='#28251f',font=med)
d.text((930,90),'R06 INPUT TEST / one profile and bearing changed',fill='#28251f',font=med)
for x,p in [(10,Path('/home/christopher/Documents/Cathedral/experimental/TAS_COURSED_CORE_R05/COURSED_SPRINGING_DETAIL.png')),(930,case/'variant_review.png')]:
 a=Image.open(p).convert('RGB');a.thumbnail((850,850));im.paste(a,(x,122))
a=Image.open(R/'PROFILE_INPUT_COMPARISON.png').convert('RGB');a.thumbnail((330,155));im.paste(a,(25,982))
target=next(m for m in c['members'] if m['kind']=='sweep');original=lib['carriers']['original']['bearing_degrees']
d.text((410,995),'Profile: width x0.90 / depth x1.05',fill='#28251f',font=small)
d.text((410,1027),f'Bearing: {original:.3f} to {target["bearing_degrees"]:.3f} degrees (+8)',fill='#28251f',font=small)
d.text((410,1059),'Other four input members reused unchanged.',fill='#49443b',font=small)
d.text((410,1091),'New fixture: five 120-unit courses, local Z0-600.',fill='#49443b',font=small)
d.text((1050,995),str(q['passed'])+'/'+str(q['total'])+' fixture checks + 8/8 API regression tests',fill='#28251f',font=small)
d.text((1050,1027),'All four internal bedding interfaces: full contact.',fill='#49443b',font=small)
d.text((1050,1059),'Top rib gap: '+format(q['geometry']['top_contact']['max_boundary_gap'],'.7f')+' native unit.',fill='#49443b',font=small)
d.text((1050,1091),'Actual GLB export/reimport checked in Blender.',fill='#49443b',font=small)
d.text((26,1145),'Architectural review pending | historical/structural validation not performed | R04/R05 unchanged | GitHub unused',fill='#49443b',font=small)
im.save(R/'SPRINGER_ENGINE_R06_RESULT.png');print('COMPARISON_READY')
