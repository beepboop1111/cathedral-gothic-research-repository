# R11 PNG profile input — experimental

Converts one dark solid silhouette to a closed polygon in a canonical width/nose frame, using uniform scale. The input file is never modified. Black threshold, image nose direction, optional width mirroring and trace simplification are configurable. Width OR depth must be explicitly supplied in declared native project units. Physical conversion and architectural orientation are not inferred.

Run from this folder on MR COMPUTER:

    python3 profile_input.py /path/to/profile.png --out /path/to/NEW_PREVIEW_FOLDER --width 141.2507 --nose left

Alternatively give `--depth`, and nose `left`, `right`, `up` or `down`. Add `--mirror-width` when appropriate. Inspect NEW_PREVIEW_FOLDER/orientation_preview.png before proceeding. The preview shows the profile coordinate frame, not its orientation in the 3D receiving pier. It is not user approval of a particular installation. Use an untouched, cropped single black filled outline on a light or transparent background; multi-component sheets and holes are rejected. Separate optional soffits are not automatically combined. A source edge can be clipped by the image itself; check the visual outline. Raster tracing is approximate, not fitted CAD curves; review small details. Simplification defaults to 0.55 pixels and can be adjusted with --simplify-px.

After reviewing, attach the section to a COPY of an existing manifest and library:

    python3 attach_section.py --section /path/to/NEW_PREVIEW_FOLDER/section.json --fixture /path/to/fixture/manifest.json --member member_2 --out /path/to/NEW_INPUT_FOLDER

Choose the actual sweep member ID in the fixture. This step does not verify installation orientation or override the bearing. Build using R06 run_checked.py and the new manifest, in another new output folder. Paths, frames and bearing must be supplied by an appropriate fixture; this is a CLI workflow, not yet a graphical Blender interface.

Requires system Python packages numpy, OpenCV, Shapely and Pillow; the build also requires R06 dependencies and Blender. Size/axis values are native fixture units. R06 / R08 / R09 / R10 are not modified. Existing outputs are protected from overwrite.
