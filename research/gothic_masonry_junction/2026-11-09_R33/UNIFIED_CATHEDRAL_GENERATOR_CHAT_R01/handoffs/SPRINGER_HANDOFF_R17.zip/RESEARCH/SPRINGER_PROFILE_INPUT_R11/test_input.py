import unittest,tempfile,pathlib,sys,cv2,numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).parent));import profile_input as c
class InputTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.tmp.name)/'shape.png'
 def tearDown(self):self.tmp.cleanup()
 def write(self,img):cv2.imwrite(str(self.path),img)
 def test_size_and_aspect(self):
  a=np.full((80,140,3),255,np.uint8);cv2.rectangle(a,(20,20),(120,60),(0,0,0),-1);self.write(a);p=c.convert(self.path,80,None,'left',False,128,.1);q=c.convert(self.path,None,200,'left',False,128,.1);self.assertAlmostEqual(p['width'],80);self.assertAlmostEqual(p['depth'],200);self.assertAlmostEqual(q['width'],80)
 def test_orientation_and_mirroring(self):
  a=np.full((100,120,3),255,np.uint8);cv2.fillPoly(a,[np.array([[20,40],[100,20],[100,80]],np.int32)],(0,0,0));self.write(a);x=c.convert(self.path,100,None,'left',False,128,1);y=c.convert(self.path,100,None,'left',True,128,1);np.testing.assert_allclose(np.array(x['section'])[:,0],-np.array(y['section'])[:,0]);np.testing.assert_allclose(np.array(x['section'])[:,1],np.array(y['section'])[:,1])
 def test_multiple_sections_rejected(self):
  a=np.full((100,150,3),255,np.uint8);cv2.rectangle(a,(10,20),(60,70),(0,0,0),-1);cv2.rectangle(a,(90,20),(140,70),(0,0,0),-1);self.write(a)
  with self.assertRaisesRegex(ValueError,'exactly one'):c.convert(self.path,100,None,'left',False,128,.1)
 def test_holes_rejected(self):
  a=np.full((100,100,3),255,np.uint8);cv2.rectangle(a,(10,10),(90,90),(0,0,0),-1);cv2.rectangle(a,(30,30),(70,70),(255,255,255),-1);self.write(a)
  with self.assertRaisesRegex(ValueError,'holes'):c.convert(self.path,100,None,'left',False,128,.1)
 def test_empty_rejected(self):
  self.write(np.full((80,80,3),255,np.uint8))
  with self.assertRaisesRegex(ValueError,'No black'):c.convert(self.path,100,None,'left',False,128,.1)
if __name__=='__main__':unittest.main()
