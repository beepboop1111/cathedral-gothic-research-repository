from PIL import Image,ImageDraw,ImageFont,ImageOps
from pathlib import Path
p=Path(__file__).parent;im=Image.new('RGB',(1600,1000),'#e7e3d9');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';b='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';small=ImageFont.truetype(f,21);title=ImageFont.truetype(b,34)
d.text((45,30),'PROFILE 18  |  BEARING ARRANGEMENT TESTS',font=title,fill='#252b32');preview=ImageOps.contain(Image.open(p/'four_build/variant_review.png').convert('RGB'),(840,840));im.paste(preview,(45,105));x=940;d.text((x,110),'SOURCE PROFILE',font=ImageFont.truetype(b,25),fill='#252b32');src=Image.open(p/'source_18.png').convert('RGBA');bg=Image.new('RGBA',src.size,'white');bg.alpha_composite(src);im.paste(ImageOps.contain(bg.convert('RGB'),(350,330)),(x+30,160))
lines=['Four members; bearing +12°: PASS','78/78 checks; GLB reimported','Three members: separation detected','Five members: non-manifold edge','Disconnected-member test: REJECTED','Source proportions preserved','Scale and placement provisional','Experimental; review pending']
for i,s in enumerate(lines):d.text((x,570+i*39),s,font=small,fill='#252b32')
im.save(p/'SPRINGER_PROFILE_R10_RESULT.png')
