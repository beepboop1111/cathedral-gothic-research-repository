# R10 profile and bearing tests — experimental

Baseline R06 engine and R08 full-height 0.01 native unit backing retreat. R04-R09 unchanged. Numerical 1:1 fixture with Z_UP; physical unit mapping unresolved. Source user PNG 18, sha256 6f24f328a075d8cf60e5cd20783092a4fa226bc4f2bb28b80207ac3d2136ffd9. One connected silhouette; threshold 128; 0.55 px simplification; 218 vertices. Uniform scale 0.3232281464530892 native units/pixel, width 141.2507, depth 116.68536086956522; proportional, test size provisional. No separate soffit added.

Four-member set 0,1,2,3 with member 2 bearing 58.16944050198884 degrees (+12 relative to original), R08 backing: 78/78 technical/geometric checks; Blender 5.0.1 GLB export/reimport; four internal beds have zero recorded unsupported area, base zero, top uncovered 4.3986e-5 square units and max gap 2.1777e-6 native units; 61-section max boundary error 9.4305e-6. Synthetic bearing arrangement, not verified actual cathedral geometry.

Three-member 0,2,3 arrangement rejected by current connectivity policy: section at Z599.950137 has two components while Z500.000137 has one. Cause and whether expected branch separation or invalid coursing require architectural review; no accepted GLB. Five-member arrangement fails non-manifold raw union (one edge); no accepted GLB. These failures are not evidence profile 18 is generally invalid.

Deliberately displaced member by 700 native units, region extended to include it: build rejected in support stage because the filled base is not one solid polygon. Negative test detects disconnected base; it does not establish detection of all disconnected or invalid cases.

Historical and structural assessment absent, architecture unapproved. No direct raster input added to reusable core; conversion performed externally. R08 backing retreat and taper issue remain unresolved. No GitHub.
