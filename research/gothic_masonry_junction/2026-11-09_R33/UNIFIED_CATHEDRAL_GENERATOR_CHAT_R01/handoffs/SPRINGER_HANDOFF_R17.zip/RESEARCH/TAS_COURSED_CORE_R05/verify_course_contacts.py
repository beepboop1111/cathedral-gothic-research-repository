from pathlib import Path
import json,numpy as np
from shapely.geometry import Polygon,Point
from shapely.ops import unary_union
R=Path(__file__).resolve().parent
prefix=(R/'fill_enclosed_pockets_exact.py').read_text().split('for k,(lo,hi)')[0]
D=json.loads((R/'COURSE_ACTUAL.json').read_text())
def cap(tris,z):
 return unary_union([Polygon([p[:2] for p in t]) for t in tris if all(abs(p[2]-z)<.0001 for p in t)])
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
def tester(tris):
 ns={'__file__':str(R/'fill_enclosed_pockets_exact.py')};exec(prefix,ns)
 t=np.asarray(tris,float);ns.update(tri=t,mins=t[:,:,2].min(axis=1),maxs=t[:,:,2].max(axis=1));return lambda z:ns['horizontal'](z)[1]
checks={};beds=[];courses=D['courses'];levels=D['levels']
for i in range(len(courses)-1):
 z=levels[i+1];lo=cap(courses[i]['triangles'],z);hi=cap(courses[i+1]['triangles'],z)
 area=lo.intersection(hi).area;missing=hi.difference(lo).area;err=lo.symmetric_difference(hi).area;gap=lo.boundary.hausdorff_distance(hi.boundary)
 beds.append(dict(z=z,area=area,supported_fraction=area/hi.area,unsupported_area=missing,cap_difference_area=err,boundary_difference=gap))
 checks['bed_'+str(i)+'_complete_contact_within_2_area_units']=missing<=2
 checks['bed_'+str(i)+'_matched_contours_within_0_005']=err<=2 and gap<=.005
top=cap(courses[-1]['triangles'],levels[-1]);rib=unary_union([cap(v,levels[-1]) for v in D['upper_ribs'].values()])
maxgap=max(top.distance(p.exterior.interpolate(p.exterior.length*j/300)) for p in parts(rib) for j in range(301));missing=rib.difference(top).area
checks['top_ribs_supported_within_2_area_units']=missing<=2
checks['top_rib_boundary_contact_within_0_005']=maxgap<=.005
base=cap(courses[0]['triangles'],levels[0]);support=unary_union([cap(v,levels[0]) for v in D['base_supports'].values()])
base_missing=base.difference(support).area
checks['base_course_seated_within_2_area_units']=base_missing<=2
ref=tester(json.loads((R/'FILLED_ACTUAL_TRIANGLES.json').read_text()))
rows=[]
for c in courses:
 current=tester(c['triangles']);lo,hi=c['z']
 for z in [lo+.05,(lo+hi)/2,hi-.05]:
  a=ref(z);b=current(z);error=a.symmetric_difference(b).area;pocket=sum(Polygon(r).area for p in parts(b) for r in p.interiors)
  checks[c['name']+'_'+str(z)+'_retains_filled_envelope']=error<=2
  checks[c['name']+'_'+str(z)+'_no_internal_pockets']=pocket<.01
  rows.append(dict(course=c['name'],z=z,envelope_error=error,pocket_area=pocket))
q=dict(checks=checks,bedding=beds,top_contact=dict(uncovered_rib_area=missing,max_boundary_gap=maxgap,actual_rib_area=rib.area),base_contact=dict(unsupported_base_area=base_missing,base_area=base.area),sections=rows)
(R/'COURSE_CONTACT_QA.json').write_text(json.dumps(q,indent=2));print(json.dumps(q));assert all(checks.values())
