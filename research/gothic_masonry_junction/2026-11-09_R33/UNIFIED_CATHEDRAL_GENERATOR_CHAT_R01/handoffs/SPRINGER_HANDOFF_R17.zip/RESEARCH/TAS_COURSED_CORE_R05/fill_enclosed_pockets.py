from pathlib import Path
import json,collections,time
import numpy as np
from shapely.geometry import Polygon,Point,LineString
from shapely.ops import unary_union,polygonize
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles
R=Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text())
tri=np.asarray(D['triangles'],float);mins=tri[:,:,2].min(axis=1);maxs=tri[:,:,2].max(axis=1);cache={}
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
def section(z):
 key=round(float(z),7)
 if key in cache:return cache[key]
 ts=tri[(mins<z)&(maxs>z)];segments=[]
 for t in ts:
  pts=[]
  for a,b in zip(t,np.roll(t,-1,axis=0)):
   if (a[2]<z<b[2]) or (b[2]<z<a[2]):
    f=(z-a[2])/(b[2]-a[2]);pts.append((round(float(a[0]+f*(b[0]-a[0])),7),round(float(a[1]+f*(b[1]-a[1])),7)))
  if len(pts)==2 and pts[0]!=pts[1]:segments.append(pts)
 if not segments:return Polygon()
 candidates=list(polygonize(unary_union([LineString(s) for s in segments])))
 def inside(p):
  x,y=p.x,p.y;hits=[]
  for a,b in segments:
   if (a[1]>y)!=(b[1]>y):
    hit=a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1])
    if hit>x:hits.append(round(hit,6))
  return len(set(hits))%2==1
 g=unary_union([p for p in candidates if inside(p.representative_point())]);cache[key]=g;return g
kept=[];removed=[];distances=[]
for i,t in enumerate(tri):
 if maxs[i]-mins[i]<1e-6:continue
 z=min(2474.9999,max(1800.0001,float(t[:,2].mean())+.000137));p=Point(t[:,:2].mean(axis=0));g=section(z)
 if g.is_empty:g=section(min(2474.9998,max(1800.0002,z+.000173)))
 assert not g.is_empty,(i,z)
 outer=min(q.exterior.distance(p) for q in parts(g))
 holes=[r for q in parts(g) for r in q.interiors]
 inner=min((r.distance(p) for r in holes),default=float('inf'))
 distances.append(min(outer,inner))
 (removed if inner<outer else kept).append(t.tolist())
# Caps use the same recovered EXTERIOR contours; only enclosed interior rings are filled.
caps={}
for z in [1800,2475]:
 old=unary_union([Polygon(t[:,:2]) for t in tri[(abs(tri[:,:,2]-z)<1e-6).all(axis=1)]])
 filled=unary_union([Polygon(p.exterior) for p in parts(old)])
 caps[str(z)]=dict(old_area=old.area,filled_area=filled.area,pocket_fill_area=filled.area-old.area)
 for poly in parts(filled):
  for t in constrained_delaunay_triangles(orient(poly,sign=1)).geoms:
   points=[[float(x),float(y),z] for x,y in list(orient(t,sign=1).exterior.coords)[:-1]]
   kept.append(list(reversed(points)) if z==1800 else points)
vertices=[];indices={};faces=[]
for t in kept:
 f=[]
 for v in t:
  key=tuple(v)
  if key not in indices:indices[key]=len(vertices);vertices.append(v)
  f.append(indices[key])
 faces.append(f)
edges=collections.defaultdict(list)
for f in faces:
 for a,b in zip(f,f[1:]+f[:1]):edges[tuple(sorted((a,b)))].append(a<b)
bad=[(e,x) for e,x in edges.items() if len(x)!=2 or x[0]==x[1]]
report=dict(method='Classify side triangles by original horizontal section exterior versus enclosed interior rings; retain exterior triangles exactly; replace caps using filled interior rings only',removed_inner_triangles=len(removed),kept_mesh_triangles=len(faces),max_classification_boundary_distance=max(distances),bad_edges=len(bad),bad_edge_examples=[dict(points=[vertices[i] for i in e],uses=x) for e,x in bad[:15]],caps=caps)
(R/'FILLED_MESH.json').write_text(json.dumps(dict(vertices=vertices,faces=faces)))
(R/'FILL_DIAGNOSTIC.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
