import bpy,bmesh,json,pathlib,hashlib,collections
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());M=json.loads((R/'FILLED_MESH.json').read_text())
bpy.ops.wm.open_mainfile(filepath=D['source'])
old=bpy.data.objects[D['object']]
r=old.copy();r.data=old.data.copy();r.name='REFERENCE_R04_TAS_UNFILLED';bpy.context.scene.collection.objects.link(r);r.hide_render=True;r.hide_set(True)
me=bpy.data.meshes.new('FILLED_ENCLOSED_POCKETS');me.from_pydata(M['vertices'],[],M['faces']);me.update()
o=bpy.data.objects.new('FILLED_CORE_R05',me);bpy.context.scene.collection.objects.link(o)
for mat in old.data.materials:o.data.materials.append(mat)
bpy.data.objects.remove(old,do_unlink=True)
bm=bmesh.new();bm.from_mesh(o.data)
bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001)
boundary=[e for e in bm.edges if e.is_boundary]
result=bmesh.ops.holes_fill(bm,edges=boundary,sides=0)
added_heights=sorted({float(v.co.z) for f in result.get('faces',[]) for v in f.verts})
bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
diagnostic=dict(boundary_before=len(boundary),new_closure_faces=len(result.get('faces',[])),nonmanifold_after=sum(not e.is_manifold for e in bm.edges),closure_vertex_heights=added_heights)
bm.to_mesh(me);bm.free();me.update()
o.data.calc_loop_triangles();v=[list(o.matrix_world@a.co) for a in me.vertices]
(R/'FILLED_ACTUAL_TRIANGLES.json').write_text(json.dumps([[v[i] for i in t.vertices] for t in me.loop_triangles]))
(R/'FILLED_BUILD_DIAGNOSTIC.json').write_text(json.dumps(diagnostic,indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'FILLED_CORE_CANDIDATE.blend'))
assert diagnostic['nonmanifold_after']==0,diagnostic
print(json.dumps(diagnostic))
