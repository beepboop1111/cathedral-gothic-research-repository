from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
R=Path(__file__).resolve().parent;prefix=(R/'fill_enclosed_pockets_exact.py').read_text().split('for k,(lo,hi)')[0]
old={'__file__':str(R/'fill_enclosed_pockets_exact.py')};exec(prefix,old)
new={'__file__':str(R/'fill_enclosed_pockets_exact.py')};exec(prefix,new)
C=json.loads((R/'COURSE_ACTUAL.json').read_text());t=np.array(C['courses'][-1]['triangles']);new.update(tri=t,mins=t[:,:,2].min(axis=1),maxs=t[:,:,2].max(axis=1))
z=2474.950137;a=old['horizontal'](z)[1];b=new['horizontal'](z)[1];q=json.loads((R/'QA.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(7.6,5.0),dpi=150);fig.patch.set_facecolor('#eeeae2')
def draw(ax,g,color):
 for p in old['parts'](g):
  ax.add_patch(Patch([(x-31000,y+1250) for x,y in p.exterior.coords],facecolor=color,edgecolor='black',linewidth=1))
  for ring in p.interiors:ax.add_patch(Patch([(x-31000,y+1250) for x,y in ring.coords],facecolor='#eeeae2',edgecolor='#a33',linewidth=1))
for ax,g,title,color in zip(axes,[a,b],['R04 / enclosed pockets','R05 / filled stone core'],['#c7c1b5','#cfad77']):
 ax.set_facecolor('#eeeae2');draw(ax,g,color)
 ax.axhline(0,color='#999',lw=.5,ls='--');ax.axvline(0,color='#999',lw=.5,ls='--');ax.set_xlim(-290,290);ax.set_ylim(-340,260);ax.set_aspect('equal');ax.set_title(title,fontsize=11);ax.tick_params(labelsize=8);ax.set_xlabel('Local X / native units',fontsize=9)
axes[0].set_ylabel('Local Y / native units',fontsize=9);fig.suptitle('Matched section at Z2474.95 / visible contour retained',fontsize=12);fig.tight_layout();fig.savefig(R/'POCKET_BEFORE_AFTER.png',facecolor=fig.get_facecolor());plt.close(fig)
# Native measurable comparison of filled last-course section.
def path(ring):return 'M '+' L '.join(str(x-31000)+','+str(-(y+1250)) for x,y in ring)+' Z'
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="-290 -260 580 600">']
for p in old['parts'](b):
 svg.append('<path d="'+path(p.exterior.coords)+'" fill="#cfad77" stroke="#a33" stroke-width="1" stroke-dasharray="4 3"/>')
for p in old['parts'](a):
 svg.append('<path d="'+path(p.exterior.coords)+'" fill="none" stroke="black" stroke-width="1"/>')
 for ring in p.interiors:svg.append('<path d="'+path(ring.coords)+'" fill="none" stroke="#999" stroke-width=".8" stroke-dasharray="4 3"/>')
svg.append('</svg>');(R/'R04_R05_SECTION_Z2474_95_NATIVE.svg').write_text(''.join(svg))
im=Image.new('RGB',(1800,1170),'#eeeae2');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font=ImageFont.truetype(f,25);small=ImageFont.truetype(f,17);med=ImageFont.truetype(f,20)
d.text((26,16),'FILLED CORE + MATCHED STONE COURSES / R05 EXPERIMENTAL',fill='#28251f',font=font)
d.text((26,53),'R04 method retained | five 135-unit courses, Z1800-2475 | visible profiles and carrier curves preserved',fill='#49443b',font=small)
pic=Image.open(R/'COURSED_SPRINGING_DETAIL.png').convert('RGB');pic.thumbnail((1000,1000));im.paste(pic,(10,85))
pic=Image.open(R/'POCKET_BEFORE_AFTER.png').convert('RGB');pic.thumbnail((760,500));im.paste(pic,(1030,125))
d.text((1045,675),'INDEPENDENT BEDDING CHECKS',fill='#28251f',font=med)
d.text((1045,717),'Joint Z          Contact          Unsupported area',fill='#49443b',font=small)
for i,bed in enumerate(q['bedding']):
 d.text((1045,750+i*33),f"{bed['z']:.0f}               {bed['supported_fraction']*100:.4f}%              {bed['unsupported_area']:.4f}",fill='#28251f',font=small)
d.text((1045,910),'Bottom course: fully seated; 2 small shaft-pocket infills.',fill='#49443b',font=small)
d.text((1045,945),'Top rib contact: maximum gap < 0.0002 native unit.',fill='#49443b',font=small)
d.text((1045,980),'Visible-contour difference: < 0.001 native unit.',fill='#49443b',font=small)
d.text((1045,1015),'No internal pockets in 158 checked core sections.',fill='#49443b',font=small)
d.text((26,1092),'BLENDER GLB REIMPORT - alternating tones identify courses; joint planes have no artificial gap',fill='#28251f',font=small)
d.text((26,1127),str(q['passed'])+'/'+str(q['total'])+' technical/geometric checks | architectural review pending | historical and structural validation not performed',fill='#49443b',font=small)
im.save(R/'TAS_COURSED_CORE_R05_RESULT.png');print('RESULT_PNG_READY')
