import bpy,pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent
S=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/TAS_DE_CHARGE_R04/TAS_DE_CHARGE_R04.blend')
bpy.ops.wm.open_mainfile(filepath=str(S));bpy.context.view_layer.update()
def coords(o):return [list(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr(([tuple(v) for v in coords(o)],[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
o=bpy.data.objects['TAS_DE_CHARGE_SHARED_S'];o.data.calc_loop_triangles();v=coords(o)
D=dict(source=str(S),source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),object=o.name,vertices=v,faces=[list(p.vertices) for p in o.data.polygons],triangles=[[v[i] for i in t.vertices] for t in o.data.loop_triangles],protected={p.name:sig(p) for p in bpy.context.scene.objects if p.type=='MESH' and p!=o},hidden_reference_names=[p.name for p in bpy.context.scene.objects if p.type=='MESH' and p.name.startswith('REFERENCE_R03_')])
(R/'INPUTS.json').write_text(json.dumps(D))
print('SAVED_BASELINE',len(v),'vertices',len(D['faces']),'faces',len(D['protected']),'protected')
