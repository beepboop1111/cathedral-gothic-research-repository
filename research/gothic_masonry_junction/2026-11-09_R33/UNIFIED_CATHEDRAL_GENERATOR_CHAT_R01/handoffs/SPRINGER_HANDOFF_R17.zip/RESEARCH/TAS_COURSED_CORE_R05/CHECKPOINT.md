# Filled core and coursed springer R05 — EXPERIMENTAL

Working method retained: R04 actual-profile mesh union and source-surface slicing. R04 saved file remains unchanged; exact parent path/hash in INPUTS.json and QA.json. Native numerical1:1; Blender X east/Y north/Z up. Physical SI calibration unresolved. No approved architecture, original historical source, authoritative generator or Pass6J record changed. GitHub unused.

## Delta and ownership
Only the south shared-pier common block is developed. Z1800–2475 is divided into five135-unit courses at Z1800,1935,2070,2205,2340,2475. Course height/count are experimental choices, not inherited R4085 dimensions or an approved masonry schedule. Courses use actual filled R04 side surfaces; no radial envelope, convex hull, or oversized circular core was substituted.

Enclosed horizontal-section pockets were distinguished from open exterior moulding recesses in every one of2073 source-vertex-height intervals. The first centroid-only removal attempt was rejected because it crossed pocket/recess transitions. The final algorithm classifies exact source triangles within each height interval and splits only at8 detected topology-transition heights. This retains exterior source surface planes while filling internal pockets, including their proper transition floors. Tiny numerical boundary cracks were closed after meshing; independent exterior tests below bound their effect.

The completed solid has no enclosed section pockets in158 independent sampled sections, including samples around all closure events. Visible exterior contour maximum difference versus R04:0.0009639463 native unit, below0.005 tolerance. Maximum filled-outline symmetric-difference area observed:0.32030957 square native units, below2. This is numerical preservation within stated tolerances, not a claim of exact floating-point identity. Actual carrier curves, profile sweeps, wall receivers, source pier and all other R04 objects are unchanged in vertex arrays and polygon connectivity.

Two small enclosed pockets in the original straight south pier also required internal infill so the first course could seat fully. These are separate additive solids inside the original pier-hole footprints, Z0–1800; original pier geometry and visible profile remain unchanged. Their combined plan area is about41.000526 square native units and volume73800.94633 cubic native units. They do not redesign the visible shaft or base. R04 unfilled common block and the filled continuous core are retained hidden in the .blend for comparison and excluded from the GLB.

## Validation actually performed
56/56 technical/geometric checks passed. Pocket filling was verified at158 heights; course interiors at15 independently selected heights. Course meshes are closed/manifold and positive-volume. The five course volumes reconstruct the filled block within1e-5 relative tolerance.

The recovered scripts' useful bedding concept was reused, with independent checks on actual resulting top/bottom caps:
- Z1935,2070,2205,2340: support fraction1.0, unsupported area0, contour symmetric difference0, boundary difference0.
- First-course base: unsupported area0.
- Actual rib-to-top-course joint atZ2475: uncovered footprint0.0013112323 square native units; maximum boundary gap0.0001945482 native unit. These are explicitly reported numerical residuals, not falsely called mathematically zero.
- Exported GLB reimport: exact visible names/count, world bounds error0 (tolerance0.01), and oriented world-triangle signatures at0.001 quantization.

Source file hashes and unrelated geometry remain unchanged. Zero-gap bed planes model geometrical contact only; mortar thickness, bedding pressure, quarry stone dimensions and construction tolerances have not been designed. Alternating course material tones are visual identifiers, not physical joints. Preview cropping is applied only after final export and does not alter delivered geometry.

## Status boundaries
Architectural: experimental five-course filled-core candidate for review; solid-core additions are a design inference, not a historic template. Historical: not assessed. Structural: not assessed; no bearing-stress, load-path or masonry capacity certification. Missing F5ZL-C support schedule remains unresolved. Bedding geometry alone does not establish structural adequacy. R4085 and Pass6J dimensions remain separate and were not applied.

## Saved files and reproduction
Directory: /home/christopher/Documents/Cathedral/experimental/TAS_COURSED_CORE_R05
Final: TAS_COURSED_CORE_R05.blend, TAS_COURSED_CORE_R05.glb, QA.json, COURSE_CONTACT_QA.json, FILLED_CORE_QA.json, R04_R05_SECTION_Z2474_95_NATIVE.svg and TAS_COURSED_CORE_R05_RESULT.png. Native SVG uses local translation/reflection only, one SVG unit per native unit. The final composite was visually inspected: actual Blender GLB reimport view, matched before/after section, and bedding results. Only that PNG is uploaded to the user.

Requires Blender5.0.1, system Python3 with numpy/Shapely2.1.2; Pillow/matplotlib for preview. Exact R04 parent model must exist at the recorded path.
1. blender -b -t4 --python extract_inputs.py
2. python3 fill_enclosed_pockets_exact.py
3. blender -b -t4 --python make_filled_candidate.py
4. python3 verify_filled_core.py
5. blender -b -t4 --python build_courses_and_verify.py
6. python3 compose_preview.py

The course builder invokes prepare_pier_infills.py and verify_course_contacts.py. The final run resumed already-validated saved courses via finalize_saved_courses.py after fixing a reporting reference to deleted pre-reimport Blender objects; no course rebuild was needed. The main builder carries the same fix for future runs. fill_enclosed_pockets.py is the superseded centroid-only attempt and is NOT the accepted method. Source originals and earlier checkpoints are retained. MANIFEST_SHA256.json records local deliverable/source hashes. No repository operations unless explicitly requested.
