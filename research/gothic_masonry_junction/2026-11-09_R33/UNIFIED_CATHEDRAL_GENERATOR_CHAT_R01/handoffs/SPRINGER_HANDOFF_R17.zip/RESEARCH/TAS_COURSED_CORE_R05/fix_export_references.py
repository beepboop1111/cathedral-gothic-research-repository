from pathlib import Path
p=Path('/home/christopher/Documents/Cathedral/experimental/TAS_COURSED_CORE_R05')
s=(p/'build_courses_and_verify.py').read_text()
s=s.replace("visible=[o for o in bpy.context.scene.objects","course_names=[o.name for o in courses];infill_names=[o.name for o in infills]\nvisible=[o for o in bpy.context.scene.objects")
s=s.replace("sum(volume(bpy.data.objects[o.name]) for o in infills)","sum(volume(bpy.data.objects[n]) for n in infill_names)")
s=s.replace("[o.name for o in courses+infills]","course_names+infill_names")
(p/'build_courses_and_verify.py').write_text(s)
prefix=s.split('base=bpy.data.objects',1)[0].replace("str(R/'FILLED_CORE_CANDIDATE.blend')","str(R/'TAS_COURSED_CORE_R05.blend')")
mid="""
courses=[bpy.data.objects[c['name']] for c in json.loads((R/'COURSE_ACTUAL.json').read_text())['courses']]
infills=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith('ENCLOSED_PIER_POCKET_INFILL_')]
course_names=[o.name for o in courses];infill_names=[o.name for o in infills]
def closed(o):
 edges=collections.defaultdict(list)
 for f in o.data.polygons:
  v=list(f.vertices)
  for a,b in zip(v,v[1:]+v[:1]):edges[tuple(sorted((a,b)))].append(a<b)
 return all(len(v)==2 and v[0]!=v[1] for v in edges.values())
base=bpy.data.objects['SHARED_PIER_S']
checks['source_pier_is_straight_vertical_for_internal_fill']=all(abs(v[2])<.0001 or abs(v[2]-1800)<.0001 for v in coords(base))
checks['five_courses_135_high']=len(courses)==5 and all(abs(max(v[2] for v in coords(o))-min(v[2] for v in coords(o))-135)<.0001 for o in courses)
checks['courses_closed_manifold']=all(closed(o) for o in courses)
checks['all_new_material_positive_volume']=all(volume(o)>0 for o in courses+infills)
checks['course_volumes_reconstruct_filled_body']=abs(sum(volume(o) for o in courses)-volume(body))/volume(body)<1e-5
checks['source_R04_saved_file_unchanged']=hashlib.sha256(pathlib.Path(D['source']).read_bytes()).hexdigest()==D['source_sha256']
upper=['CHAPEL_TRANSVERSE_31000','BAY1_RIB_1','BAY2_RIB_0','BAY1_FORMERET_0','BAY2_FORMERET_0']
contact=json.loads((R/'COURSE_CONTACT_QA.json').read_text());checks.update(contact['checks']);checks.update(filledqa['checks']);assert all(checks.values())
"""
suffix=s.split('visible=[o for o in bpy.context.scene.objects',1)[1]
(p/'finalize_saved_courses.py').write_text(prefix+mid+"\nvisible=[o for o in bpy.context.scene.objects"+suffix)
print('EXPORT_REPORT_REFERENCES_CORRECTED')
