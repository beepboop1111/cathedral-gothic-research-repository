import bpy,bmesh,json,pathlib,hashlib,math,collections,subprocess
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());filledqa=json.loads((R/'FILLED_CORE_QA.json').read_text());assert all(filledqa['checks'].values())
bpy.ops.wm.open_mainfile(filepath=str(R/'TAS_COURSED_CORE_R05.blend'));bpy.context.view_layer.update()
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
def triangles(o):
 o.data.calc_loop_triangles();v=coords(o);return [[list(v[i]) for i in t.vertices] for t in o.data.loop_triangles]
def cap(o,z):return [[v[:2] for v in t] for t in triangles(o) if all(abs(v[2]-z)<.0001 for v in t)]
checks=dict(all_R04_neighbors_curves_pier_and_receivers_unchanged=all(sig(bpy.data.objects[n])==h for n,h in D['protected'].items()))
body=bpy.data.objects['FILLED_CORE_R05'];levels=[1800.+135*i for i in range(6)]
def boolean(o,cut):
 bpy.context.view_layer.objects.active=o;m=o.modifiers.new('HORIZONTAL_BED','BOOLEAN');m.operation='INTERSECT';m.solver='EXACT';m.object=cut;bpy.ops.object.modifier_apply(modifier=m.name)
def cleanup(o):
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00001)
 bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.00000001)
 edges=[e for e in bm.edges if e.is_boundary]
 if edges:bmesh.ops.holes_fill(bm,edges=edges,sides=0)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));n=sum(not e.is_manifold for e in bm.edges);bm.to_mesh(o.data);bm.free();o.data.update();return n
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(p) for p in coords(o)];c=v[0]
 return sum((v[t.vertices[0]]-c).dot((v[t.vertices[1]]-c).cross(v[t.vertices[2]]-c))/6 for t in o.data.loop_triangles)

courses=[bpy.data.objects[c['name']] for c in json.loads((R/'COURSE_ACTUAL.json').read_text())['courses']]
infills=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith('ENCLOSED_PIER_POCKET_INFILL_')]
course_names=[o.name for o in courses];infill_names=[o.name for o in infills]
def closed(o):
 edges=collections.defaultdict(list)
 for f in o.data.polygons:
  v=list(f.vertices)
  for a,b in zip(v,v[1:]+v[:1]):edges[tuple(sorted((a,b)))].append(a<b)
 return all(len(v)==2 and v[0]!=v[1] for v in edges.values())
base=bpy.data.objects['SHARED_PIER_S']
checks['source_pier_is_straight_vertical_for_internal_fill']=all(abs(v[2])<.0001 or abs(v[2]-1800)<.0001 for v in coords(base))
checks['five_courses_135_high']=len(courses)==5 and all(abs(max(v[2] for v in coords(o))-min(v[2] for v in coords(o))-135)<.0001 for o in courses)
checks['courses_closed_manifold']=all(closed(o) for o in courses)
checks['all_new_material_positive_volume']=all(volume(o)>0 for o in courses+infills)
checks['course_volumes_reconstruct_filled_body']=abs(sum(volume(o) for o in courses)-volume(body))/volume(body)<1e-5
checks['source_R04_saved_file_unchanged']=hashlib.sha256(pathlib.Path(D['source']).read_bytes()).hexdigest()==D['source_sha256']
upper=['CHAPEL_TRANSVERSE_31000','BAY1_RIB_1','BAY2_RIB_0','BAY1_FORMERET_0','BAY2_FORMERET_0']
contact=json.loads((R/'COURSE_CONTACT_QA.json').read_text());checks.update(contact['checks']);checks.update(filledqa['checks']);assert all(checks.values())

visible=[o for o in bpy.context.scene.objects if o.type=='MESH' and not o.hide_get() and not o.hide_render and not o.name.startswith('REFERENCE_')]
def snapshot(obs):
 result={}
 for o in obs:
  v=coords(o);o.data.calc_loop_triangles();ts=[]
  for t in o.data.loop_triangles:
   p=[tuple(round(v[i][k],3) for k in range(3)) for i in t.vertices];ts.append(min(tuple(p[j:]+p[:j]) for j in range(3)))
  result[o.name]=dict(bounds=[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]],triangles=sorted(ts))
 return result
before=snapshot(visible)
bpy.ops.object.select_all(action='DESELECT')
for o in visible:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(R/'TAS_COURSED_CORE_R05.glb'),export_format='GLB',use_selection=True,export_cameras=False,export_lights=False)
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.import_scene.gltf(filepath=str(R/'TAS_COURSED_CORE_R05.glb'));after=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
checks['GLB_names_counts_no_reference_duplicates']=set(before)==set(after)
err=max(abs(before[n]['bounds'][j][k]-after[n]['bounds'][j][k]) for n in before for j in range(2) for k in range(3))
checks['GLB_bounds_within_0_01']=err<.01
checks['GLB_oriented_triangle_signatures_at_0_001']=all(before[n]['triangles']==after[n]['triangles'] for n in before)
qa=dict(revision='TAS_COURSED_CORE_R05_EXPERIMENTAL',source=D['source'],source_sha256=D['source_sha256'],checks=checks,passed=sum(checks.values()),total=len(checks),course_levels=levels,filled_core_sections=filledqa['sections'],max_visible_boundary_error=filledqa['max_boundary_error'],max_pocket_area_after=filledqa['max_pocket_after'],pier_infill_count=len(infills),pier_infill_volume=sum(volume(bpy.data.objects[n]) for n in infill_names),bedding=contact['bedding'],top_contact=contact['top_contact'],base_contact=contact['base_contact'],glb_bounds_error=err,validation=dict(technical='watertight positive course meshes, volume reconstruction, actual GLB reimport and oriented triangle signatures',geometric='158 original-vs-filled sections, external recess preservation, exact shared bedding cap checks, actual pier and rib seating checks',architectural='experimental five135-unit courses and internal core infill; stone sizes/bond and course choice require review',historical='not assessed; recovered code used for checks only, no historical stone schedule inferred',structural='not assessed; no bearing stress, force-path or capacity approval; F5ZL-C schedule unresolved'))
(R/'QA.json').write_text(json.dumps(qa,indent=2));assert all(checks.values()),qa
# Preview copies are cropped only after export.
keep=set(upper+['SHARED_PIER_S']+course_names+infill_names+[n for n in D['protected'] if n.startswith('RECEIVING_S_')])
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and o.name not in keep:bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.mesh.primitive_cube_add(size=1,location=(31000,-1200,2250));cut=bpy.context.object;cut.dimensions=(1500,1700,1500);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and o!=cut:
  boolean(o,cut)
  if not len(o.data.polygons):bpy.data.objects.remove(o,do_unlink=True)
bpy.data.objects.remove(cut,do_unlink=True)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX'
scene.render.resolution_x=1200;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(32050,100,3200));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=2150;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(31000,-1175,2240))
for loc,power,size in [((31000,1000,7000),1500000000,4000),((28000,-3500,5000),1300000000,4000)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(31000,-1250,2200))
scene.render.filepath=str(R/'COURSED_SPRINGING_DETAIL.png');bpy.ops.render.render(write_still=True)
print('RESULT',json.dumps(qa))
