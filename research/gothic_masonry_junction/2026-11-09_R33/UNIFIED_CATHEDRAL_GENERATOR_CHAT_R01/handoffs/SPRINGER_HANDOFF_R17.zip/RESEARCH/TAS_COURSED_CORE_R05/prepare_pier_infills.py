from pathlib import Path
import json
from shapely.geometry import Polygon
from shapely.ops import unary_union
from shapely.geometry.polygon import orient
from shapely import constrained_delaunay_triangles
R=Path(__file__).resolve().parent;D=json.loads((R/'PIER_CAP_INPUT.json').read_text())
cap=unary_union([Polygon(t) for t in D['pier_top']]);back=unary_union([Polygon(t) for t in D['lower_receivers']]);holes=unary_union([Polygon(r) for r in cap.interiors]).difference(back)
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
meshes=[]
for i,p in enumerate(parts(holes)):
 if p.area<.00001:continue
 p=orient(p,sign=1);v=[];lookup={};faces=[]
 def vertex(x,y,k):
  key=(float(x),float(y),1800. if k else 0.)
  if key not in lookup:lookup[key]=len(v);v.append(key)
  return lookup[key]
 for t in constrained_delaunay_triangles(p).geoms:
  pts=list(orient(t,sign=1).exterior.coords)[:-1];faces.extend([list(reversed([vertex(x,y,0) for x,y in pts])),[vertex(x,y,1) for x,y in pts]])
 for ring in [p.exterior,*p.interiors]:
  pts=list(ring.coords)
  for a,b in zip(pts,pts[1:]):faces.append([vertex(*a,0),vertex(*b,0),vertex(*b,1),vertex(*a,1)])
 meshes.append(dict(name='ENCLOSED_PIER_POCKET_INFILL_'+str(i),vertices=v,faces=faces,area=p.area))
(R/'PIER_INFILL_MESHES.json').write_text(json.dumps(meshes));print('PIER_INFILL',len(meshes),sum(p['area'] for p in meshes))
