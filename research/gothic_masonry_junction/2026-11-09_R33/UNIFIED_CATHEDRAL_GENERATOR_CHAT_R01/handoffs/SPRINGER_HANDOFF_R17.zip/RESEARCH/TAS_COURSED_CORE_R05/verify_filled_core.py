from pathlib import Path
import json,numpy as np
from shapely.geometry import Polygon
from shapely.ops import unary_union
R=Path(__file__).resolve().parent
prefix=(R/'fill_enclosed_pockets_exact.py').read_text().split('for k,(lo,hi)')[0]
old={'__file__':str(R/'fill_enclosed_pockets_exact.py')};exec(prefix,old)
new={'__file__':str(R/'fill_enclosed_pockets.py')};exec(prefix,new)
t=np.asarray(json.loads((R/'FILLED_ACTUAL_TRIANGLES.json').read_text()),float);new.update(tri=t,mins=t[:,:,2].min(axis=1),maxs=t[:,:,2].max(axis=1),cache={})
diag=json.loads((R/'FILLED_BUILD_DIAGNOSTIC.json').read_text())
levels=set([1800.05,2474.95,2200.05]+[1802.5+5*i for i in range(135)])
for z in diag['closure_vertex_heights']:
 for dz in [-.011,.011]:
  if 1800<z+dz<2475:levels.add(z+dz)
rows=[]
for z in sorted(levels):
 z=min(2474.999,max(1800.001,z+.000137))
 a=old['horizontal'](z)[1];b=new['horizontal'](z)[1]
 assert not a.is_empty and not b.is_empty,z
 desired=unary_union([Polygon(p.exterior) for p in old['parts'](a)])
 rings=sum(Polygon(r).area for p in new['parts'](b) for r in p.interiors)
 boundary=unary_union([p.exterior for p in old['parts'](desired)]).hausdorff_distance(unary_union([p.exterior for p in new['parts'](b)]))
 error=desired.symmetric_difference(b).area
 rows.append(dict(z=z,pocket_before=sum(Polygon(r).area for p in old['parts'](a) for r in p.interiors),pocket_after=rings,envelope_difference_area=error,outer_boundary_error=boundary,source_material_lost_area=a.difference(b).area,added_area=b.difference(a).area))
checks=dict(closed_solid=diag['nonmanifold_after']==0,all_sampled_pockets_filled=max(r['pocket_after'] for r in rows)<.01,filled_exterior_area_matches_source=max(r['envelope_difference_area'] for r in rows)<2,visible_outer_contours_preserved=max(r['outer_boundary_error'] for r in rows)<.005,original_material_not_removed=max(r['source_material_lost_area'] for r in rows)<2)
q=dict(checks=checks,sections=len(rows),worst_by_area=sorted(rows,key=lambda r:r['envelope_difference_area'],reverse=True)[:10],max_pocket_after=max(r['pocket_after'] for r in rows),max_boundary_error=max(r['outer_boundary_error'] for r in rows),rows=rows)
(R/'FILLED_CORE_QA.json').write_text(json.dumps(q,indent=2));print(json.dumps({k:v for k,v in q.items() if k!='rows'}));assert all(checks.values())
