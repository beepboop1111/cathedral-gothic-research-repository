from pathlib import Path
import json,collections,time
import numpy as np
import shapely
from shapely.geometry import Polygon,Point
from shapely.ops import unary_union,polygonize
R=Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());tri=np.asarray(D['triangles'],float)
mins=tri[:,:,2].min(axis=1);maxs=tri[:,:,2].max(axis=1);levels=np.unique(tri[:,:,2]);runs=[[] for _ in tri];last=np.full(len(tri),-2,int)
def parts(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [p for a in g.geoms for p in parts(a)]
def horizontal(z):
 ids=np.flatnonzero((mins<z)&(maxs>z));ts=tri[ids];a=ts;b=np.roll(ts,-1,axis=1)
 mask=(a[:,:,2]<z)&(b[:,:,2]>z)|(a[:,:,2]>z)&(b[:,:,2]<z)
 rows,cols=np.nonzero(mask);aa=a[rows,cols];bb=b[rows,cols];f=(z-aa[:,2])/(bb[:,2]-aa[:,2])
 pts=np.round(aa[:,:2]+f[:,None]*(bb[:,:2]-aa[:,:2]),7).reshape(-1,2,2)
 assert len(pts)==len(ids)
 candidates=list(polygonize(unary_union(shapely.linestrings(pts))))
 aa=pts[:,0];bb=pts[:,1]
 good=[]
 for p in candidates:
  q=p.representative_point();cross=(aa[:,1]>q.y)!=(bb[:,1]>q.y)
  x=aa[cross,0]+(q.y-aa[cross,1])*(bb[cross,0]-aa[cross,0])/(bb[cross,1]-aa[cross,1])
  if len(np.unique(np.round(x[x>q.x],6)))%2:good.append(p)
 g=unary_union(good)
 assert not g.is_empty,z
 outer=unary_union([p.exterior for p in parts(g)])
 midpoint=pts.mean(axis=1)
 dist=shapely.distance(shapely.points(midpoint),outer)
 return ids[dist<.00001],g
for k,(lo,hi) in enumerate(zip(levels,levels[1:])):
 ids,g=horizontal((lo+hi)/2)
 for i in ids:
  if last[i]==k-1:runs[i][-1][1]=float(hi)
  else:runs[i].append([float(lo),float(hi)])
  last[i]=k
 if k%250==0:print('INTERVAL',k,'of',len(levels)-1,flush=True)
critical=set()
for i,spans in enumerate(runs):
 for lo,hi in spans:
  if lo>mins[i]+1e-6:critical.add(lo)
  if hi<maxs[i]-1e-6:critical.add(hi)
critical=sorted(critical)
def clip(poly,z,above):
 result=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ina=a[2]>=z-1e-10 if above else a[2]<=z+1e-10;inb=b[2]>=z-1e-10 if above else b[2]<=z+1e-10
  if ina:result.append(a)
  if ina!=inb:
   f=(z-a[2])/(b[2]-a[2]);result.append([a[0]+f*(b[0]-a[0]),a[1]+f*(b[1]-a[1]),z])
 return result
vertices=[];lookup={};faces=[];original_triangles_retained=0
def vertex(v):
 key=tuple(round(float(x),7) for x in v)
 if key not in lookup:lookup[key]=len(vertices);vertices.append(list(key))
 return lookup[key]
for i,spans in enumerate(runs):
 for lo,hi in spans:
  cuts=[lo]+[z for z in critical if lo+1e-7<z<hi-1e-7]+[hi]
  for a,b in zip(cuts,cuts[1:]):
   p=clip(clip(tri[i].tolist(),a,True),b,False)
   ids=[vertex(v) for v in p];ids=[x for j,x in enumerate(ids) if j==0 or x!=ids[j-1]]
   if len(ids)>1 and ids[0]==ids[-1]:ids.pop()
   for j in range(1,len(ids)-1):
    if len({ids[0],ids[j],ids[j+1]})==3:faces.append([ids[0],ids[j],ids[j+1]])
counts=collections.Counter()
for f in faces:
 for a,b in zip(f,f[1:]+f[:1]):counts[tuple(sorted((a,b)))]+=1
boundary=[e for e,n in counts.items() if n==1]
nonhorizontal=[e for e in boundary if abs(vertices[e[0]][2]-vertices[e[1]][2])>1e-5]
report=dict(method='Exact source-triangle exterior classification in every vertex-height interval; split only at topological pocket/recess transitions; no outer contour interpolation',intervals=len(levels)-1,critical_levels=critical,source_triangles=len(tri),inner_triangles_removed=sum(not a for a in runs),side_triangles=len(faces),boundary_edges=len(boundary),nonhorizontal_boundary_edges=len(nonhorizontal),nonhorizontal_examples=[[vertices[i] for i in e] for e in nonhorizontal[:10]])
(R/'FILLED_MESH.json').write_text(json.dumps(dict(vertices=vertices,faces=faces)))
(R/'FILL_DIAGNOSTIC.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
