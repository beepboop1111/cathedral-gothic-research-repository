import bpy,bmesh,json,pathlib,hashlib,math,collections,subprocess
from mathutils import Vector
R=pathlib.Path(__file__).resolve().parent;D=json.loads((R/'INPUTS.json').read_text());filledqa=json.loads((R/'FILLED_CORE_QA.json').read_text());assert all(filledqa['checks'].values())
bpy.ops.wm.open_mainfile(filepath=str(R/'FILLED_CORE_CANDIDATE.blend'));bpy.context.view_layer.update()
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def sig(o):return hashlib.sha256(repr((coords(o),[tuple(p.vertices) for p in o.data.polygons])).encode()).hexdigest()
def triangles(o):
 o.data.calc_loop_triangles();v=coords(o);return [[list(v[i]) for i in t.vertices] for t in o.data.loop_triangles]
def cap(o,z):return [[v[:2] for v in t] for t in triangles(o) if all(abs(v[2]-z)<.0001 for v in t)]
checks=dict(all_R04_neighbors_curves_pier_and_receivers_unchanged=all(sig(bpy.data.objects[n])==h for n,h in D['protected'].items()))
body=bpy.data.objects['FILLED_CORE_R05'];levels=[1800.+135*i for i in range(6)]
def boolean(o,cut):
 bpy.context.view_layer.objects.active=o;m=o.modifiers.new('HORIZONTAL_BED','BOOLEAN');m.operation='INTERSECT';m.solver='EXACT';m.object=cut;bpy.ops.object.modifier_apply(modifier=m.name)
def cleanup(o):
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00001)
 bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.00000001)
 edges=[e for e in bm.edges if e.is_boundary]
 if edges:bmesh.ops.holes_fill(bm,edges=edges,sides=0)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));n=sum(not e.is_manifold for e in bm.edges);bm.to_mesh(o.data);bm.free();o.data.update();return n
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(p) for p in coords(o)];c=v[0]
 return sum((v[t.vertices[0]]-c).dot((v[t.vertices[1]]-c).cross(v[t.vertices[2]]-c))/6 for t in o.data.loop_triangles)
base=bpy.data.objects['SHARED_PIER_S'];receiver_names=[n for n in D['protected'] if n.startswith('RECEIVING_S_LOWER_')]
(R/'PIER_CAP_INPUT.json').write_text(json.dumps(dict(pier_top=cap(base,1800),lower_receivers=[t for n in receiver_names for t in cap(bpy.data.objects[n],1800)])))
checks['source_pier_is_straight_vertical_for_internal_fill']=all(abs(v[2])<.0001 or abs(v[2]-1800)<.0001 for v in coords(base))
subprocess.run(['/usr/bin/python3',str(R/'prepare_pier_infills.py')],check=True);infills=[]
for d in json.loads((R/'PIER_INFILL_MESHES.json').read_text()):
 me=bpy.data.meshes.new(d['name']);me.from_pydata(d['vertices'],[],d['faces']);me.update();o=bpy.data.objects.new(d['name'],me);bpy.context.scene.collection.objects.link(o);o.data.materials.append(base.data.materials[0]);cleanup(o);infills.append(o)
v=coords(body);lo=[min(p[k] for p in v) for k in range(3)];hi=[max(p[k] for p in v) for k in range(3)]
courses=[];repairs={}
for i,(a,b) in enumerate(zip(levels,levels[1:])):
 o=body.copy();o.data=body.data.copy();o.name='R05_SPRINGING_COURSE_%02d'%(i+1);bpy.context.scene.collection.objects.link(o)
 bpy.ops.mesh.primitive_cube_add(size=1,location=((lo[0]+hi[0])/2,(lo[1]+hi[1])/2,(a+b)/2));cut=bpy.context.object;cut.dimensions=(hi[0]-lo[0]+20,hi[1]-lo[1]+20,b-a);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 boolean(o,cut);bpy.data.objects.remove(cut,do_unlink=True);repairs[o.name]=cleanup(o)
 m=bpy.data.materials.new('COURSE_TONE_%d'%i);c=(.64+.025*(i%2),.48+.025*(i%2),.29+.025*(i%2),1);m.diffuse_color=c;m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=c;m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.85
 o.data.materials.clear();o.data.materials.append(m)
 for p in o.data.polygons:p.material_index=0
 courses.append(o)
body.hide_render=True;body.hide_set(True)
checks['five_courses_135_high']=len(courses)==5 and all(abs(max(v[2] for v in coords(o))-min(v[2] for v in coords(o))-135)<.0001 for o in courses)
checks['courses_closed_manifold']=all(n==0 for n in repairs.values())
checks['all_new_material_positive_volume']=all(volume(o)>0 for o in courses+infills)
checks['course_volumes_reconstruct_filled_body']=abs(sum(volume(o) for o in courses)-volume(body))/volume(body)<1e-5
checks['source_R04_saved_file_unchanged']=hashlib.sha256(pathlib.Path(D['source']).read_bytes()).hexdigest()==D['source_sha256']
upper=['CHAPEL_TRANSVERSE_31000','BAY1_RIB_1','BAY2_RIB_0','BAY1_FORMERET_0','BAY2_FORMERET_0']
supports=[base]+[bpy.data.objects[n] for n in receiver_names]+infills
data=dict(levels=levels,courses=[dict(name=o.name,z=[levels[i],levels[i+1]],triangles=triangles(o)) for i,o in enumerate(courses)],upper_ribs={n:triangles(bpy.data.objects[n]) for n in upper},base_supports={o.name:triangles(o) for o in supports})
(R/'COURSE_ACTUAL.json').write_text(json.dumps(data))
subprocess.run(['/usr/bin/python3',str(R/'verify_course_contacts.py')],check=True)
contact=json.loads((R/'COURSE_CONTACT_QA.json').read_text());checks.update(contact['checks']);checks.update(filledqa['checks'])
assert all(checks.values()),checks
bpy.ops.wm.save_as_mainfile(filepath=str(R/'TAS_COURSED_CORE_R05.blend'))
course_names=[o.name for o in courses];infill_names=[o.name for o in infills]
visible=[o for o in bpy.context.scene.objects if o.type=='MESH' and not o.hide_get() and not o.hide_render and not o.name.startswith('REFERENCE_')]
def snapshot(obs):
 result={}
 for o in obs:
  v=coords(o);o.data.calc_loop_triangles();ts=[]
  for t in o.data.loop_triangles:
   p=[tuple(round(v[i][k],3) for k in range(3)) for i in t.vertices];ts.append(min(tuple(p[j:]+p[:j]) for j in range(3)))
  result[o.name]=dict(bounds=[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]],triangles=sorted(ts))
 return result
before=snapshot(visible)
bpy.ops.object.select_all(action='DESELECT')
for o in visible:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(R/'TAS_COURSED_CORE_R05.glb'),export_format='GLB',use_selection=True,export_cameras=False,export_lights=False)
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.import_scene.gltf(filepath=str(R/'TAS_COURSED_CORE_R05.glb'));after=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
checks['GLB_names_counts_no_reference_duplicates']=set(before)==set(after)
err=max(abs(before[n]['bounds'][j][k]-after[n]['bounds'][j][k]) for n in before for j in range(2) for k in range(3))
checks['GLB_bounds_within_0_01']=err<.01
checks['GLB_oriented_triangle_signatures_at_0_001']=all(before[n]['triangles']==after[n]['triangles'] for n in before)
qa=dict(revision='TAS_COURSED_CORE_R05_EXPERIMENTAL',source=D['source'],source_sha256=D['source_sha256'],checks=checks,passed=sum(checks.values()),total=len(checks),course_levels=levels,filled_core_sections=filledqa['sections'],max_visible_boundary_error=filledqa['max_boundary_error'],max_pocket_area_after=filledqa['max_pocket_after'],pier_infill_count=len(infills),pier_infill_volume=sum(volume(bpy.data.objects[n]) for n in infill_names),bedding=contact['bedding'],top_contact=contact['top_contact'],base_contact=contact['base_contact'],glb_bounds_error=err,validation=dict(technical='watertight positive course meshes, volume reconstruction, actual GLB reimport and oriented triangle signatures',geometric='158 original-vs-filled sections, external recess preservation, exact shared bedding cap checks, actual pier and rib seating checks',architectural='experimental five135-unit courses and internal core infill; stone sizes/bond and course choice require review',historical='not assessed; recovered code used for checks only, no historical stone schedule inferred',structural='not assessed; no bearing stress, force-path or capacity approval; F5ZL-C schedule unresolved'))
(R/'QA.json').write_text(json.dumps(qa,indent=2));assert all(checks.values()),qa
# Preview copies are cropped only after export.
keep=set(upper+['SHARED_PIER_S']+course_names+infill_names+[n for n in D['protected'] if n.startswith('RECEIVING_S_')])
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and o.name not in keep:bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.mesh.primitive_cube_add(size=1,location=(31000,-1200,2250));cut=bpy.context.object;cut.dimensions=(1500,1700,1500);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
for o in list(bpy.context.scene.objects):
 if o.type=='MESH' and o!=cut:
  boolean(o,cut)
  if not len(o.data.polygons):bpy.data.objects.remove(o,do_unlink=True)
bpy.data.objects.remove(cut,do_unlink=True)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX'
scene.render.resolution_x=1200;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(32050,100,3200));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=2150;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(31000,-1175,2240))
for loc,power,size in [((31000,1000,7000),1500000000,4000),((28000,-3500,5000),1300000000,4000)]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,(31000,-1250,2200))
scene.render.filepath=str(R/'COURSED_SPRINGING_DETAIL.png');bpy.ops.render.render(write_still=True)
print('RESULT',json.dumps(qa))
