#!/usr/bin/env python3
"""Read-only diagnostics for saved springer build stages; geometry stays untouched."""
import argparse,collections,json,pathlib,sys
import numpy as np
sys.path.insert(0,'/home/christopher/Documents/Cathedral/experimental/SPRINGER_ENGINE_R06');import springer_core as core

def edge_analysis(triangles,decimals=5):
 edges=collections.Counter()
 for tri in triangles:
  v=[tuple(round(float(x),decimals) for x in pt) for pt in tri]
  for a,b in ((0,1),(1,2),(2,0)):edges[tuple(sorted((v[a],v[b])))]+=1
 bad=[{'endpoints':[list(a),list(b)],'incident_triangles':n,'length':float(np.linalg.norm(np.array(a)-b))} for (a,b),n in edges.items() if n!=2]
 return {'quantization_decimals':decimals,'edges':len(edges),'abnormal_edge_count':len(bad),'by_incidence':dict(collections.Counter(str(x['incident_triangles']) for x in bad)),'examples':bad[:30],'note':'Quantized triangle-edge diagnostic; triangulation and quantization can affect counts. Confirm on source mesh.'}

def diagnose(folder,samples):
 folder=pathlib.Path(folder);config=json.loads((folder/'config.json').read_text());raw_path=folder/'raw_geometry.json';data={'source_directory':str(folder),'status':'partial','notes':[]};levels=config['course_levels'];lo,hi=levels[0],levels[-1];data['spring_level']=lo;data['top_level']=hi;data['course_levels']=levels
 raw=json.loads(raw_path.read_text()) if raw_path.exists() else None
 if raw:data['raw_mesh_edge_diagnostic']=edge_analysis(raw['common'])
 else:data['notes'].append('No raw geometry; mesh diagnosis unavailable')
 qa=folder/'QA.json';geom=folder/'GEOMETRY_QA.json'
 if qa.exists():
  q=json.loads(qa.read_text());data['status']='completed' if all(q['checks'].values()) else 'failed';data['recorded_checks']={'passed':q['passed'],'total':q['total'],'failures':[k for k,v in q['checks'].items() if not v]}
 elif geom.exists():
  q=json.loads(geom.read_text());data['status']='failed';data['recorded_checks']={'passed':sum(q['checks'].values()),'total':len(q['checks']),'failures':[k for k,v in q['checks'].items() if not v]}
 logs={n:(folder/n).read_text(errors='replace') for n in ('RAW_BUILD.log','FILL.log','FINISH.log') if (folder/n).exists()};combined='\n'.join(logs.values())
 if 'Filled support section must be one solid polygon' in combined:data['recorded_failure']='base footprint is not one solid polygon'
 elif 'profile_cluster_and_receiver_connected' in data.get('recorded_checks',{}).get('failures',[]):data['recorded_failure']='section connectivity check failed'
 elif 'assert bad==0' in combined:data['recorded_failure']='raw union contains non-manifold edge(s)'
 elif 'Traceback (most recent call last)' in combined:data['recorded_failure']='inspect stage logs for exception'
 if 'recorded_failure' in data and data['status']!='completed':data['status']='failed'
 f=folder/'filled_actual.json'
 if f.exists():
  tris=json.loads(f.read_text());rows=[]
  for z in np.linspace(lo+.05,hi-.05,samples):
   z=float(z)+.000137
   try:
    parts=core.polygon_parts(core.section_geometry(tris,z));rows.append({'z':z,'components':len(parts),'areas':sorted([float(p.area) for p in parts],reverse=True)})
   except Exception as e:rows.append({'z':z,'error':str(e) or type(e).__name__})
  changes=[]
  for a,b in zip(rows,rows[1:]):
   if 'components' in a and 'components' in b and a['components']!=b['components']:changes.append({'from_z':a['z'],'to_z':b['z'],'from_count':a['components'],'to_count':b['components']})
  data['sections']={'samples':rows,'component_count_changes':changes,'note':'Sampled horizontal sections, not continuous proof. Separation can be intentional; assess course boundaries and bearings.'}
 else:data['notes'].append('No filled geometry; separation sampling unavailable')
 return data

def main():
 p=argparse.ArgumentParser();p.add_argument('build',type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);p.add_argument('--samples',type=int,default=25);a=p.parse_args()
 if not 2<=a.samples<=201:p.error('samples must be 2–201')
 d=diagnose(a.build,a.samples);a.out.mkdir(parents=True,exist_ok=False);(a.out/'diagnostics.json').write_text(json.dumps(d,indent=2));print(json.dumps({'status':d['status'],'recorded_failure':d.get('recorded_failure'),'bad_edges':d.get('raw_mesh_edge_diagnostic',{}).get('abnormal_edge_count'),'section_changes':d.get('sections',{}).get('component_count_changes'),'section_errors':sum('error' in x for x in d.get('sections',{}).get('samples',[]))},indent=2))
if __name__=='__main__':
 try:main()
 except (OSError,ValueError,KeyError) as e:print('DIAGNOSTIC ERROR:',e,file=sys.stderr);sys.exit(2)
