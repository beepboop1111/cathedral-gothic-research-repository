# R13 diagnostic checkpoint

New standalone read-only analyzer; no generator geometry or original R04–R12 files modified. Uses saved raw triangle geometry, filled geometry when present, recorded check results and stage logs. Numeric 1:1 native coordinates; Z_UP; no verified SI scale. R08 backing workaround and unresolved F5ZL-C support data remain unchanged.

Regression: 4/4 saved-fixture expectations passed. R10 three-bearing case: 25-section sample has 1 component at Z499.96680366666675 and 2 at Z524.9626370000001; actual change within sampled interval only, and intentional separation versus inadequate common course remains undecided. R10 five-bearing raw union: quantized edge from (0,-0.01,0) to (0,0,0), 4 incident triangles, 1 abnormal edge. Disconnected-base negative fixture explicitly reports support footprint failure. R12 passing fixture completed 78/78 previously including Blender 5.0.1 GLB reimport; diagnostic reported no abnormal raw edges or sampled section count changes. R13 only reads saved cases, does not itself rebuild or reimport a GLB.

This pass does not repair any failure and is not integrated into the build wrapper. No automatic judgement of architectural correctness, structural capacity, historical practice or branch-separation intent. Test results and concise numerical reports are saved next to the tool. No GitHub.
