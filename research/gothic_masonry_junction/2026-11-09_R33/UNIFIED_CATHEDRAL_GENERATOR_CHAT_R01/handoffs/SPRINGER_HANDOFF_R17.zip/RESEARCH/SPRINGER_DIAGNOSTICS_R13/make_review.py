import pathlib,sys,json
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
sys.path.insert(0,'/home/christopher/Documents/Cathedral/experimental/SPRINGER_ENGINE_R06');import springer_core as c
p=pathlib.Path('/home/christopher/Documents/Cathedral/experimental');out=p/'SPRINGER_DIAGNOSTICS_R13';d=json.loads((out/'three/diagnostics.json').read_text());change=d['sections']['component_count_changes'][0];tri=json.loads((p/'SPRINGER_PROFILE_R10/build/filled_actual.json').read_text());fig=plt.figure(figsize=(15,9),facecolor='#f0ece4');grid=fig.add_gridspec(2,3,width_ratios=[1.25,1,1],height_ratios=[3.3,1.0]);ax=fig.add_subplot(grid[0,0]);ax.imshow(mpimg.imread(p/'SPRINGER_CONTROLS_R12/test_build/variant_review.png'));ax.set_title('PASSING FIXTURE / GLB REIMPORT');ax.axis('off')
for col,z in enumerate((change['from_z'],change['to_z']),1):
 a=fig.add_subplot(grid[0,col]);polys=c.polygon_parts(c.section_geometry(tri,z));colors=['#85735d','#bc5738','#798b99','#4c6480']
 for j,part in enumerate(polys):
  x,y=part.exterior.xy;a.fill(x,y,color=colors[j%len(colors)],edgecolor='#202b32',linewidth=.6)
  for ring in part.interiors:
   x,y=ring.xy;a.fill(x,y,color='#f0ece4')
 a.set_aspect('equal');a.set_xlim(-390,390);a.set_ylim(-360,450);a.set_title('Z %.2f  |  %d COMPONENT%s'%(z,len(polys),'' if len(polys)==1 else 'S'));a.set_xlabel('X (native units)');a.set_ylabel('Y (native units)')
ax=fig.add_subplot(grid[1,:]);ax.axis('off');ax.text(.01,.85,'R13 DIAGNOSTICS: sampled separation Z %.2f–%.2f; interpretation of branch separation remains open.'%(change['from_z'],change['to_z']),fontsize=12,transform=ax.transAxes);ax.text(.01,.53,'Five-bearing test: one four-face edge at (0, -0.01, 0) to (0, 0, 0).',fontsize=12,transform=ax.transAxes);ax.text(.01,.21,'Disconnected-base fixture rejected; passing fixture unflagged. 4 / 4 regression expectations passed.',fontsize=12,transform=ax.transAxes);fig.suptitle('SPRINGER GEOMETRY DIAGNOSTICS',fontsize=19,fontweight='bold');fig.tight_layout(rect=[0,0,1,.95]);fig.savefig(out/'SPRINGER_DIAGNOSTICS_R13_RESULT.png',dpi=130,facecolor=fig.get_facecolor());plt.close(fig)
