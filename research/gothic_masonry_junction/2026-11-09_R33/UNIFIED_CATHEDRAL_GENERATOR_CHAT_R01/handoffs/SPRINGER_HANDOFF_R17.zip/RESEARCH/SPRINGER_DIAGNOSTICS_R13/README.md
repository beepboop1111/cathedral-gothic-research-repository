# R13 diagnostic reader — experimental

Run on an existing R06-compatible output folder:

    python3 diagnose.py /path/to/build --out /path/to/NEW_DIAGNOSTICS --samples 25

Read-only on the build. Produces a separate diagnostics.json and terminal summary: previously recorded stage errors, quantized raw triangle edge incidences, and filled-section component counts and change brackets when data exists. It accepts failed or completed builds with config.json, and flags missing stage data rather than asserting success. Existing output directories are not overwritten. Up to 201 sections may be selected.

Sections are discrete samples, so change brackets depend on spacing; they are not exact transition elevations or proof between samples. More than one polygon in a slice may be appropriate above a springing block or indicate an unsound course: architectural, bearing and bonding review is required. Edge incidence is measured after rounding to 5 decimal places in native units, so confirm against the original Blender mesh and distinguish touching shells from a real defect. Self-intersection, full 3D clearances, physical loads and ultimate strength are not assessed. When an earlier stage did not save geometry, that analysis remains unavailable. A status of completed means saved checks reported pass, not design approval. The runner does not automatically call these diagnostics yet.

Test the four saved fixtures on MR COMPUTER: `python3 test_diagnostics.py`. Requires existing R06, numpy and Shapely, and the original R10/R12 fixture paths. The comparison image uses the previous R12 GLB-reimport render and sections from the failed three-bearing trial; no geometry is regenerated or changed.
