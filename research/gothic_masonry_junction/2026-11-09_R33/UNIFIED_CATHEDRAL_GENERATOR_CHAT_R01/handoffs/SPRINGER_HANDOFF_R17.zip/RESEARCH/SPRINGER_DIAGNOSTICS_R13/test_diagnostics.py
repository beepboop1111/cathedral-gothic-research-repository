import pathlib,unittest
from diagnose import diagnose
root=pathlib.Path('/home/christopher/Documents/Cathedral/experimental')
class Diagnosis(unittest.TestCase):
 def test_separating_cluster(self):
  d=diagnose(root/'SPRINGER_PROFILE_R10/build',25);self.assertEqual(d['status'],'failed');self.assertEqual(d['recorded_failure'],'section connectivity check failed');self.assertTrue(any(x['from_count']==1 and x['to_count']==2 for x in d['sections']['component_count_changes']))
 def test_four_face_edge(self):
  d=diagnose(root/'SPRINGER_PROFILE_R10/five_build',25);self.assertEqual(d['status'],'failed');self.assertEqual(d['raw_mesh_edge_diagnostic']['by_incidence'],{'4':1});self.assertEqual(d['recorded_failure'],'raw union contains non-manifold edge(s)')
 def test_disconnected_base(self):
  d=diagnose(root/'SPRINGER_PROFILE_R10/disconnected_build',25);self.assertEqual(d['status'],'failed');self.assertEqual(d['recorded_failure'],'base footprint is not one solid polygon')
 def test_passing_fixture(self):
  d=diagnose(root/'SPRINGER_CONTROLS_R12/test_build',25);self.assertEqual(d['status'],'completed');self.assertEqual(d['raw_mesh_edge_diagnostic']['abnormal_edge_count'],0);self.assertFalse(d['sections']['component_count_changes']);self.assertFalse(any('error' in x for x in d['sections']['samples']))
if __name__=='__main__':unittest.main()
