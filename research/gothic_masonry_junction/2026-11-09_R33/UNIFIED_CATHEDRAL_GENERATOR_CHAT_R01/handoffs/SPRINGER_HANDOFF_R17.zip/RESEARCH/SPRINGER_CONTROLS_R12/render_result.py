from PIL import Image,ImageDraw,ImageFont,ImageOps
from pathlib import Path
p=Path(__file__).parent;im=Image.new('RGB',(1600,1000),'#e8e4dc');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';b='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';title=ImageFont.truetype(b,34);font=ImageFont.truetype(f,23);small=ImageFont.truetype(f,20);d.text((40,25),'BEARING AND COURSE CONTROLS  |  R12',font=title,fill='#222b31');view=Image.open(p/'test_build/variant_review.png').convert('RGB');view.thumbnail((820,820));im.paste(view,(40,105));x=915;d.text((x,115),'TEST SETTINGS',font=ImageFont.truetype(b,27),fill='#222b31');items=['Member 2 bearing: 43.16944°','Spring datum: Z0 (unchanged)','Backing: existing R08 receiver','Courses: 0 / 100 / 210 / 330 / 460 / 600','Native units; experimental fixture','','Blender GLB reimport: 78/78','Input and safety checks: 9/9','Architectural review pending']
for i,t in enumerate(items):d.text((x,175+i*43),t,font=small,fill='#222b31')
d.text((x,650),'Course levels',font=font,fill='#222b31');z=[0,100,210,330,460,600];x0=970;y0=945;scale=.37
for i,(lo,hi) in enumerate(zip(z,z[1:])):
 y1=y0-hi*scale;y2=y0-lo*scale;d.rectangle((x0,y1,x0+170,y2),fill=('#bca588' if i%2==0 else '#d2bea3'),outline='#675542',width=2)
for a in z:
 y=y0-a*scale;d.line((x0+172,y,x0+190,y),fill='#333333',width=2);d.text((x0+200,y-10),str(a),font=small,fill='#222b31')
im.save(p/'SPRINGER_CONTROLS_R12_RESULT.png')
