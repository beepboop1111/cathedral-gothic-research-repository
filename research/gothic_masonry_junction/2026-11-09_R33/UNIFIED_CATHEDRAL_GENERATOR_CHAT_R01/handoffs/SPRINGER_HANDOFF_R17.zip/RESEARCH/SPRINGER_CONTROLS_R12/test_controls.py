import pathlib,json,unittest,copy
import controls as c
base=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/SPRINGER_PROFILE_INPUT_R11/build_input/manifest.json');cfg=json.loads(base.read_text());lib=json.loads(pathlib.Path(cfg['input_library']).read_text())
class Controls(unittest.TestCase):
 def call(self,**kw):
  x=dict(bearings={},carriers={},levels=None,spring=None,backing=None);x.update(kw);return c.configure(cfg,lib,**x)
 def test_edits_and_source_preservation(self):
  a=copy.deepcopy(cfg);x=self.call(bearings={'member_2':'43'},levels=[0,100,210,330,460,600]);self.assertEqual(cfg,a);self.assertEqual(x['course_levels'],[0,100,210,330,460,600]);self.assertEqual(next(m for m in x['members'] if m['id']=='member_2')['bearing_degrees'],43)
 def test_mesh_bearing_rejected(self):
  with self.assertRaises(ValueError):self.call(bearings={'member_0':'10'})
 def test_nonfinite_rejected(self):
  with self.assertRaises(ValueError):self.call(bearings={'member_2':'nan'})
 def test_bad_course_order_rejected(self):
  with self.assertRaises(ValueError):self.call(levels=[0,150,140,600])
 def test_datum_change_rejected(self):
  with self.assertRaises(ValueError):self.call(spring=50)
 def test_unknown_carrier_rejected(self):
  with self.assertRaises(ValueError):self.call(carriers={'member_2':'missing'})
 def test_bad_backing_rejected(self):
  with self.assertRaises(ValueError):self.call(backing='missing')
 def test_backing_selection(self):self.assertNotIn('backing',self.call(backing='none'))
 def test_ends_fixed(self):
  with self.assertRaises(ValueError):self.call(levels=[0,200,601])
if __name__=='__main__':unittest.main()
