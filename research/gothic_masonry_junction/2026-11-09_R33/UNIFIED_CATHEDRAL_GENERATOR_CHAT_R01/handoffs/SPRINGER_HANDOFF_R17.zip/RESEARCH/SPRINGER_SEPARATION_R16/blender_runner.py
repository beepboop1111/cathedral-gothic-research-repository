import bpy,bmesh,sys,json,pathlib,hashlib,math,collections,subprocess
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parent
stage=sys.argv[sys.argv.index('--')+1];OUT=pathlib.Path(sys.argv[sys.argv.index('--')+2]);C=json.loads((OUT/'config.json').read_text());I=json.loads((OUT/'resolved_inputs.json').read_text());levels=C['course_levels'];low,high=levels[0],levels[-1]
def coords(o):return [tuple(o.matrix_world@v.co) for v in o.data.vertices]
def triangles(o):
 o.data.calc_loop_triangles();v=coords(o);return [[list(v[i]) for i in t.vertices] for t in o.data.loop_triangles]
def mesh(name,d):
 m=bpy.data.meshes.new(name);m.from_pydata(d['vertices'],[],d['faces']);m.update();o=bpy.data.objects.new(name,m);bpy.context.scene.collection.objects.link(o);return o
def boolean(o,other,op):
 bpy.context.view_layer.objects.active=o;m=o.modifiers.new('LOCAL_STONE_PARTITION','BOOLEAN');m.operation=op;m.solver='EXACT';m.object=other;bpy.ops.object.modifier_apply(modifier=m.name)
def box(name,bounds):
 x0,x1,y0,y1,z0,z1=bounds;bpy.ops.mesh.primitive_cube_add(size=1,location=((x0+x1)/2,(y0+y1)/2,(z0+z1)/2));o=bpy.context.object;o.name=name;o.dimensions=(x1-x0,y1-y0,z1-z0);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return o
def cleanup(o):
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00001);bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.00000001)
 edge=[e for e in bm.edges if e.is_boundary]
 if edge:bmesh.ops.holes_fill(bm,edges=edge,sides=0)
 bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bad=sum(not e.is_manifold for e in bm.edges);bm.to_mesh(o.data);bm.free();o.data.update();return bad
def component_count(o):
 bm=bmesh.new();bm.from_mesh(o.data);remaining=set(bm.verts);count=0
 while remaining:
  count+=1;stack=[remaining.pop()]
  while stack:
   v=stack.pop()
   for edge in v.link_edges:
    other=edge.other_vert(v)
    if other in remaining:remaining.remove(other);stack.append(other)
 bm.free();return count
def material(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*color,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.85;return m
def assign(o,m):
 o.data.materials.clear();o.data.materials.append(m)
 for p in o.data.polygons:p.material_index=0
def volume(o):
 o.data.calc_loop_triangles();v=[Vector(p) for p in coords(o)];a=v[0]
 return sum((v[t.vertices[0]]-a).dot((v[t.vertices[1]]-a).cross(v[t.vertices[2]]-a))/6 for t in o.data.loop_triangles)
if stage=='raw':
 bpy.ops.wm.read_factory_settings(use_empty=True);sources=[]
 stone=material('fixture_members',(.73,.65,.51))
 for member in I['members']:
  o=mesh(member['id'],member['mesh']);assign(o,stone);sources.append(o)
 if I.get('backing'):
  o=mesh('receiver',I['backing']);assign(o,stone);sources.append(o)
 original={o.name:triangles(o) for o in sources}
 cut=box('TEMP_COMMON_REGION',C['study_region']);pieces=[]
 for o in sources:
  p=o.copy();p.data=o.data.copy();p.name='TEMP_'+o.name;bpy.context.scene.collection.objects.link(p);boolean(p,cut,'INTERSECT')
  if len(p.data.polygons):pieces.append(p)
  else:bpy.data.objects.remove(p,do_unlink=True)
 body=pieces[0]
 for p in pieces[1:]:boolean(body,p,'UNION');bpy.data.objects.remove(p,do_unlink=True)
 body.name='raw_common_block';bad=cleanup(body)
 for o in sources:boolean(o,cut,'DIFFERENCE');cleanup(o)
 bpy.data.objects.remove(cut,do_unlink=True)
 (OUT/'raw_geometry.json').write_text(json.dumps(dict(common=triangles(body),original_members=original,open_edges_after_cleanup=bad)))
 assert bad==0,bad
 bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'raw_fixture.blend'))
 print('RAW_FIXTURE_READY',flush=True)
elif stage=='finish':
 bpy.ops.wm.open_mainfile(filepath=str(OUT/'raw_fixture.blend'))
 original=bpy.data.objects['raw_common_block'];original.name='REFERENCE_UNFILLED_COMMON';original.hide_render=True;original.hide_set(True)
 body=mesh('filled_common_reference',json.loads((OUT/'filled_mesh.json').read_text()));assert cleanup(body)==0
 (OUT/'filled_actual.json').write_text(json.dumps(triangles(body)))
 subprocess.run(['/usr/bin/python3',str(ROOT/'case_tools.py'),'support',str(OUT)],check=True)
 support=mesh('derived_respond',json.loads((OUT/'support_mesh.json').read_text()));assert cleanup(support)==0
 assign(support,material('respond',(.68,.56,.39)))
 v=coords(body);x0=min(p[0] for p in v)-10;x1=max(p[0] for p in v)+10;y0=min(p[1] for p in v)-10;y1=max(p[1] for p in v)+10
 courses=[];bad={}
 split=bmesh.new();split.from_mesh(body.data);bmesh.ops.triangulate(split,faces=list(split.faces))
 for height in levels[1:-1]:bmesh.ops.bisect_plane(split,geom=list(split.verts)+list(split.edges)+list(split.faces),plane_co=(0,0,height),plane_no=(0,0,1),dist=.0000001,clear_inner=False,clear_outer=False)
 for i,(a,b) in enumerate(zip(levels,levels[1:])):
  p=body.copy();p.data=body.data.copy();p.name='course_%02d'%(i+1);bpy.context.scene.collection.objects.link(p)
  bm=split.copy();discard=[face for face in bm.faces if face.calc_center_median().z<a-.00001 or face.calc_center_median().z>b+.00001]
  bmesh.ops.delete(bm,geom=discard,context='FACES');bm.to_mesh(p.data);bm.free();p.data.update();bad[p.name]=cleanup(p)
  assert len(p.data.vertices)>0,('empty course',i,a,b)
  assign(p,material('bed_tone_%d'%i,(.60+.065*(i%2),.46+.065*(i%2),.29+.065*(i%2))));courses.append(p)
 split.free();body.hide_render=True;body.hide_set(True)
 upper={m['id']:triangles(bpy.data.objects[m['id']]) for m in I['members']}
 (OUT/'courses_actual.json').write_text(json.dumps(dict(courses=[dict(name=o.name,triangles=triangles(o)) for o in courses],upper_members=upper,support=triangles(support))))
 counts={o.name:component_count(o) for o in courses};checks=dict(each_course_single_connected_mesh=all(n==1 for n in counts.values()),courses_closed_manifold=all(v==0 for v in bad.values()),all_new_stones_positive_volume=all(volume(o)>0 for o in courses+[support]),course_volume_reconstructs_filled_core=abs(sum(volume(o) for o in courses)-volume(body))/volume(body)<1e-5)
 subprocess.run(['/usr/bin/python3',str(ROOT/'case_tools.py'),'verify',str(OUT)],check=True)
 geometry=json.loads((OUT/'GEOMETRY_QA.json').read_text());inputs=json.loads((OUT/'INPUT_QA.json').read_text());checks.update(geometry['checks']);checks.update(inputs['checks'])
 for i,record in enumerate(I.get('source_files',[])):
  checks['protected_source_'+str(i)+'_hash_unchanged']=hashlib.sha256(pathlib.Path(record['path']).read_bytes()).hexdigest()==record['sha256']
 assert all(checks.values()),checks
 bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'springer_variant.blend'))
 visible=[o for o in bpy.context.scene.objects if o.type=='MESH' and not o.hide_get() and not o.hide_render]
 def snapshot(obs):
  out={}
  for o in obs:
   v=coords(o);o.data.calc_loop_triangles();ts=[]
   for t in o.data.loop_triangles:
    p=[tuple(round(v[i][k],4) for k in range(3)) for i in t.vertices];ts.append(min(tuple(p[j:]+p[:j]) for j in range(3)))
   out[o.name]=dict(bounds=[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]],triangles=sorted(ts))
  return out
 before=snapshot(visible);bpy.ops.object.select_all(action='DESELECT')
 for o in visible:o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(OUT/'springer_variant.glb'),export_format='GLB',use_selection=True,export_cameras=False,export_lights=False)
 for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
 bpy.ops.import_scene.gltf(filepath=str(OUT/'springer_variant.glb'));after=snapshot([o for o in bpy.context.scene.objects if o.type=='MESH'])
 checks['GLB_object_names_count']=set(before)==set(after)
 err=max(abs(before[n]['bounds'][j][k]-after[n]['bounds'][j][k]) for n in before for j in range(2) for k in range(3))
 checks['GLB_bounds_within_0_005']=err<=.005;checks['GLB_oriented_triangles_0_0001']=all(before[n]['triangles']==after[n]['triangles'] for n in before)
 qa=dict(status='R06_REUSABLE_INPUT_ENGINE_EXPERIMENTAL',checks=checks,passed=sum(checks.values()),total=len(checks),input_metadata=I['metadata'],input_change=C.get('change',{}),courses=levels,geometry=geometry,glb_bounds_error=err,validation=dict(technical='config/API guards, mesh execution, actual GLB reimport',geometric='changed input section/bearing, 61 filled sections, shared bed and rib seating checks',architectural='isolated fixture, no cathedral adoption or approved generator replacement',historical='not assessed; modified section is experimental',structural='not assessed; physical capacity and F5ZL-C schedule unresolved'))
 (OUT/'QA.json').write_text(json.dumps(qa,indent=2));assert all(checks.values()),qa
 # Crop imported geometry for this one review render only.
 cut=box('TEMP_REVIEW_REGION',[-750,750,-600,1100,-300,1200])
 for o in list(bpy.context.scene.objects):
  if o.type=='MESH' and o!=cut:
   boolean(o,cut,'INTERSECT')
   if not len(o.data.polygons):bpy.data.objects.remove(o,do_unlink=True)
 bpy.data.objects.remove(cut,do_unlink=True)
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=40;scene.world=scene.world or bpy.data.worlds.new('ReviewWorld');scene.world.color=(.65,.65,.65);scene.view_settings.view_transform='AgX';scene.render.resolution_x=1200;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
 def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
 bpy.ops.object.camera_add(location=(1050,1350,1400));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=2150;cam.data.clip_end=100000;scene.camera=cam;aim(cam,(0,75,440))
 for loc,power in [((0,2250,5200),1500000000),((-3000,-2250,3200),1300000000)]:
  bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.data.energy=power;o.data.shape='DISK';o.data.size=4000;aim(o,(0,0,400))
 scene.render.filepath=str(OUT/'variant_review.png');bpy.ops.render.render(write_still=True)
 print('VARIANT_FINISHED',qa['passed'],qa['total'],flush=True)
