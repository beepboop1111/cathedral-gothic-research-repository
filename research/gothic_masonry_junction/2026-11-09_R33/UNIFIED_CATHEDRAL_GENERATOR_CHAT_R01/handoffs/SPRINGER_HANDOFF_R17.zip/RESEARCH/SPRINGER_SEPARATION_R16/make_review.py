import pathlib,sys,json
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
sys.path.insert(0,'/home/christopher/Documents/Cathedral/experimental/SPRINGER_SEPARATION_R16');import springer_core as c
p=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/SPRINGER_SEPARATION_R16');tri=json.loads((p/'build/filled_actual.json').read_text());fig=plt.figure(figsize=(15,9),facecolor='#f0ece4');grid=fig.add_gridspec(2,3,width_ratios=[1.3,1,1],height_ratios=[3.3,1]);ax=fig.add_subplot(grid[0,0]);ax.imshow(mpimg.imread(p/'build/variant_review.png'));ax.set_title('THREE-BEARING FIXTURE / GLB REIMPORT');ax.axis('off')
for col,z in enumerate((500.000137,520.000137),1):
 a=fig.add_subplot(grid[0,col]);polys=c.polygon_parts(c.section_geometry(tri,z));colors=['#85735d','#bc5738']
 for j,part in enumerate(polys):
  x,y=part.exterior.xy;a.fill(x,y,color=colors[j%2],edgecolor='#202b32',linewidth=.6)
  for ring in part.interiors:x,y=ring.xy;a.fill(x,y,color='#f0ece4')
 a.set_aspect('equal');a.set_xlim(-390,390);a.set_ylim(-360,450);a.set_title('Z %.0f  |  %d COMPONENT%s'%(z,len(polys),'' if len(polys)==1 else 'S'));a.set_xlabel('X (native units)');a.set_ylabel('Y (native units)')
ax=fig.add_subplot(grid[1,:]);ax.axis('off');ax.text(.01,.85,'Connected solid courses; horizontal sections split near Z508.396, above the Z480 bedding plane.',fontsize=12,transform=ax.transAxes);ax.text(.01,.53,'79/79 technical/geometric checks; trial geometry unchanged. Disconnected base and invalid policy rejected.',fontsize=12,transform=ax.transAxes);ax.text(.01,.21,'Experimental opt-in policy; separation and stone construction still need architectural review.',fontsize=12,transform=ax.transAxes);fig.suptitle('SPRINGER BRANCH SEPARATION STUDY',fontsize=19,fontweight='bold');fig.tight_layout(rect=[0,0,1,.95]);fig.savefig(p/'SPRINGER_SEPARATION_R16_RESULT.png',dpi=130,facecolor=fig.get_facecolor())
