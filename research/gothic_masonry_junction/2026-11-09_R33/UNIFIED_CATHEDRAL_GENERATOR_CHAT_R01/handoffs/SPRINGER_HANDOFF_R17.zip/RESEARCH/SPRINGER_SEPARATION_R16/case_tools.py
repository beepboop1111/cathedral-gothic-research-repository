import sys,json,pathlib,numpy as np
from shapely.geometry import Polygon
from shapely.ops import unary_union
import springer_core as core
out=pathlib.Path(sys.argv[2]);mode=sys.argv[1];c=json.loads((out/'config.json').read_text())
if mode=='support':
 t=json.loads((out/'filled_actual.json').read_text());cap=core.cap_geometry(t,c['course_levels'][0])
 parts=core.polygon_parts(cap)
 if len(parts)!=1 or parts[0].interiors:raise ValueError('Filled support section must be one solid polygon')
 (out/'support_mesh.json').write_text(json.dumps(core.vertical_prism(parts[0],c['course_levels'][0]-300,c['course_levels'][0])))
elif mode=='verify':
 raw=json.loads((out/'raw_geometry.json').read_text());filled=json.loads((out/'filled_actual.json').read_text());actual=json.loads((out/'courses_actual.json').read_text())
 checks={};metrics={};levels=c['course_levels'];lo,hi=levels[0],levels[-1];tol=c.get('tolerances',dict(area=2.,length=.005));gaps=[]
 for z in np.linspace(lo+.05,hi-.05,61):
  z=float(z)+.000137
  a=core.section_geometry(raw['common'],z);b=core.section_geometry(filled,z);desired=unary_union([Polygon(p.exterior) for p in core.polygon_parts(a)])
  error=desired.symmetric_difference(b).area;pocket=sum(Polygon(r).area for p in core.polygon_parts(b) for r in p.interiors)
  boundary=desired.boundary.hausdorff_distance(b.boundary)
  checks['section_'+str(round(z,3))+'_filled_external_shape']=error<=tol['area'] and boundary<=tol['length'] and pocket<.01
  gaps.append(boundary)
 beds=[]
 for i in range(len(actual['courses'])-1):
  z=levels[i+1];a=core.cap_geometry(actual['courses'][i]['triangles'],z);b=core.cap_geometry(actual['courses'][i+1]['triangles'],z)
  missing=b.difference(a).area;difference=a.symmetric_difference(b).area;contact=a.intersection(b).area/b.area
  checks['bed_'+str(i)+'_matches_actual_exported_caps']=missing<=tol['area'] and difference<=tol['area'] and a.boundary.hausdorff_distance(b.boundary)<=tol['length']
  beds.append(dict(z=z,supported_fraction=contact,unsupported_area=missing,contour_difference_area=difference))
 top=core.cap_geometry(actual['courses'][-1]['triangles'],hi)
 # Only the requested local spring cluster, excluding far ends of full source meshes.
 region=c['study_region'];from shapely.geometry import box
 mask=box(region[0],region[2],region[1],region[3])
 ribs=unary_union([core.cap_geometry(t,hi) for t in actual['upper_members'].values()]).intersection(mask)
 missing=ribs.difference(top).area
 maxgap=max((top.distance(p.exterior.interpolate(p.exterior.length*j/200)) for p in core.polygon_parts(ribs) for j in range(201)),default=0)
 checks['top_rib_contact']=missing<=tol['area'] and maxgap<=tol['length']
 bottom=core.cap_geometry(actual['courses'][0]['triangles'],lo);support=core.cap_geometry(actual['support'],lo);base_missing=bottom.difference(support).area
 checks['base_full_geometric_seating']=base_missing<=tol['area']
 policy=c.get('connectivity_policy',{'mode':'single_all_heights'})
 mode=policy.get('mode');transition=policy.get('single_core_to_z')
 if mode=='single_all_heights':limit=hi
 elif mode=='single_core_to_z':
  if transition is None or not np.isfinite(transition) or not lo<transition<hi:raise ValueError('single_core_to_z must lie strictly inside study height')
  limit=float(transition)
 else:raise ValueError('Unknown connectivity policy')
 heights=np.linspace(lo+.05,limit-.05,15)
 checks['profile_cluster_and_receiver_connected']=all(len(core.polygon_parts(core.section_geometry(filled,float(z)+.000137)))==1 for z in heights)
 separation=[{'z':float(z)+.000137,'components':len(core.polygon_parts(core.section_geometry(filled,float(z)+.000137)))} for z in np.linspace(limit+.05,hi-.05,15)] if mode=='single_core_to_z' else []
 result=dict(checks={k:bool(v) for k,v in checks.items()},bedding=beds,max_boundary_error=max(gaps),top_contact=dict(uncovered_area=missing,max_boundary_gap=maxgap),unsupported_base_area=base_missing,sections_checked=61,connectivity_policy=policy,post_core_sections=separation)
 (out/'GEOMETRY_QA.json').write_text(json.dumps(result,indent=2));print('GEOMETRY_CHECKS',sum(checks.values()),len(checks),flush=True);assert all(checks.values()),result
