# R16 experimental branch-separation policy

This is a separate copy of the R06 build scripts; it is not installed in R14. The default requires the common block to have one sampled horizontal section at all sampled heights. An explicit manifest `connectivity_policy` of `{"mode":"single_core_to_z","single_core_to_z":480.0}` instead requires a connected section at 15 sampled elevations below the selected level, records samples above it, and requires each generated course to be one connected, closed mesh. The value 480 applies only to the R10 experimental fixture. No structural or architectural conclusions follow merely from a pass. The approved level, structural load path and workable coursing require review. Sampling does not prove continuity everywhere; levels very close to the study endpoints are untested.

Run with a new output directory:

    PYTHONPATH=/home/christopher/Documents/Cathedral/experimental/SPRINGER_SEPARATION_R16 python3 /home/christopher/Documents/Cathedral/experimental/SPRINGER_SEPARATION_R16/run_checked.py /home/christopher/Documents/Cathedral/experimental/SPRINGER_SEPARATION_R16/manifest.json --out /path/to/new/output --blender /usr/bin/blender --threads 4

The tested script uses Blender 5.0.1. Existing manifest, geometry and previously generated outputs are retained. Architectural, historical and structural validation remain separate.
