from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
p=Path(__file__).parent;im=Image.new('RGB',(1600,1000),'#e9e5dd');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';b='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';d.text((40,25),'FIVE-BEARING JUNCTION  |  BACKING TEST',font=ImageFont.truetype(b,34),fill='#222b31');render=Image.open(p/'original_backing_test/build/variant_review.png').convert('RGB');render.thumbnail((820,820));im.paste(render,(40,100));x=915;d.text((x,115),'EXPERIMENTAL COMPARISON',font=ImageFont.truetype(b,26),fill='#222b31');font=ImageFont.truetype(f,22)
lines=['R10: 0.01-unit retreated backing','  One four-face edge at springing','R15: original backing restored','  No abnormal edge in diagnostics','','Profiles, bearings and courses retained','78/78 checks; GLB reimport passed','Four beds match within tolerance','','Three-bearing backing remains unresolved','Geometry is not yet architecturally approved']
for i,line in enumerate(lines):d.text((x,175+i*45),line,font=font,fill='#222b31')
im.save(p/'SPRINGER_JUNCTION_R15_RESULT.png')
