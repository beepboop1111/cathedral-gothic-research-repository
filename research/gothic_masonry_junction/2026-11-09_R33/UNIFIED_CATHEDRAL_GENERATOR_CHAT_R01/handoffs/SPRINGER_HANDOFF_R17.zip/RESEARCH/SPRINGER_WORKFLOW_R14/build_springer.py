#!/usr/bin/env python3
"""Guarded springer workflow: reviewed section/manifest -> controls -> GLB -> diagnostics."""
import argparse,json,os,pathlib,subprocess,sys
from PIL import Image,ImageDraw,ImageFont
ROOT=pathlib.Path('/home/christopher/Documents/Cathedral/experimental')
CORE=ROOT/'SPRINGER_ENGINE_R06';CONTROL=ROOT/'SPRINGER_CONTROLS_R12/controls.py';ATTACH=ROOT/'SPRINGER_PROFILE_INPUT_R11/attach_section.py';RUNNER=ROOT/'SPRINGER_ENGINE_R07_THREE_BEARING/run_checked.py';DIAG=ROOT/'SPRINGER_DIAGNOSTICS_R13/diagnose.py'
def call(cmd,log,env=None):
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 return r.returncode

def build_review(out,summary,section_preview):
 im=Image.new('RGB',(1600,1000),'#ece8df');d=ImageDraw.Draw(im);bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';normal='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';title=ImageFont.truetype(bold,32);font=ImageFont.truetype(normal,22);d.text((40,25),'ONE-COMMAND SPRINGER BUILD  |  EXPERIMENTAL',font=title,fill='#202830')
 render=Image.open(out/'build/variant_review.png').convert('RGB');render.thumbnail((780,780));im.paste(render,(40,100));x=850
 if section_preview:
  p=Image.open(section_preview).convert('RGB');p.thumbnail((700,420));im.paste(p,(x,100));y=550
 else:y=125
 lines=['Blender GLB reimport: '+str(summary['passed'])+'/'+str(summary['total'])+' checks','Diagnostics: '+summary['diagnostic_status'],'Levels: '+', '.join(str(x) for x in summary['course_levels']),'Existing backing and bearings follow manifest.','Experimental: architecture requires review.']
 for i,line in enumerate(lines):d.text((x,y+i*48),line,font=font,fill='#202830')
 im.save(out/'SPRINGER_WORKFLOW_RESULT.png')

def main():
 p=argparse.ArgumentParser();p.add_argument('--fixture',required=True,type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);p.add_argument('--section',type=pathlib.Path,help='section.json produced by preview step');p.add_argument('--member',help='sweep member ID when --section is provided');p.add_argument('--bearing',action='append',default=[]);p.add_argument('--carrier',action='append',default=[]);p.add_argument('--courses',nargs='+');p.add_argument('--spring',type=float);p.add_argument('--backing');p.add_argument('--blender',default='/usr/bin/blender');p.add_argument('--threads',type=int,default=4);a=p.parse_args()
 if bool(a.section)!=bool(a.member):p.error('--section and --member must be supplied together')
 if a.threads<1:p.error('--threads must be positive')
 preview=None
 if a.section:
  preview=a.section.parent/'orientation_preview.png'
  if not preview.is_file():p.error('section must have an orientation_preview.png from profile input')
 a.out=a.out.resolve();a.out.mkdir(parents=True,exist_ok=False);env=os.environ.copy();env['PYTHONPATH']=str(CORE)+os.pathsep+env.get('PYTHONPATH','');fixture=a.fixture.resolve();summary={'status':'failed','failed_stage':None,'fixture':str(fixture),'stages':{}}
 def stage(name,cmd):
  rc=call(cmd,a.out/(name+'.log'),env);summary['stages'][name]=rc
  if rc:summary['failed_stage']=name
  return rc
 try:
  if a.section:
   if stage('attach',[sys.executable,str(ATTACH),'--section',str(a.section.resolve()),'--fixture',str(fixture),'--member',a.member,'--out',str(a.out/'profile_input')]):return 1
   fixture=a.out/'profile_input/manifest.json'
  cmd=[sys.executable,str(CONTROL),'--fixture',str(fixture),'--out',str(a.out/'controlled_manifest.json')]
  for value in a.bearing:cmd+=['--bearing',value]
  for value in a.carrier:cmd+=['--carrier',value]
  if a.courses:cmd+=['--courses',*a.courses]
  if a.spring is not None:cmd+=['--spring',str(a.spring)]
  if a.backing is not None:cmd+=['--backing',a.backing]
  if stage('controls',cmd):return 1
  rc=stage('build',[sys.executable,str(RUNNER),str(a.out/'controlled_manifest.json'),'--out',str(a.out/'build'),'--blender',a.blender,'--threads',str(a.threads)])
  build_failure=rc!=0
  if (a.out/'build/config.json').exists():
   diag_rc=stage('diagnostics',[sys.executable,str(DIAG),str(a.out/'build'),'--out',str(a.out/'diagnostics')])
   if diag_rc:return 1
   diag=json.loads((a.out/'diagnostics/diagnostics.json').read_text());summary['diagnostic_status']=diag['status'];summary['diagnostic_failure']=diag.get('recorded_failure');summary['diagnostic_warnings']={'quantized_abnormal_edges':diag.get('raw_mesh_edge_diagnostic',{}).get('abnormal_edge_count'),'sampled_component_changes':diag.get('sections',{}).get('component_count_changes',[]),'sample_errors':sum('error' in x for x in diag.get('sections',{}).get('samples',[]))}
  else:
   summary['diagnostic_status']='unavailable: build config was not produced';return 1
  if build_failure:
   summary['failed_stage']='build';return 1
  qa_path=a.out/'build/QA.json';glb=a.out/'build/springer_variant.glb';render=a.out/'build/variant_review.png'
  if not all(x.is_file() and x.stat().st_size>0 for x in (qa_path,glb,render)):
   summary['failed_stage']='missing_outputs';return 1
  qa=json.loads(qa_path.read_text());checks=qa['checks']
  if not checks or not all(checks.values()) or not checks.get('GLB_object_names_count') or not checks.get('GLB_oriented_triangles_0_0001') or summary['diagnostic_status']!='completed':
   summary['failed_stage']='validation';return 1
  summary.update(passed=qa['passed'],total=qa['total'],course_levels=qa['courses'],glb=str(glb),reimport_checked=True,failed_stage='review')
  build_review(a.out,summary,preview);summary.update(status='passed',failed_stage=None);return 0
 finally:
  (a.out/'WORKFLOW_SUMMARY.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,KeyError,json.JSONDecodeError) as e:print('WORKFLOW ERROR:',e,file=sys.stderr);sys.exit(2)
