# R14 checkpoint

Experimental guarded one-command wrapper; R04–R13 remain unchanged. 1:1 numerical native fixture coordinates, Z_UP; SI conversion unresolved. Profile31 R11 proportional conversion, four-member R09 fixture, existing R08 0.01 native unit full-height backing retreat. Member_2 bearing 42.16944050198884 degrees; course levels 0/110/220/340/470/600. This is an isolated experimental study, not approved cathedral geometry.

Final successful run `pass_final`: attach, controls, build and diagnostics all zero exit status; saved R06 QA 78/78 and GLB reimport verified in Blender 5.0.1; diagnostics found 0 quantized abnormal edges, 0 sampled connectivity changes and 0 sample errors. New review PNG produced. Previously tested early wrapper `pass_test` remains separate; final code was rerun after added warning reporting and success-after-render guard.

Final known failure run `failure_final`: saved R10 five-member variant failed raw union; wrapper exit status 1 and automatic diagnostics ran successfully, locating one quantized non-manifold edge; no success PNG. Separate `test_workflow.py` 4/4 verifies saved pass and failed results, refusal to overwrite existing output, and rejection of section without a member. Failed setup, five-bearing and three-bearing cases are not repaired; no automatic architecture/structural conclusions.

R11 PNG conversion/preview remains a separate step and preview existence alone does not prove review or bind image cryptographically to data. GUI, custom carrier creation, moving datum or mesh bearings, and Blender 5.1+ verification remain open. R08 local backing taper and R10 failure analysis remain open; F5ZL-C support data missing. Architectural review, historical validation and structural capacity not performed. No GitHub.
