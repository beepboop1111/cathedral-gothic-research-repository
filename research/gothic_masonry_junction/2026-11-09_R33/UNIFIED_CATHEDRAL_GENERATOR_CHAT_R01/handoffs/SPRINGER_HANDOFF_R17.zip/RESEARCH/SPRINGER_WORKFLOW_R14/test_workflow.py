import hashlib,json,pathlib,subprocess,sys,unittest
P=pathlib.Path(__file__).resolve().parent;T=P/'build_springer.py';fixture=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/SPRINGER_PROFILE_R09/manifest.json')
class Tests(unittest.TestCase):
 def test_pass_outputs(self):
  p=P/'pass_final';s=json.loads((p/'WORKFLOW_SUMMARY.json').read_text());self.assertEqual(s['status'],'passed');self.assertTrue(s['reimport_checked']);self.assertEqual(s['passed'],s['total']);self.assertEqual(s['diagnostic_status'],'completed');self.assertEqual(s['diagnostic_warnings']['sample_errors'],0);self.assertTrue((p/'build/springer_variant.glb').is_file());self.assertTrue((p/'SPRINGER_WORKFLOW_RESULT.png').is_file())
 def test_failure_diagnostics(self):
  p=P/'failure_final';s=json.loads((p/'WORKFLOW_SUMMARY.json').read_text());self.assertEqual(s['status'],'failed');self.assertEqual(s['failed_stage'],'build');self.assertIn('non-manifold',s['diagnostic_failure']);self.assertEqual(s['diagnostic_warnings']['quantized_abnormal_edges'],1);self.assertFalse((p/'SPRINGER_WORKFLOW_RESULT.png').exists())
 def test_overwrite_rejected(self):
  p=P/'pass_final';b=(p/'WORKFLOW_SUMMARY.json').read_bytes();r=subprocess.run([sys.executable,str(T),'--fixture',str(fixture),'--out',str(p)],capture_output=True);self.assertNotEqual(r.returncode,0);self.assertEqual(b,(p/'WORKFLOW_SUMMARY.json').read_bytes())
 def test_missing_member_rejected(self):
  section=pathlib.Path('/home/christopher/Documents/Cathedral/experimental/SPRINGER_PROFILE_INPUT_R11/profile31/section.json');out=P/'invalid_should_not_exist';r=subprocess.run([sys.executable,str(T),'--fixture',str(fixture),'--section',str(section),'--out',str(out)],capture_output=True);self.assertNotEqual(r.returncode,0);self.assertFalse(out.exists())
if __name__=='__main__':unittest.main()
