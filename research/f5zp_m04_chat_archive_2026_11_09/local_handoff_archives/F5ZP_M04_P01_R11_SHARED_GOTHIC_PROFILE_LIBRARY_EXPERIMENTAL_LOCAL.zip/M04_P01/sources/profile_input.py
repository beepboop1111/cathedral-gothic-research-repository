#!/usr/bin/env python3
"""Experimental PNG silhouette to uniformly-scaled section. Preview before use."""
import argparse,hashlib,json,pathlib,sys
import cv2,numpy as np
from shapely.geometry import Polygon
from PIL import Image,ImageDraw,ImageFont

def convert(path, width, depth, nose, mirror, threshold, simplify):
    raw=path.read_bytes();a=cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_UNCHANGED)
    if a is None:raise ValueError('Unreadable PNG')
    if a.ndim==2:rgb=a;alpha=np.full(a.shape,255,np.uint8)
    elif a.shape[2]==4:rgb=cv2.cvtColor(a[:,:,:3],cv2.COLOR_BGR2GRAY);alpha=a[:,:,3]
    else:rgb=cv2.cvtColor(a[:,:,:3],cv2.COLOR_BGR2GRAY);alpha=np.full(rgb.shape,255,np.uint8)
    mask=((rgb<threshold)&(alpha>127)).astype('uint8')*255
    contours,hier=cv2.findContours(mask,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_NONE)
    if hier is None:raise ValueError('No black silhouette found')
    roots=[i for i,h in enumerate(hier[0]) if h[3]<0 and cv2.contourArea(contours[i])>=2]
    if len(roots)!=1:raise ValueError(f'Expected exactly one profile silhouette; found {len(roots)}; crop multi-profile sheets or remove fragments')
    idx=roots[0]
    if hier[0][idx][2]>=0:raise ValueError('Profile has interior holes; unsupported by this engine')
    full=contours[idx].reshape(-1,2).astype(float);approx=cv2.approxPolyDP(contours[idx],simplify,True).reshape(-1,2).astype(float)
    if len(approx)<3:raise ValueError('Insufficient contour points')
    # depth is positive toward the visible nose; width is transverse.
    if nose=='left': u,v=approx[:,1],-approx[:,0]
    elif nose=='right':u,v=-approx[:,1],approx[:,0]
    elif nose=='up':u,v=approx[:,0],-approx[:,1]
    else:u,v=-approx[:,0],approx[:,1]
    if mirror:u=-u
    u=u-(u.min()+u.max())/2;v=v-v.min()
    w=float(np.ptp(u));h=float(np.ptp(v))
    if min(w,h)<=0:raise ValueError('Profile has zero extent')
    factor=(width/w) if width is not None else (depth/h)
    points=np.column_stack((u*factor,v*factor));poly=Polygon(points)
    if not poly.is_valid or poly.area<=0:raise ValueError('Traced outline is invalid or self-intersecting')
    out={'schema':'springer_png_section_v1','source_file':path.name,'source_sha256':hashlib.sha256(raw).hexdigest(),'image_dimensions_px':[int(a.shape[1]),int(a.shape[0])],'section':points.tolist(),'units':'user-declared native units; conversion to physical units is not inferred','width':w*factor,'depth':h*factor,'uniform_scale_units_per_pixel':factor,'nose_direction_on_image':nose,'mirror_width':mirror,'black_threshold':threshold,'simplify_tolerance_pixels':simplify,'raw_contour_vertices':len(full),'vertices':len(points),'notes':['Raster-derived silhouette; inspect orientation and edge quality','Only a single solid profile is supported; optional soffits are not automatically attached']}
    return out

def preview(data,path,out):
    im=Image.new('RGB',(1500,900),'#eeeae2');d=ImageDraw.Draw(im);f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';b='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';font=ImageFont.truetype(f,24);bold=ImageFont.truetype(b,30);small=ImageFont.truetype(f,19)
    d.text((35,25),'PROFILE INPUT PREVIEW — INSPECT BEFORE BUILD',font=bold,fill='#222a30')
    source=Image.open(path).convert('RGBA');base=Image.new('RGBA',source.size,'white');base.alpha_composite(source);source=base.convert('RGB');source.thumbnail((620,580));im.paste(source,(50+(620-source.width)//2,155));d.text((50,95),'SOURCE PNG',font=bold,fill='#222a30')
    points=np.array(data['section']);w,h=data['width'],data['depth'];scale=min(560/w,500/h);x0=760+280;y0=680
    xy=[(x0+x*scale,y0-y*scale) for x,y in points];d.polygon(xy,fill='#202c36');d.line(xy+[xy[0]],fill='#b24c38',width=3)
    d.text((750,95),'VECTOR SECTION',font=bold,fill='#222a30');d.line([(x0-260,735),(x0+260,735)],fill='#284d7a',width=3);d.text((x0-65,748),'WIDTH →',font=small,fill='#284d7a');d.line([(1370,680),(1370,230)],fill='#a54732',width=3);d.polygon([(1370,210),(1362,230),(1378,230)],fill='#a54732');d.text((1300,695),'NOSE ↑',font=small,fill='#a54732')
    d.text((50,795),f"Width {w:.4f}  |  Depth {h:.4f}  |  nose in source: {data['nose_direction_on_image']}  |  mirrored: {data['mirror_width']}",font=font,fill='#222a30')
    d.text((50,840),'Uniform scaling; numerical units supplied by user. Raster trace and orientation require review.',font=small,fill='#48545d');im.save(out)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('png',type=pathlib.Path);ap.add_argument('--out',required=True,type=pathlib.Path);size=ap.add_mutually_exclusive_group(required=True);size.add_argument('--width',type=float);size.add_argument('--depth',type=float);ap.add_argument('--nose',choices=('left','right','up','down'),required=True);ap.add_argument('--mirror-width',action='store_true');ap.add_argument('--threshold',type=int,default=128);ap.add_argument('--simplify-px',type=float,default=.55);a=ap.parse_args()
    if not (0<a.threshold<256):ap.error('threshold must be 1–255')
    if (a.width is not None and (not np.isfinite(a.width) or a.width<=0)) or (a.depth is not None and (not np.isfinite(a.depth) or a.depth<=0)):ap.error('size must be positive and finite')
    if not np.isfinite(a.simplify_px) or a.simplify_px<0:ap.error('simplification must be non-negative and finite')
    data=convert(a.png,a.width,a.depth,a.nose,a.mirror_width,a.threshold,a.simplify_px);a.out.mkdir(parents=True,exist_ok=False);(a.out/'section.json').write_text(json.dumps(data,indent=2));preview(data,a.png,a.out/'orientation_preview.png');print(json.dumps({k:data[k] for k in ('width','depth','vertices','uniform_scale_units_per_pixel')},indent=2))
if __name__=='__main__':
 try:main()
 except (ValueError,OSError) as e: print('PROFILE INPUT ERROR: '+str(e),file=sys.stderr);sys.exit(2)
