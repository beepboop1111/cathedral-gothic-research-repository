import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
# Explicit synthetic dimensions; no historical scale or automatic fit adjustment.
doc=dict(schema_version='R16',units='m',coordinate_frame='xy_plan_z_up',floor_z=0,
 profiles=[dict(id='pier_cluster',kind='pier',polygon=[[-.28,-.48],[.28,-.48],[.28,-.28],[.48,-.28],[.48,.28],[.28,.28],[.28,.48],[-.28,.48],[-.28,.28],[-.48,.28],[-.48,-.28],[-.28,-.28]]),
           dict(id='rib_moulded',kind='rib',polygon=[[-.16,0],[0,0],[.16,0],[.16,-.08],[.10,-.12],[.10,-.21],[.06,-.27],[-.06,-.27],[-.10,-.21],[-.10,-.12],[-.16,-.08]]),
           dict(id='arch_moulded',kind='rib',polygon=[[-.22,0],[0,0],[.22,0],[.22,-.12],[.15,-.16],[.15,-.25],[.08,-.34],[-.08,-.34],[-.15,-.25],[-.15,-.16],[-.22,-.12]])],
 supports=[dict(id=key,xy=xy,rotation_degrees=0,profile_id='pier_cluster',spring_z=4,port_xy_local=[0,0]) for key,xy in [('P0',[-6,0]),('P1',[0,0]),('P2',[4.5,0]),('P3',[-6,6]),('P4',[0,6]),('P5',[5.2,6])]],
 edges=[dict(id=key,supports=ends,apex_z=7.2,profile_id='arch_moulded') for key,ends in [('E01',['P0','P1']),('E14',['P1','P4']),('E43',['P4','P3']),('E30',['P3','P0']),('E12',['P1','P2']),('E25',['P2','P5']),('E54',['P5','P4'])]],
 bays=[dict(id='Bay_W',supports=['P0','P1','P4','P3'],edges=['E01','E14','E43','E30'],crown_xy=[-3,3],crown_z=8.3,radial_profile_id='rib_moulded',web_radius=12,web_thickness_vertical=.18),
       dict(id='Bay_E',supports=['P1','P2','P5','P4'],edges=['E12','E25','E54','E14'],crown_xy=[2.3,3.1],crown_z=8.1,radial_profile_id='rib_moulded',web_radius=12,web_thickness_vertical=.18)],
 walls=[dict(id='Wall_S',edge_id='E01',thickness=.8,alignment='center',top_z=9.2)],
 openings=[dict(id='Window_S',wall_id='Wall_S',layout_file='../R53_Universal_2D_Engine/examples/bar_2light_sexfoil.json',center_along_wall=3,sill_z=.8,depth=.24,reveal_from_left_face=.22,minimum_surround=.3)],
 clearances=[dict(id='West_aisle',xy_min=[-4.7,1],xy_max=[-1.3,5],height=3.0),dict(id='East_aisle',xy_min=[1,1],xy_max=[3.5,5],height=3.0),dict(id='Shared_arch_passage',xy_min=[-.3,1.2],xy_max=[.3,4.8],height=5.8)],
 sampling=dict(segments=32,web_steps=16))
(ROOT/'two_bays.json').write_text(json.dumps(doc,indent=2)+'\n')
