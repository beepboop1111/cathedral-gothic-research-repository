# Master plan → cathedral geometry contract, R16

Status: implemented integration study, not a complete cathedral engine. The input is `two_bays.json`; the machine-readable, closed schema is `building.schema.json`. The master floor plan remains authoritative. R16 does not create an editing interface.

## Authority and coordinate system

All building measurements are metres. XY is plan; Z is elevation. Floor, springing, arch apex, crown, sill and wall top are **absolute elevations**. Local profiles also use metres. No inferred scale, silent fit scaling or automatic constraint relaxation is allowed. R53 millimetres convert to metres once at its adapter boundary; uncalibrated pixels cannot be placed.

The demonstration is synthetic. Its dimensions do not imply approval or historical calibration of any source. R53 provenance, correction records, source status and source file hash survive placement in `resolved.json`.

## Records

| Record | Required authority | Derived geometry |
|---|---|---|
| Profile | ID, kind, ordered closed-section polygon without repeated final vertex | Pier footprint or rib cross-section |
| Support | ID, XY origin, orientation, profile ID, springing Z, local port XY | Transformed finished footprint and global bearing point |
| Edge | ID, two support IDs, apex Z, profile ID | One shared two-branch arch and its top bearing paths |
| Bay | ID, ordered support/edge references, crown XY/Z, radial profile, web radius and thickness | Radial ribs and web panels bounded by canonical edge paths |
| Wall | ID, edge ID, alignment, thickness, top Z | Two wall faces and a solid elevation region with opening voids |
| Opening | ID, wall ID, R53 input file, centre along wall, sill Z, depth, reveal and minimum surround | Metric layout placement, wall cutout and constant-depth tracery |
| Clearance | ID, XY rectangle, required height above floor | Minimum finished mesh height over that rectangle and limiting part |

Element IDs are globally unique across supports, edges, bays, walls and openings. Profiles and clearance zones have their own ID registries. Shared geometry is referenced, never copied per bay. Derived rib names use support IDs; web names use edge and support IDs so dimension edits retain object identity.

## Footprints and springing

The pier profile generator's adapter should deliver its actual finished section polygon, not a bounding circle. R16 rotates and translates that polygon to obtain the footprint. A support's bearing point is its declared local port, transformed by the same orientation. Ports must lie strictly within their support footprint. The complete projected rib section at each spring must also fit inside that footprint, at or below its top elevation. The example places them at the centre of the pier top.

The current adapter supports one common-height bearing point per support and straight constant-section piers. A capital/impost adapter will need to provide its own finished envelope and named attachment surfaces. Multiple ports on one support and stepped springing require a later contract version; R16 rejects unequal springing rather than projecting it flat.

Architectural bay boundaries pass through resolved bearing points. They are **not clear-space polygons**. Finished profiles and wall faces determine clearance.

## Paths, section frames and web bearing

The shared edge owns the arch profile, apex and both springing points. Both bays obtain those from the same record. A second edge with the same two supports is rejected. An edge can bound one or two bays; overlapping bay interiors are rejected.

R15 generates the normalized path families and web underside geometry. Its circular test ribs are discarded. R16 sweeps supplied polygon profiles along the resolved paths. Local profile X is lateral to the path; local profile Y is the upward cross-section normal. `(0,0)` is the top bearing datum, and profiles must lie on or below Y=0 with that datum on their boundary.

Every sampled web boundary is checked against the corresponding actual profile-bearing trace. This preserves the agreed interface as profile depth or width changes. It establishes line contact, not a proof of finite bearing or a solved masonry joint. Profiles cannot change the bearing datum silently.

Vault thickness is explicitly **vertical thickness above the R15 underside**, not a surface-normal offset. Every panel is closed individually; adjoining solids are not fused. Radial branches meet at the crown without a generated boss or mitred joint.

## Walls and openings

A wall follows its edge's resolved bearing points in plan. The edge's first-to-second support direction defines left and right. Alignment `center` places half the thickness on each side; `left` and `right` place all of it on the corresponding side. Wall height is wall-top Z minus floor Z.

The example uses a straight, constant-thickness wall. Curved walls, tapered walls, buttresses and masonry courses are outside this adapter.

R53 delivers sampled stone, envelope and void regions. The whole envelope is cut from the wall, then the stone region is extruded into that opening. The surrounding wall, frame, mullions and voids therefore use the same boundary. The opening's `sill_z` locates the lowest point of the **outer envelope**, including the sill band; it is not the clear-light sill.

`center_along_wall` is measured from the edge's first support, using the envelope's horizontal midpoint. `reveal_from_left_face` locates the first tracery face inside the wall. Tracery depth plus reveal must fit within wall thickness. There is no nonuniform scaling or clipping of the source tracery.

The resolver checks wall surround, separation between openings and conservative projected overlap with actual pier footprints. It does not yet test every possible rib/tracery or cross-component intersection. R53 analytical records retain their meaning as construction geometry; the extruded mesh comes from sampled region boundaries, not from untrimmed construction circles.

## Clearance and failure behaviour

Each required rectangular floor zone is projected vertically through the finished mesh. Every intersecting triangle is clipped to the rectangle; the minimum interpolated Z gives the available height. This checks triangle interiors as well as vertices, at the configured mesh precision. Piers and walls intersecting the zone produce zero clearance at the floor. The report names the limiting mesh part.

A clearance failure rejects the build with the zone ID, required height, available height and limiting part. Other failures identify invalid references, contradictory geometry, unsupported springing, improper bearing profiles or openings that do not fit. The CLI finishes geometry and clearance validation before replacing output files. It does not modify input files.

## Dependency and rebuild sequence

1. Validate units, fields, finite measurements and IDs.
2. Resolve profile polygons, support footprints and bearing ports.
3. Resolve canonical edges, bays and wall faces; check adjacency.
4. Generate shared arches, radial ribs and R15 webs; check bearing agreement and thicken webs.
5. Build the actual R53 layout, preserve physical units, place it and cut the wall.
6. Check finished-mesh clearance zones.
7. Export named OBJ components, materials and a resolved report with input/source fingerprints.

Current rebuilds regenerate the assembly deterministically. Stable references are in place, but incremental caching and dirty-element propagation are not implemented. A future profile-generator adapter should emit this contract's polygon/port records rather than independently place new objects.

## Next adapter work

The actual master floor-plan exporter and separate pier/rib profile generator were not present in this workspace. Their production adapters remain to be connected to this implemented contract. Following that, add capital/impost envelopes, section-to-web bearing surfaces, arch joints/crown bosses, moulded and rebated tracery, and masonry course/block partitioning. Those additions should preserve ownership and dimensions established here, with their own envelope checks.
