import copy
import json
import math
import unittest
from collections import Counter
from pathlib import Path
from shapely.geometry import Polygon
from integration import ROOT, ContractError, build, resolve, clip_xy, extrude, v15

class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.doc=json.loads((ROOT/'two_bays.json').read_text())
        cls.parts,cls.report=build(cls.doc)
    def config(self): return copy.deepcopy(self.doc)
    def test_shared_arch_single_owner(self):
        self.assertEqual(self.report['resolved']['ownership']['E14'],['Bay_W','Bay_E'])
        self.assertEqual([p['name'] for p in self.parts if p['owner']=='E14'],['E14.half0','E14.half1'])
        self.assertEqual(len([p for p in self.parts if p['type']=='pier']),6)
    def test_actual_profile_bearing_and_web_edges(self):
        self.assertEqual(len(self.report['bearing_checks']),16)
        self.assertLess(max(c['max_bearing_trace_error'] for c in self.report['bearing_checks']),1e-8)
        for p in self.parts:
            if p['type']=='rib':
                # Both example profiles contain an explicit datum vertex (0,0).
                for trace in p['bearing_trace']:
                    self.assertLess(min(math.dist(trace,v) for v in p['vertices']),1e-8)
    def test_closed_nondegenerate_mesh_parts(self):
        for p in self.parts:
            edges=Counter(); vs=p['vertices']; volume=0
            for f in p['faces']:
                a,b,c=[vs[i] for i in f]
                self.assertGreater(v15.length(v15.cross(v15.sub(b,a),v15.sub(c,a))),1e-12,p['name'])
                volume+=v15.dot(a,v15.cross(b,c))/6
                for i,j in zip(f,(*f[1:],f[0])): edges[tuple(sorted([i,j]))]+=1
            self.assertTrue(all(n==2 for n in edges.values()),p['name'])
            self.assertGreater(volume,0,p['name'])
    def test_clearance_uses_triangle_interior(self):
        pts=clip_xy([(-2,-2,4),(2,-2,8),(0,2,6)],[-.2,-.2],[.2,.2])
        self.assertTrue(pts)
        self.assertAlmostEqual(min(p[2] for p in pts),5.8)
        self.assertTrue(all(c['passed'] for c in self.report['clearances']))
    def test_profile_changes_preserve_bearing_paths(self):
        c=self.config(); c['profiles'][2]['polygon']=[[x,y*1.15] for x,y in c['profiles'][2]['polygon']]
        changed,_=build(c)
        old={p['name']:p for p in self.parts}; new={p['name']:p for p in changed}
        for key in ['E14.half0','E14.half1']:
            self.assertEqual(old[key]['bearing_trace'],new[key]['bearing_trace'])
            self.assertNotEqual(old[key]['vertices'],new[key]['vertices'])
        self.assertEqual(old['Bay_W.web.E14.P1']['vertices'],new['Bay_W.web.E14.P1']['vertices'])
    def test_spring_section_must_fit_support(self):
        c=self.config(); c['profiles'][0]['polygon']=[[x*.3,y*.3] for x,y in c['profiles'][0]['polygon']]
        with self.assertRaisesRegex(ContractError,'spring section extends outside pier'): build(c)
    def test_pier_footprint_controls_clearance(self):
        c=self.config(); c['profiles'][0]['polygon']=[[x*3,y*3] for x,y in c['profiles'][0]['polygon']]
        with self.assertRaisesRegex(ContractError,'Clearance failure'): build(c)
    def test_window_fit_rejects_without_scaling(self):
        for mutation in ['height','depth','pier']:
            c=self.config()
            if mutation=='height': c['walls'][0]['top_z']=6
            if mutation=='depth': c['openings'][0]['depth']=.7
            if mutation=='pier': c['openings'][0]['center_along_wall']=1.7
            with self.subTest(mutation=mutation), self.assertRaises(ContractError): build(c)
    def test_duplicate_edge_and_bad_references(self):
        for mutation in ['duplicate','missing','order','spring','unit','bearing','outside_port','overlap']:
            c=self.config()
            if mutation=='duplicate': c['edges'].append(dict(c['edges'][1],id='Duplicate'))
            if mutation=='missing': c['bays'][0]['edges'][0]='Missing'
            if mutation=='order': c['bays'][0]['edges'][0]='E43'
            if mutation=='spring': c['supports'][0]['spring_z']=4.1
            if mutation=='unit': c['units']='mm'
            if mutation=='bearing': c['profiles'][1]['polygon']=[[x,y-.01] for x,y in c['profiles'][1]['polygon']]
            if mutation=='outside_port': c['supports'][0]['port_xy_local']=[2,0]
            if mutation=='overlap': c['bays'].append(dict(c['bays'][0],id='Overlap'))
            with self.subTest(mutation=mutation),self.assertRaises(ContractError): resolve(c)
    def test_wall_alignment_and_support_rotation(self):
        c=self.config(); c['walls'][0]['alignment']='left'; c['supports'][0]['rotation_degrees']=90
        c['supports'][0]['port_xy_local']=[.1,0]
        r=resolve(c)
        self.assertEqual(r['walls']['Wall_S']['depth_interval'],[0,.8])
        self.assertAlmostEqual(r['supports']['P0']['port'][0],-6)
        self.assertAlmostEqual(r['supports']['P0']['port'][1],.1)
    def test_unsupported_or_nonfinite_fields_rejected(self):
        for mutate in [lambda c:c.update(unknown=True),lambda c:c.update(floor_z=float('nan')),lambda c:c['sampling'].update(segments=3)]:
            c=self.config(); mutate(c)
            with self.assertRaises(ContractError): resolve(c)
    def test_repeatable_outputs(self):
        parts,report=build(self.config())
        self.assertEqual(parts,self.parts); self.assertEqual(report,self.report)
    def test_physical_tracery_conversion(self):
        o=self.report['opening_placements'][0]
        self.assertAlmostEqual(o['elevation_bounds'][2]-o['elevation_bounds'][0],2.72)
        self.assertAlmostEqual(o['elevation_bounds'][1],.8)
        self.assertEqual(o['source_provenance']['units'],'mm')
        self.assertAlmostEqual(o['extrusion_depth'],.24)

if __name__=='__main__': unittest.main()
