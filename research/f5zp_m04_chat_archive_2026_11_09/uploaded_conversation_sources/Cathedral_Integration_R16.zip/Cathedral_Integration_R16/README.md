# R16 — floor-plan integration prototype

Two unequal adjacent bays share one profiled arch and two of six profiled piers. Their vaults have explicit thickness. A 0.80 m wall contains the actual R53 two-light/sexfoil tracery layout, converted from millimetres without fit scaling and extruded to an explicitly chosen 0.24 m depth. Three floor-space clearance requirements are checked against the finished mesh.

Open `output/assembly.obj` with `output/assembly.mtl` beside it, or inspect `output/integration_preview.png`. `output/resolved.json` records ownership, bearing checks, clearances, source provenance and limitations.

The reusable deliverable is `CONTRACT.md` plus `building.schema.json`. `two_bays.json` is an example master-plan export, not an editing interface. `integration.py` is the working resolver and adapter implementation.

From the extracted package's root:

```
python3 Cathedral_Integration_R16/integration.py Cathedral_Integration_R16/two_bays.json --output Cathedral_Integration_R16/output
python3 -m unittest discover -s Cathedral_Integration_R16 -v
python3 Cathedral_Integration_R16/render_preview.py
```

Python 3 and the existing R53 dependencies are required; see `requirements.txt`. Matplotlib is needed only to regenerate the preview. The delivery bundle includes the R15 and R53 source files needed by these commands. Existing workspace engines were not modified.

## What is connected

- Explicit pier profile polygons become rotated finished footprints and bearing locations.
- Edge-owned arches are generated only once and referenced by both adjoining bays.
- Supplied polygon rib sections replace the R15 circular test ribs.
- Web boundaries meet the shared profile-bearing traces; web thickness is vertical.
- Wall alignment resolves interior/exterior faces relative to edge direction.
- Actual R53 envelope/stone polygons drive both the wall hole and the tracery placement.
- Passage clearances include projecting profiles and pier footprints at mesh precision.
- Invalid references, duplicate edges, unsuitable footprints, nonfinite data, insufficient opening fit and failed clearance are rejected rather than silently adjusted.

## Limits

This is a tested integration foundation, not the complete cathedral generator. No master floor-plan exporter or separate profile-generator source was available, so their adapters are represented by explicit input records. Piers are straight extrusions, tracery has constant depth, walls are straight, web thickness is vertical, and masonry block/course subdivision is not implemented. Solids remain separate with unresolved overlapping joints. Bearing checks establish line contact, not finite bearing. Only requested clearance rectangles are tested; this is not exhaustive collision analysis or structural validation.
