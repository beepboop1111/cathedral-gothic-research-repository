"""Generate the closed R16 interchange schema."""
import json
from pathlib import Path

def obj(props,required=None): return dict(type='object',properties=props,required=list(props) if required is None else required,additionalProperties=False)
def arr(item,n=0): return dict(type='array',items=item,minItems=n)
def ref(name): return {'$ref':'#/$defs/'+name}
num={'type':'number'}; positive={'type':'number','exclusiveMinimum':0}; ident={'type':'string','pattern':'^[A-Za-z][A-Za-z0-9_.-]*$'}
xy=dict(type='array',items=num,minItems=2,maxItems=2)
ids=arr(ident,3)
profile=obj({'id':ident,'kind':{'enum':['pier','rib']},'polygon':arr(xy,3)})
support=obj({'id':ident,'xy':xy,'rotation_degrees':num,'profile_id':ident,'spring_z':num,'port_xy_local':xy})
edge=obj({'id':ident,'supports':dict(type='array',items=ident,minItems=2,maxItems=2),'apex_z':num,'profile_id':ident})
bay=obj({'id':ident,'supports':ids,'edges':ids,'crown_xy':xy,'crown_z':num,'radial_profile_id':ident,'web_radius':positive,'web_thickness_vertical':positive})
wall=obj({'id':ident,'edge_id':ident,'thickness':positive,'alignment':{'enum':['center','left','right']},'top_z':num})
opening=obj({'id':ident,'wall_id':ident,'layout_file':{'type':'string'},'center_along_wall':num,'sill_z':num,'depth':positive,'reveal_from_left_face':{'type':'number','minimum':0},'minimum_surround':positive})
clearance=obj({'id':ident,'xy_min':xy,'xy_max':xy,'height':positive})
schema=obj({'schema_version':{'const':'R16'},'units':{'const':'m'},'coordinate_frame':{'const':'xy_plan_z_up'},'floor_z':num,
            'profiles':arr(ref('profile'),1),'supports':arr(ref('support'),3),'edges':arr(ref('edge'),3),'bays':arr(ref('bay'),1),
            'walls':arr(ref('wall')),'openings':arr(ref('opening')),'clearances':arr(ref('clearance')),
            'sampling':obj({'segments':{'type':'integer','minimum':8,'maximum':256},'web_steps':{'type':'integer','minimum':4,'maximum':128}})})
schema.update({'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':dict(profile=profile,support=support,edge=edge,bay=bay,wall=wall,opening=opening,clearance=clearance)})
if __name__=='__main__': Path(__file__).with_name('building.schema.json').write_text(json.dumps(schema,indent=2)+'\n')
