"""Static review sheet, regenerated from the master building input."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/r16-matplotlib')
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from integration import ROOT, build, load_tracery

c=json.loads((ROOT/'two_bays.json').read_text()); parts,report=build(c)
colors={'pier':'#9c8970','rib':'#776047','web':'#d8cbb1','wall':'#b6aa91','tracery':'#c9a062'}
fig=plt.figure(figsize=(18,9),facecolor='#f6f3ed')
grid=fig.add_gridspec(2,3,width_ratios=[1,1.6,1],height_ratios=[1,.16],left=.04,right=.97,top=.83,bottom=.08,wspace=.10)
ax=fig.add_subplot(grid[0,0]); ax.set_facecolor('#f6f3ed')
r=report['resolved']
for key,b in r['bays'].items():
    pts=[r['supports'][sid]['port'][:2] for sid in b['supports']]
    ax.add_patch(Patch(pts,facecolor='#e8e0d2',edgecolor='#9a8a70',lw=1.3))
    for x,y in pts: ax.plot([x,b['crown_xy'][0]],[y,b['crown_xy'][1]],color='#a59171',lw=.9)
    ax.text(*b['crown_xy'],key,ha='center',va='center',fontsize=10,bbox=dict(facecolor='#f6f3ed',edgecolor='none',pad=3))
for cl in c['clearances']:
    a=cl['xy_min']; b=cl['xy_max']
    ax.add_patch(Patch([a,[b[0],a[1]],b,[a[0],b[1]]],facecolor='#96baac',alpha=.23,edgecolor='#43836c',ls='--'))
for key,s in r['supports'].items():
    ax.add_patch(Patch(s['footprint'],facecolor=colors['pier'],edgecolor='#554d41',lw=.7))
    ax.text(s['xy'][0],s['xy'][1]+.7,key,fontsize=9,ha='center')
w=r['walls']['Wall_S']; ax.add_patch(Patch([[-6,-.4],[0,-.4],[0,.4],[-6,.4]],facecolor=colors['wall'],alpha=.5))
ax.plot([0,0],[0,6],color='#9b5c35',lw=3); ax.text(.18,3,'E14 · one shared arch',rotation=90,fontsize=9,ha='left',va='center')
ax.set_aspect('equal'); ax.set_xlim(-7,6); ax.set_ylim(-1.5,7.5); ax.axis('off'); ax.set_title('MASTER PLAN',fontsize=12,loc='left',pad=25)
ax.text(-6.5,-1.3,'Green = tested clearance zones',fontsize=9,color='#43836c')

ax=fig.add_subplot(grid[0,1],projection='3d'); ax.set_facecolor('#f6f3ed')
faces=[]; facecolors=[]
for p in parts:
    faces.extend([[p['vertices'][i] for i in f] for f in p['faces']]); facecolors.extend([colors[p['type']]]*len(p['faces']))
mesh=Poly3DCollection(faces,facecolors=facecolors,edgecolor='none',zsort='average',shade=True,lightsource=matplotlib.colors.LightSource(azdeg=130,altdeg=45))
ax.add_collection3d(mesh)
ax.set(xlim=(-6.5,5.7),ylim=(-.7,6.7),zlim=(0,9.5)); ax.set_box_aspect((12.2,7.4,9.5)); ax.view_init(elev=25,azim=55); ax.set_proj_type('ortho'); ax.axis('off'); ax.set_title('RESOLVED ASSEMBLY',fontsize=12,loc='left',pad=25)

ax=fig.add_subplot(grid[0,2]); ax.set_facecolor('#f6f3ed')
stone,env,source=load_tracery(ROOT.parent/'R53_Universal_2D_Engine/examples/bar_2light_sexfoil.json')
from shapely import affinity
from shapely.geometry import box
from integration import triangles
stone=affinity.translate(stone,3,.8-env.bounds[1]); env=affinity.translate(env,3,.8-env.bounds[1])
wall=box(0,0,6,9.2).difference(env)
for region,color in [(wall,colors['wall']),(stone,colors['tracery'])]:
    for tri in triangles(region): ax.add_patch(Patch(tri,facecolor=color,edgecolor=color,lw=.15))
ax.set_xlim(-.4,6.4); ax.set_ylim(-.5,9.7); ax.set_aspect('equal'); ax.axis('off'); ax.set_title('WALL + R53 TRACERY',fontsize=12,loc='left',pad=25)
ax.text(3,-.45,'0.80 m wall · 0.24 m tracery depth',ha='center',fontsize=9)
fig.text(.04,.94,'Cathedral integration · R16',fontsize=26,weight='bold',color='#38352d')
fig.text(.04,.895,'One floor-plan specification → shared supports, profiled ribs, vault masonry and fitted tracery',fontsize=13,color='#6b6253')
checks=report['clearances']; heights='   |   '.join(f'{x["id"].replace("_"," ")}: {x["available_height"]:.2f} m available / {x["required_height"]:.2f} m required' for x in checks)
fig.text(.04,.13,heights,fontsize=10,color='#365d4f')
fig.text(.04,.075,'Synthetic integration study. Separate solids; joint cutting, masonry blocks and moulded tracery remain future adapters.',fontsize=10,color='#6b6253')
fig.savefig(ROOT/'output'/'integration_preview.png',dpi=150,facecolor=fig.get_facecolor())
