"""R16: floor-plan contract, deterministic resolver and mesh adapters.
No add-on, UI or changes to the R15/R53 source engines.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path
import jsonschema
import shapely
from shapely.geometry import Polygon, Point, box, shape
from shapely import affinity
from shapely.geometry.polygon import orient

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'Polygonal_Vaults_R15'))
import vault as v15
TOL=1e-8

class ContractError(ValueError): pass

def require(ok,message):
    if not ok: raise ContractError(message)

def index(items,label):
    result={x['id']:x for x in items}
    require(len(result)==len(items),f'{label}: duplicate IDs')
    return result

def polygon(points,label):
    p=Polygon(points)
    require(p.is_valid and p.area>TOL,f'{label}: invalid/zero-area polygon')
    require(len(set(map(tuple,points)))==len(points),f'{label}: duplicate profile vertices')
    return orient(p,sign=1)

def transform_xy(p,s):
    a=math.radians(s['rotation_degrees']); x,y=p
    return (s['xy'][0]+x*math.cos(a)-y*math.sin(a),s['xy'][1]+x*math.sin(a)+y*math.cos(a))

def validate(doc):
    try: jsonschema.Draft202012Validator(json.loads((ROOT/'building.schema.json').read_text())).validate(doc)
    except jsonschema.ValidationError as e: raise ContractError(f'{list(e.absolute_path)}: {e.message}') from e
    def finite(x):
        if isinstance(x,float): require(math.isfinite(x),'Nonfinite measurement')
        if isinstance(x,dict):
            for y in x.values(): finite(y)
        if isinstance(x,list):
            for y in x: finite(y)
    finite(doc)

def resolve(doc):
    validate(doc)
    profiles=index(doc['profiles'],'profiles'); supports=index(doc['supports'],'supports'); edges=index(doc['edges'],'edges')
    bays=index(doc['bays'],'bays'); walls=index(doc['walls'],'walls'); index(doc['openings'],'openings'); index(doc['clearances'],'clearances')
    element_ids=[x['id'] for group in ('supports','edges','bays','walls','openings') for x in doc[group]]
    require(len(set(element_ids))==len(element_ids),'Building element IDs must be globally unique')
    def get(items,key,owner):
        require(key in items,f'{owner}: missing reference {key}')
        return items[key]
    pp={}
    for key,p in profiles.items():
        pp[key]=polygon(p['polygon'],key)
        if p['kind']=='rib':
            require(max(y for x,y in p['polygon'])<=TOL,f'{key}: rib profile must lie below its top bearing datum')
            require(pp[key].boundary.distance(Point(0,0))<TOL,f'{key}: profile must meet bearing datum (0,0)')
    def profile(key,kind,owner):
        p=get(profiles,key,owner); require(p['kind']==kind,f'{owner}: wrong profile kind'); return pp[key]
    rs={}
    for key,s in supports.items():
        p=profile(s['profile_id'],'pier',key)
        require(s['spring_z']>doc['floor_z'],f'{key}: springing must exceed floor')
        require(p.contains(Point(s['port_xy_local'])),f'{key}: port must lie inside pier bearing footprint')
        footprint=polygon([transform_xy(q,s) for q in list(p.exterior.coords)[:-1]],key)
        xy=transform_xy(s['port_xy_local'],s)
        rs[key]=dict(**s,footprint=list(footprint.exterior.coords)[:-1],port=[*xy,s['spring_z']])
    ownership={key:[] for key in edges}; pairs={}
    for key,e in edges.items():
        a,b=[get(rs,k,key) for k in e['supports']]
        require(a['id']!=b['id'] and math.dist(a['port'][:2],b['port'][:2])>TOL,f'{key}: collapsed edge')
        pair=tuple(sorted(e['supports'])); require(pair not in pairs,f'{key}: duplicate physical edge; reuse {pairs.get(pair)}'); pairs[pair]=key
        require(abs(a['spring_z']-b['spring_z'])<TOL,f'{key}: unequal springing elevations unsupported')
        require(e['apex_z']>a['spring_z'],f'{key}: apex must exceed springing')
        profile(e['profile_id'],'rib',key)
    plans={}; configs={}
    for key,b in bays.items():
        n=len(b['supports']); require(n==len(b['edges']) and len(set(b['supports']))==n,f'{key}: boundary count/repeated supports')
        points=[get(rs,s,key)['port'] for s in b['supports']]
        require(max(p[2] for p in points)-min(p[2] for p in points)<TOL,f'{key}: common springing elevation required')
        for i,edge_id in enumerate(b['edges']):
            e=get(edges,edge_id,key)
            require(set(e['supports'])=={b['supports'][i],b['supports'][(i+1)%n]},f'{key}: edge {edge_id} does not match boundary order')
            ownership[edge_id].append(key)
        profile(b['radial_profile_id'],'rib',key)
        config=dict(corners=[p[:2] for p in points],crown_xy=b['crown_xy'],spring=points[0][2],crown=b['crown_z'],
                    apices=[edges[e]['apex_z'] for e in b['edges']],web_radius=b['web_radius'],rib_radius=.075,**doc['sampling'])
        try: v15.validate(config)
        except ValueError as e: raise ContractError(f'{key}: {e}') from e
        plans[key]=Polygon(config['corners']); configs[key]=config
    for key,owners in ownership.items(): require(1<=len(owners)<=2,f'{key}: an edge must have one or two bay owners')
    for i,(key,p) in enumerate(plans.items()):
        for other,q in list(plans.items())[i+1:]: require(p.intersection(q).area<TOL,f'{key}/{other}: overlapping bay interiors')
    rw={}; wall_edges=set()
    for key,w in walls.items():
        e=get(edges,w['edge_id'],key)
        require(w['edge_id'] not in wall_edges,f'{key}: duplicate wall on edge'); wall_edges.add(w['edge_id'])
        a,b=[rs[s]['port'] for s in e['supports']]; L=math.dist(a[:2],b[:2]); t=[(b[i]-a[i])/L for i in (0,1)]; normal=[-t[1],t[0]]
        require(w['top_z']>doc['floor_z'],f'{key}: wall top below floor')
        offsets={'center':[-w['thickness']/2,w['thickness']/2],'left':[0,w['thickness']],'right':[-w['thickness'],0]}[w['alignment']]
        rw[key]=dict(**w,origin=a[:2],tangent=t,left_normal=normal,length=L,depth_interval=offsets)
    for c in doc['clearances']:
        require(all(c['xy_max'][i]>c['xy_min'][i] for i in (0,1)),f'{c["id"]}: inverted clearance rectangle')
    for o in doc['openings']:
        w=get(rw,o['wall_id'],o['id'])
        require(o['depth']+o['reveal_from_left_face']<=w['thickness']+TOL,f'{o["id"]}: tracery exceeds wall depth')
    return dict(profiles=profiles,supports=rs,edges=edges,bays=bays,walls=rw,ownership=ownership,configs=configs)


def triangles(poly):
    result=[]
    for p in getattr(poly,'geoms',[poly]):
        if p.is_empty: continue
        require(p.geom_type=='Polygon','Expected polygon region')
        mesh=shapely.constrained_delaunay_triangles(p)
        require(abs(sum(t.area for t in mesh.geoms)-p.area)<1e-7,'Triangulation area mismatch')
        for t in mesh.geoms: result.append(list(orient(t,sign=1).exterior.coords)[:3])
    return result

def extrude(name,poly,lo,hi,frame,kind,owner):
    """Extrude XY-region along local depth, mapping a right-handed local frame."""
    require(hi>lo,f'{name}: nonpositive extrusion depth')
    vs=[]; fs=[]; lookup={}
    def vert(p,z):
        xyz=tuple(frame(p[0],p[1],z)); key=tuple(round(x,12) for x in xyz)
        if key not in lookup: lookup[key]=len(vs); vs.append(xyz)
        return lookup[key]
    for tri in triangles(poly):
        fs.append(tuple(vert(p,lo) for p in reversed(tri)))
        fs.append(tuple(vert(p,hi) for p in tri))
    for p in getattr(poly,'geoms',[poly]):
        p=orient(p,sign=1)
        for ring in [p.exterior,*p.interiors]:
            pts=list(ring.coords)
            for a,b in zip(pts,pts[1:]):
                i,j,k,l=vert(a,lo),vert(b,lo),vert(b,hi),vert(a,hi)
                fs.extend([(i,j,k),(i,k,l)])
    return dict(name=name,owner=owner,type=kind,vertices=vs,faces=fs)


def sweep(name,pts,section,owner):
    # Section x is lateral, y is upward normal; (0,0) is the web bearing trace.
    lat=v15.unit((-(pts[-1][1]-pts[0][1]),pts[-1][0]-pts[0][0],0))
    section=list(orient(Polygon(section),sign=1).exterior.coords)[:-1]; S=len(section); vs=[]; fs=[]
    for i,p in enumerate(pts):
        tangent=v15.unit(v15.sub(pts[min(len(pts)-1,i+1)],pts[max(0,i-1)]))
        normal=v15.unit(v15.cross(tangent,lat))
        require(normal[2]>0,f'{name}: invalid sweep frame')
        vs.extend(v15.add(p,v15.add(v15.mul(lat,x),v15.mul(normal,y))) for x,y in section)
    for i in range(len(pts)-1):
        for j in range(S):
            a=i*S+j; b=i*S+(j+1)%S; fs.extend([(a,b,b+S),(a,b+S,a+S)])
    for tri in triangles(Polygon(section)):
        ids=[min(range(S),key=lambda j:math.dist(section[j],p)) for p in tri]
        fs.append(tuple(reversed(ids))); fs.append(tuple((len(pts)-1)*S+j for j in ids))
    return dict(name=name,owner=owner,type='rib',vertices=vs,faces=fs,bearing_trace=pts)


def check_support_contact(part,section,support):
    end=part['vertices'][:len(section)]
    footprint=Polygon(support['footprint'])
    require(footprint.buffer(TOL).covers(Polygon([(x,y) for x,y,z in end])),
            f'{part["name"]}: rib spring section extends outside pier {support["id"]}')
    require(max(z for x,y,z in end)<=support['spring_z']+TOL,
            f'{part["name"]}: rib spring section rises above support')


def thicken(part,thickness,owner):
    # Deliberately vertical thickness, not a normal offset; exact underside retained.
    vs=part['vertices']; fs=part['faces']; count=len(vs); edges={}
    for f in fs:
        for a,b in zip(f,(*f[1:],f[0])):
            key=tuple(sorted((a,b)))
            if key in edges: edges.pop(key)
            else: edges[key]=(a,b)
    faces=[tuple(reversed(f)) for f in fs]+[tuple(i+count for i in f) for f in fs]
    for a,b in edges.values(): faces.extend([(a,b,b+count),(a,b+count,a+count)])
    return dict(name=owner+'.'+part['name'],owner=owner,type='web',vertices=vs+[(x,y,z+thickness) for x,y,z in vs],faces=faces)


def load_tracery(path):
    # Use the actual R53 API, with its provenance and validation intact.
    base=ROOT.parent/'R53_Universal_2D_Engine'
    sys.path.insert(0,str(base))
    try:
        spec=importlib.util.spec_from_file_location('r16_r53_adapter',base/'engine.py')
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        result=module.build(json.loads(path.read_text()))
    finally: sys.path.remove(str(base))
    units=result['provenance']['units']; require(units in ('mm','m'),f'{path.name}: uncalibrated/source pixels cannot be placed in a metric plan')
    scale={'mm':.001,'m':1}[units]
    stone=affinity.scale(shape(result['regions']['stone']['geometry']),scale,scale,origin=(0,0))
    envelope=affinity.scale(shape(result['regions']['envelope']['geometry']),scale,scale,origin=(0,0))
    return stone,envelope,result


def clip_xy(triangle,lo,hi):
    """Clip a 3D triangle to a vertical rectangular prism, preserving linear Z."""
    pts=list(triangle)
    for axis,bound,sign in [(0,lo[0],1),(0,hi[0],-1),(1,lo[1],1),(1,hi[1],-1)]:
        out=[]
        for a,b in zip(pts,pts[1:]+pts[:1]):
            da=(a[axis]-bound)*sign; db=(b[axis]-bound)*sign
            if da>=0: out.append(a)
            if (da>=0)!=(db>=0): out.append(v15.add(a,v15.mul(v15.sub(b,a),da/(da-db))))
        pts=out
        if not pts: break
    return pts

def check_clearances(doc,parts):
    reports=[]
    for c in doc['clearances']:
        minimum=math.inf; obstruction=None
        for p in parts:
            vs=p['vertices']
            if any(max(v[i] for v in vs)<c['xy_min'][i] or min(v[i] for v in vs)>c['xy_max'][i] for i in (0,1)): continue
            for f in p['faces']:
                clipped=clip_xy([vs[i] for i in f],c['xy_min'],c['xy_max'])
                if clipped:
                    z=min(p[2] for p in clipped)
                    if z<minimum: minimum=z; obstruction=p['name']
        available=None if math.isinf(minimum) else minimum-doc['floor_z']
        reports.append(dict(id=c['id'],required_height=c['height'],available_height=available,limiting_part=obstruction,
                            passed=available is None or available+TOL>=c['height'],method='triangle clipping against vertical XY rectangle; mesh precision'))
    return reports


def build(doc,config_dir=ROOT):
    r=resolve(doc); parts=[]; N=doc['sampling']['segments']; traces={}
    for key,s in r['supports'].items():
        parts.append(extrude(key,Polygon(s['footprint']),doc['floor_z'],s['spring_z'],lambda x,y,z:(x,y,z),'pier',key))
    for key,e in r['edges'].items():
        a,b=[r['supports'][s]['port'] for s in e['supports']]; mid=[(a[0]+b[0])/2,(a[1]+b[1])/2,e['apex_z']]
        traces[key]=[]
        for h,corner in enumerate([a,b]):
            pts=[v15.path(corner,mid,i/N,1.2) for i in range(N+1)]; traces[key].append(pts)
            profile=r['profiles'][e['profile_id']]['polygon']
            part=sweep(f'{key}.half{h}',pts,profile,key)
            check_support_contact(part,profile,r['supports'][e['supports'][h]])
            parts.append(part)
    seam_checks=[]
    for key,b in r['bays'].items():
        c=r['configs'][key]
        try: generated=v15.geometry(c)
        except ValueError as e: raise ContractError(f'{key}: {e}') from e
        crown=(*b['crown_xy'],b['crown_z'])
        radial=[]
        for i,sid in enumerate(b['supports']):
            pts=[v15.path(r['supports'][sid]['port'],crown,j/N,1) for j in range(N+1)]; radial.append(pts)
            profile=r['profiles'][b['radial_profile_id']]['polygon']
            part=sweep(f'{key}.radial.{sid}',pts,profile,key)
            check_support_contact(part,profile,r['supports'][sid])
            parts.append(part)
        M=c['web_steps']
        for p in generated:
            if p['type']!='web': continue
            _,k,h=p['name'].split('_'); k=int(k); h=int(h)
            edge_id=b['edges'][k]; corner_id=b['supports'][(k+h)%len(b['supports'])]
            canonical_half=r['edges'][edge_id]['supports'].index(corner_id)
            edge_trace=traces[edge_id][canonical_half]; rad=radial[(k+h)%len(radial)]
            error=0
            for j in range(1,N+1):
                offset=1+(j-1)*(M+1)
                error=max(error,math.dist(p['vertices'][offset],rad[j]),math.dist(p['vertices'][offset+M],edge_trace[j]))
            require(error<TOL,f'{key}/{edge_id}: web-to-profile bearing mismatch')
            seam_checks.append(dict(bay=key,web=p['name'],edge=edge_id,max_bearing_trace_error=error))
            web=thicken(p,b['web_thickness_vertical'],key)
            web['name']=f'{key}.web.{edge_id}.{corner_id}'
            parts.append(web)
    openings={k:[] for k in r['walls']}; placements=[]
    for o in doc['openings']:
        w=r['walls'][o['wall_id']]; path=(Path(config_dir)/o['layout_file']).resolve()
        stone,envelope,source=load_tracery(path)
        x0,z0,x1,z1=envelope.bounds; dx=o['center_along_wall']-(x0+x1)/2; dz=o['sill_z']-z0
        stone=affinity.translate(stone,dx,dz); envelope=affinity.translate(envelope,dx,dz)
        region=box(0,doc['floor_z'],w['length'],w['top_z'])
        require(region.covers(envelope.buffer(o['minimum_surround'])),f'{o["id"]}: opening leaves insufficient wall surround')
        for prior in openings[o['wall_id']]: require(envelope.distance(prior)>=o['minimum_surround'],f'{o["id"]}: openings overlap or have insufficient separation')
        openings[o['wall_id']].append(envelope)
        # local X right, Z up, depth toward wall right: right-handed frame.
        def frame(x,z,d,w=w): return (w['origin'][0]+w['tangent'][0]*x-w['left_normal'][0]*d,w['origin'][1]+w['tangent'][1]*x-w['left_normal'][1]*d,z)
        lo=-w['depth_interval'][1]+o['reveal_from_left_face']; hi=lo+o['depth']
        tracery=extrude(o['id'],stone,lo,hi,frame,'tracery',o['id'])
        # Check actual support projections, rather than assuming the opening fits between centres.
        for sid,s in r['supports'].items():
            footprint=Polygon(s['footprint'])
            xs=[]; depths=[]
            for x,y in footprint.exterior.coords:
                delta=[x-w['origin'][0],y-w['origin'][1]]
                xs.append(sum(delta[i]*w['tangent'][i] for i in (0,1)))
                depths.append(sum(delta[i]*w['left_normal'][i] for i in (0,1)))
            if max(depths)>w['depth_interval'][0] and min(depths)<w['depth_interval'][1]:
                require(envelope.intersection(box(min(xs),doc['floor_z'],max(xs),s['spring_z'])).area<TOL,f'{o["id"]}: opening intersects pier {sid}')
        parts.append(tracery)
        placements.append(dict(id=o['id'],wall_id=w['id'],source_status=source['status'],source_provenance=source['provenance'],
                               source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),unit_conversion='physical units only; no fit scaling',
                               elevation_bounds=list(envelope.bounds),extrusion_depth=o['depth'],source_corrections=source['diagnostics']['corrections']))
    for key,w in r['walls'].items():
        region=box(0,doc['floor_z'],w['length'],w['top_z'])
        for opening in openings[key]: region=region.difference(opening)
        def frame(x,z,d,w=w): return (w['origin'][0]+w['tangent'][0]*x-w['left_normal'][0]*d,w['origin'][1]+w['tangent'][1]*x-w['left_normal'][1]*d,z)
        parts.append(extrude(key,region,-w['depth_interval'][1],-w['depth_interval'][0],frame,'wall',key))
    clearances=check_clearances(doc,parts)
    failed=[c for c in clearances if not c['passed']]
    require(not failed,'Clearance failure: '+'; '.join(f'{c["id"]}: needs {c["required_height"]:.3f}m, has {c["available_height"]:.3f}m at {c["limiting_part"]}' for c in failed))
    report=dict(schema_version='R16',status='INTEGRATION_STUDY',units='m',
                input_sha256=hashlib.sha256(json.dumps(doc,sort_keys=True,allow_nan=False).encode()).hexdigest(),
                engine_sha256={str(path.relative_to(ROOT.parent)):hashlib.sha256(path.read_bytes()).hexdigest() for path in [ROOT/'integration.py',ROOT/'building.schema.json',ROOT.parent/'Polygonal_Vaults_R15'/'vault.py']},resolved=r,opening_placements=placements,bearing_checks=seam_checks,
                clearances=clearances,parts=[dict(id=p['name'],owner=p['owner'],kind=p['type'],vertices=len(p['vertices']),triangles=len(p['faces'])) for p in parts],
                limitations=['Synthetic example, not a calibrated cathedral plan.','Profiles supplied as polygons; external pier/profile generator not present.',
                'Rib/web contact checked along bearing traces only; finite bearing and joint intersections unresolved.',
                'Web thickness is vertical, not normal to the surface.','Tracery is a constant-depth extrusion of R53 sampled regions, not moulded/rebated stone.',
                'Wall/pier and rib joints remain overlapping separate solids; no masonry block layout or joint cutting.',
                'Clearance checks apply only to requested rectangles at mesh sampling precision; no exhaustive collision or structural certification.'])
    return parts,report


def write_obj(parts,path):
    lines=['# R16 integration study; metres; Z up','mtllib assembly.mtl']; offset=1
    for p in parts:
        lines.extend(['o '+p['name'],'usemtl '+p['type']])
        lines.extend('v '+' '.join(f'{x:.12g}' for x in vertex) for vertex in p['vertices'])
        lines.extend('f '+' '.join(str(i+offset) for i in f) for f in p['faces']); offset+=len(p['vertices'])
    path.write_text('\n'.join(lines)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('input',type=Path); parser.add_argument('--output',type=Path,required=True)
    a=parser.parse_args(); doc=json.loads(a.input.read_text()); parts,report=build(doc,a.input.parent)
    # Validation and clearance checks finish before output files are replaced.
    a.output.mkdir(parents=True,exist_ok=True); write_obj(parts,a.output/'assembly.obj')
    (a.output/'assembly.mtl').write_text(''.join(f'newmtl {k}\nKd {rgb}\n\n' for k,rgb in [('pier','.60 .53 .41'),('rib','.44 .34 .22'),('web','.84 .79 .66'),('wall','.70 .66 .55'),('tracery','.85 .70 .43')]))
    (a.output/'resolved.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(f'Built {len(parts)} parts; {len(report["bearing_checks"])} bearing checks; {len(report["clearances"])} clearances passed')

if __name__=='__main__': main()
