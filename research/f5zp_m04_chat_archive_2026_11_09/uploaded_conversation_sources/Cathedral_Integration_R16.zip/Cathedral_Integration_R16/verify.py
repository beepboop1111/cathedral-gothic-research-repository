"""Save actual integration test results as a reviewable QA artifact."""
import json
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
suite=unittest.defaultTestLoader.discover(str(ROOT),pattern='test_integration.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
report=dict(tests_run=result.testsRun,successful=result.wasSuccessful(),failures=[dict(test=str(t),details=d) for t,d in result.failures],errors=[dict(test=str(t),details=d) for t,d in result.errors])
(ROOT/'output').mkdir(exist_ok=True)
(ROOT/'output'/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() else 1)
