"""R53 strict 2D API over the byte-preserved U01 kernel. No 3D entry points."""
import copy, hashlib, importlib.util, json, math, sys, types
from pathlib import Path
from xml.sax.saxutils import escape
import jsonschema
from shapely.geometry import mapping
from shapely.ops import unary_union
from primitives import Circle, GeometryError, arc_record, circle_circle

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'R52_universal_2d_engine_handoff'/'baseline'
SOURCE=BASE/'tracery_universal_U01.py'
HASH='9ed6c586d352f5be0fd6be147275cc6155ed809b6e8b06cbc44009d5f8aaa0d3'
SCHEMA=json.loads((ROOT/'input.schema.json').read_text())

def validate(doc):
    try: jsonschema.Draft202012Validator(SCHEMA).validate(doc)
    except jsonschema.ValidationError as e: raise GeometryError(f'{list(e.absolute_path)}: {e.message}') from e
    def finite(x):
        if isinstance(x,float) and not math.isfinite(x): raise GeometryError('non-finite input')
        if isinstance(x,dict):
            for v in x.values(): finite(v)
        if isinstance(x,list):
            for v in x: finite(v)
    finite(doc)
    if (doc['units']=='px') != (doc['unit_authority']=='uncalibrated_source'):
        raise GeometryError('unit authority mismatch; conversions are not supported in R53')
    if doc['unit_authority']=='synthetic' and doc['evidence_class']!='synthetic':
        raise GeometryError('synthetic dimensions require synthetic evidence')
    g=doc['geometry']
    if g['mode']=='plate' and ('voids' not in g or 'fill' in g): raise GeometryError('plate needs voids and cannot have fill')
    if g['mode']=='bar' and ('frame' not in g['outline'] or 'voids' in g): raise GeometryError('bar needs frame and cannot have voids')
    names=[v['name'] for v in g.get('voids',[])]
    if len(set(names))!=len(names) or any(n in ('outline','W','frame') for n in names): raise GeometryError('duplicate/reserved void ID')
    def check_arch(a,local=False):
        if a['type']=='measured':
            if local: raise GeometryError('measured nested sub-arches unsupported')
            if not {'xl','xr','CL'}<=a.keys() or ('CR' in a)==('axis' in a): raise GeometryError('measured arch needs jambs, CL and exactly one of CR/axis')
            if a['xl']>=a['xr']: raise GeometryError('inverted jambs')
            c=Circle(*a['CL']); d=Circle(*a['CR']) if 'CR' in a else Circle(2*a['axis']-c.x,c.z,c.radius)
            if c!=d and circle_circle(c,d).kind=='NONE': raise GeometryError('arch circles do not intersect')
            for x,k in ((a['xl'],c),(a['xr'],d)):
                if abs(x-k.x)>k.radius: raise GeometryError('arc cannot reach jamb')
        elif not local and not {'span','spring'}<=a.keys(): raise GeometryError('arch needs span and spring')
        elif a.get('f',1)<.5: raise GeometryError('arch radius too small')
    check_arch(g['outline']['arch'])
    for v in g.get('voids',[]):
        if sum(k in v for k in ('arch','circles','regular'))!=1: raise GeometryError('void requires exactly one geometry')
        if 'arch' in v:
            if 'sill' not in v: raise GeometryError('arch void needs sill')
            check_arch(v['arch'])
        for c in v.get('circles',[]): Circle(*c)
    def fill(f,depth=0):
        if f is None:return
        if depth>8: raise GeometryError('nesting exceeds eight levels')
        if 'children' in f and len(f['children'])!=f['n']: raise GeometryError('children count differs from n')
        if f['type']=='intersecting' and any(k in f for k in ('head','children','sub_arch')): raise GeometryError('intersecting fill does not support head/children/sub_arch')
        if 'head' in f and f['n']!=2: raise GeometryError('oculus needs two lights')
        if 'sub_arch' in f: check_arch(f['sub_arch'],True)
        for child in f.get('children',[]): fill(child,depth+1)
    fill(g.get('fill'))


def load_kernel():
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest()!=HASH: raise GeometryError('U01 source hash mismatch')
    # The upstream import is optional only for 3D. Restore module state after import.
    stub=None
    try: import triangle
    except ImportError:
        stub=types.ModuleType('triangle'); stub.__spec__=importlib.util.spec_from_loader('triangle',loader=None); sys.modules['triangle']=stub
    try:
        spec=importlib.util.spec_from_file_location('_r53_u01',SOURCE)
        u=importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
    finally:
        if stub is not None: sys.modules.pop('triangle',None)
    return u


def build(doc):
    validate(doc)
    u=load_kernel(); captured=[]; arches={}; sills={}
    original_circle=u.Circle
    class RecordedCircle(original_circle):
        def __init__(self,x,z,r):
            super().__init__(x,z,r); captured.append(self)
        def rec(self): return [self.x,self.z,self.r]
    u.Circle=RecordedCircle
    class Model2D(u.Model):
        def fill(self,f,w,sill,path):
            sills[path]=sill
            return super().fill(f,w,sill,path)
        def _arch_checks(self,name,a):
            arches['W' if name=='W intrados' else name]=a
            super()._arch_checks(name,a)
        def solids(self): raise GeometryError('3D disabled')
        def _topology(self):
            if self.mode=='plate':
                for i,(_,name,p) in enumerate(self.vpolys):
                    if not p.is_valid or not self.outline.contains(p): raise GeometryError(f'{name}: invalid/outside void')
                    for _,other,q in self.vpolys[i+1:]:
                        if p.intersects(q): raise GeometryError(f'voids overlap or touch: {name}, {other}')
            super()._topology()
    spec=copy.deepcopy(doc['geometry']); spec['tolerance']=doc['sampling_sagitta_tolerance']
    try: m=Model2D(spec)
    except (ValueError,KeyError,ZeroDivisionError,IndexError) as e: raise GeometryError(f'construction rejected: {e}') from e
    failed=[c for c in m.checks if not c['ok']]
    if failed: raise GeometryError('QA rejected: '+ '; '.join(c['name'] for c in failed))
    sills['outline']=m.sill if m.mode=='plate' else m.sill-spec['outline'].get('sill_band',spec['outline']['frame'])
    for v in spec.get('voids',[]):
        if 'arch' in v:sills[v['name']]=v['sill']
    curves=[]
    anchors=[]
    for name,a in sorted(arches.items()):
        for side,c,p,q in [('left',a.CL,a.sl,a.apex),('right',a.CR,a.apex,a.sr)]:
            curves.append(arc_record(name+'.'+side,name,Circle(c.x,c.z,c.r),p,q))
        anchors.append(dict(id=name,apex_source_units=a.apex,spring_left_source_units=a.sl,spring_right_source_units=a.sr))
        if name in sills:
            sill=sills[name]
            for label,p,q in [('jamb_left',(a.xl,sill),a.sl),('jamb_right',a.sr,(a.xr,sill)),('sill',(a.xr,sill),(a.xl,sill))]:
                length=math.dist(p,q)
                if length==0:continue
                tangent=[(q[i]-p[i])/length for i in range(2)]
                curves.append(dict(curve_id=name+'.'+label,parent_id=name,kind='segment',start_source_units=p,end_source_units=q,
                    tangent_start=tangent,tangent_end=tangent,normal_convention='left of travel',normal_start=[-tangent[1],tangent[0]]))
    # Circle constructors retain full precision even where U01's summary rounds oculus radii.
    def circle_record(name,parent,rec):
        x,z,r=rec
        c=Circle(x,z,r)
        curves.append(arc_record(name,parent,c,(x+r,z),(x+r,z),clockwise=False,full=True))
    for name,record in sorted(m.con['circles'].items()):
        if isinstance(record,list):
            for i,c in enumerate(record): circle_record(f'{name}.circle{i+1}',name,c)
        elif 'centre_line' in record: circle_record(name+'.centreline',name,record['centre_line'])
        else:
            matches=[c for c in captured if [round(c.x,6),round(c.z,6)]==record['centre'] and round(c.r,6)==record['r_outer']]
            if not matches: raise GeometryError('missing full-precision oculus')
            c=matches[0]; circle_record(name+'.outer',name,[c.x,c.z,c.r])
            for i,lobe in enumerate(record.get('foil',{}).get('lobes',[])): circle_record(f'{name}.lobe{i+1}',name,lobe)
    for c in curves:
        c.update(source_status=doc['evidence_class'],geometry_role='construction',source_id=doc['source_id'])
    vu=unary_union([v['poly'] for v in m.voids])
    residual=m.stone.union(vu).symmetric_difference(m.outline).area
    if not m.stone.is_valid or residual>doc['construction_tolerance']**2: raise GeometryError('region partition failed')
    def region(p): return dict(boundary_representation='sampled_polygon',geometry=mapping(p),area_source_units_sq=p.area,bounds_source_units=list(p.bounds))
    members=[dict(id=x['name'],kind=x['kind'],parent_id=x['name'].rsplit('.',1)[0] if '.' in x['name'] else 'root') for x in m.members]
    nodes={'root':dict(id='root',parent_id=None)}
    for identifier in [c['parent_id'] for c in curves]+[v['id'] for v in m.voids]+[x['id'] for x in members]:
        while identifier!='root':
            parent=identifier.rsplit('.',1)[0] if '.' in identifier else 'root'
            nodes[identifier]=dict(id=identifier,parent_id=parent); identifier=parent
    out=dict(schema_version='R53',status='VALIDATED_2D',id=spec['id'],
        provenance={k:doc[k] for k in ('units','coordinate_frame','unit_authority','source_id','source_file_hash','drawing_view','evidence_class','historical_status')},
        analytic_curves=curves,anchors=anchors,topology=dict(nodes=sorted(nodes.values(),key=lambda x:x['id']),members=members,
        junctions=[dict(id=f'J{i+1:03}',members=[a,b],kind=k) for i,(a,b,k) in enumerate(m.junctions)],minimum_web_source_units=m.web),
        regions=dict(stone=region(m.stone),envelope=region(m.outline),openings=[dict(id=v['id'],parent_id=nodes[v['id']]['parent_id'],role=v['role'],**region(v['poly'])) for v in m.voids]),
        diagnostics=dict(checks=sorted(m.checks,key=lambda c:c["name"]),partition_residual_source_units_sq=residual,corrections=m.corrections,cleaned_vertex_count=getattr(m,'cleaned',0)),
        limitations=['Construction arcs are exact; boolean region boundaries remain sampled.','No historical calibration, architectural approval or 3D layout lock.'],
        construction_tolerance_source_units=doc['construction_tolerance'],sampling_sagitta_tolerance_source_units=doc['sampling_sagitta_tolerance'])
    out['provenance'].update(kernel_sha256=HASH,wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    return out


def write_svg(result,path):
    x0,z0,x1,z1=result['regions']['envelope']['bounds_source_units']; pad=(z1-z0)*.06
    def rings(geom):
        polygons=[geom['coordinates']] if geom['type']=='Polygon' else geom['coordinates']
        return ' '.join('M '+' L '.join(f'{x},{-z}' for x,z in ring)+' Z' for poly in polygons for ring in poly)
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0-pad} {-z1-pad} {x1-x0+2*pad} {z1-z0+2*pad}">', '<title>'+escape(result['id'])+' — R53 experimental 2D</title>']
    s.append('<g id="construction" fill="none" stroke="#999" stroke-width="1" stroke-dasharray="8 8">')
    for c in result['analytic_curves']:
        if c['kind']!='arc':continue
        x,z=c['centre_source_units'];r=c['radius_source_units']
        s.append(f'<circle cx="{x}" cy="{-z}" r="{r}"/>')
    s.append('</g><g id="confirmed-input" fill="#d4d8d5" stroke="black" stroke-width="1" fill-rule="evenodd">')
    s.append('<path d="'+rings(result['regions']['stone']['geometry'])+'"/></g>')
    s.append('<g id="uncertain-interpretation" fill="none" stroke="#b44" stroke-dasharray="8 8">')
    if result['provenance']['evidence_class']!='synthetic': s.append('<path d="'+rings(result['regions']['envelope']['geometry'])+'"/>')
    s.append('</g></svg>'); Path(path).write_text('\n'.join(s))

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    result=build(json.loads(a.input.read_text()));a.output.mkdir(parents=True,exist_ok=True)
    (a.output/'model.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    write_svg(result,a.output/'model.svg')
