"""Strict analytical primitives. Coordinates are (x,z); angles are radians."""
from dataclasses import dataclass
import math

class GeometryError(ValueError):
    pass

def number(v):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise GeometryError('expected a finite number')
    return float(v)

def point(p):
    if len(p) != 2:
        raise GeometryError('point needs two coordinates')
    return tuple(number(v) for v in p)

@dataclass(frozen=True)
class Circle:
    x: float
    z: float
    radius: float
    def __post_init__(self):
        for v in (self.x, self.z, self.radius): number(v)
        if self.radius <= 0: raise GeometryError('radius must be positive')

@dataclass(frozen=True)
class Intersection:
    kind: str
    points: tuple

def circle_circle(a, b, tolerance=1e-10):
    t = number(tolerance)
    if t <= 0: raise GeometryError('tolerance must be positive')
    dx, dz = b.x-a.x, b.z-a.z
    d = math.hypot(dx, dz)
    if d == 0:
        if a.radius == b.radius: raise GeometryError('COINCIDENT: infinitely many intersections')
        return Intersection('NONE', ())
    if d > a.radius+b.radius+t or d < abs(a.radius-b.radius)-t:
        return Intersection('NONE', ())
    along = (d*d+(a.radius-b.radius)*(a.radius+b.radius))/(2*d)
    h2 = (a.radius-along)*(a.radius+along)
    mx, mz = a.x+along*dx/d, a.z+along*dz/d
    if abs(d-a.radius-b.radius)<=t or abs(d-abs(a.radius-b.radius))<=t:
        return Intersection('TANGENT', ((mx,mz),))
    if h2 < 0: return Intersection('NONE', ())
    h = math.sqrt(h2)
    return Intersection('TWO', tuple(sorted(((mx-h*dz/d,mz+h*dx/d),(mx+h*dz/d,mz-h*dx/d)))))

def circle_line(c, origin, direction, tolerance=1e-10):
    x,z = point(origin); dx,dz = point(direction)
    t=number(tolerance)
    if t<=0: raise GeometryError('tolerance must be positive')
    length=math.hypot(dx,dz)
    if length==0: raise GeometryError('line direction cannot be zero')
    dx,dz=dx/length,dz/length
    along=(c.x-x)*dx+(c.z-z)*dz
    px,pz=x+along*dx,z+along*dz
    dist=math.hypot(px-c.x,pz-c.z)
    if dist>c.radius+t: return Intersection('NONE',())
    if abs(dist-c.radius)<=t: return Intersection('TANGENT',((px,pz),))
    h=math.sqrt((c.radius-dist)*(c.radius+dist))
    return Intersection('TWO',tuple(sorted(((px-h*dx,pz-h*dz),(px+h*dx,pz+h*dz)))))

def arc_record(identifier, parent, c, start, end, clockwise=True, full=False):
    start,end=point(start),point(end)
    for p in (start,end):
        if abs(math.hypot(p[0]-c.x,p[1]-c.z)-c.radius)>1e-9*max(1,c.radius):
            raise GeometryError('arc endpoint is off circle')
    a=math.atan2(start[1]-c.z,start[0]-c.x)
    b=math.atan2(end[1]-c.z,end[0]-c.x)
    sweep=-((a-b)%(2*math.pi)) if clockwise else (b-a)%(2*math.pi)
    if full: sweep=(-1 if clockwise else 1)*2*math.pi
    if sweep==0: raise GeometryError('zero arc sweep')
    sign=-1 if clockwise else 1
    tangent=lambda v: [-sign*math.sin(v), sign*math.cos(v)]
    return dict(curve_id=identifier,parent_id=parent,kind='arc',centre_source_units=[c.x,c.z],
                radius_source_units=c.radius,start_angle_rad=a,end_angle_rad=a+sweep,
                start_source_units=start,end_source_units=end,winding='CW' if clockwise else 'CCW',
                tangent_start=tangent(a),tangent_end=tangent(a+sweep),
                normal_convention='left of travel',normal_start=[-tangent(a)[1],tangent(a)[0]],normal_end=[-tangent(a+sweep)[1],tangent(a+sweep)[0]])
