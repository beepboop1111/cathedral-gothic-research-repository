"""Standalone polygonal rib-vault study engine. Coordinates and elevations in metres."""
import argparse
import json
import math
from pathlib import Path

EPS = 1e-9

def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def mul(a,s): return tuple(x*s for x in a)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def length(a): return math.sqrt(dot(a,a))
def unit(a): return mul(a,1/length(a))
def orient(a,b,c): return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def intersects(a,b,c,d):
    def on(a,b,p):
        return abs(orient(a,b,p)) <= EPS and all(min(a[k],b[k])-EPS <= p[k] <= max(a[k],b[k])+EPS for k in (0,1))
    o=[orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)]
    return (o[0]*o[1]<0 and o[2]*o[3]<0) or on(a,b,c) or on(a,b,d) or on(c,d,a) or on(c,d,b)

def validate(c):
    p=c['corners']; n=len(p)
    if n<3 or any(len(v)!=2 for v in p): raise ValueError('Supply at least three XY corners in boundary order')
    if len(c['apices'])!=n: raise ValueError('Supply one arch apex elevation per boundary edge')
    if len(c['crown_xy'])!=2: raise ValueError('Crown position needs X and Y')
    values=[x for v in p for x in v]+c['apices']+c['crown_xy']+[c[k] for k in ('spring','crown','web_radius','rib_radius')]
    if any(not isinstance(x,(float,int)) or not math.isfinite(x) for x in values): raise ValueError('All measurements must be finite numbers')
    if min(c['web_radius'],c['rib_radius'])<=0: raise ValueError('Radii must be positive')
    if min([c['crown']]+c['apices'])<=c['spring']: raise ValueError('Crown and arch apices must exceed springing')
    for key,default,minimum in [('segments',48,4),('web_steps',20,2),('rib_sides',16,3)]:
        v=c.get(key,default)
        if type(v)!=int or v<minimum: raise ValueError(f'{key} must be an integer >= {minimum}')
    for i in range(n):
        if length(sub(p[i],p[(i+1)%n]))<EPS: raise ValueError('Repeated adjacent corners')
        if abs(orient(p[i-1],p[i],p[(i+1)%n]))<EPS: raise ValueError('Collinear consecutive corners')
        for j in range(i+1,n):
            if j==i+1 or (i==0 and j==n-1): continue
            if intersects(p[i],p[(i+1)%n],p[j],p[(j+1)%n]): raise ValueError('Boundary must be simple, with no crossings or touching edges')
    area=sum(orient((0,0),p[i],p[(i+1)%n]) for i in range(n))
    if abs(area)<EPS: raise ValueError('Plan has zero area')
    direction=1 if area>0 else -1
    if any(direction*orient(p[i],p[(i+1)%n],c['crown_xy'])<=EPS for i in range(n)):
        raise ValueError('Crown must be strictly inside the plan kernel: every edge must be visible from it')
    return direction

def path(a,b,t,ratio):
    r=(1+ratio*ratio)/2; theta=math.atan2(ratio,r-1)
    h=r*(1-math.cos(theta*t)); v=r*math.sin(theta*t)/ratio
    return (a[0]+(b[0]-a[0])*h,a[1]+(b[1]-a[1])*h,a[2]+(b[2]-a[2])*v)

def section(a,b,u,r):
    d=sub(b,a); size=length(d)
    if size<EPS: return a
    if size>2*r: raise ValueError('Web radius is too small for a web chord')
    tangent=mul(d,1/size); normal=sub((0,0,1),mul(tangent,tangent[2]))
    if length(normal)<EPS: raise ValueError('Vertical web chord is unsupported')
    sag=math.sqrt(max(0,r*r-(size*(u-.5))**2))-math.sqrt(max(0,r*r-(size/2)**2))
    return add(add(a,mul(d,u)),mul(unit(normal),sag))

def geometry(c):
    direction=validate(c); n=len(c['corners'])
    N=c.get('segments',48); M=c.get('web_steps',20); S=c.get('rib_sides',16)
    corners=[(*p,c['spring']) for p in c['corners']]; crown=(*c['crown_xy'],c['crown'])
    mids=[(*(mul(add(c['corners'][k],c['corners'][(k+1)%n]),.5)),c['apices'][k]) for k in range(n)]
    parts=[]
    def rib(name,a,b,ratio):
        pts=[path(a,b,i/N,ratio) for i in range(N+1)]
        lat=unit((-(b[1]-a[1]),b[0]-a[0],0)); vs=[]; fs=[]
        for i,p in enumerate(pts):
            tangent=unit(sub(pts[min(N,i+1)],pts[max(0,i-1)])); normal=unit(cross(tangent,lat))
            if normal[2]<0: normal=mul(normal,-1)
            origin=sub(p,mul(normal,c['rib_radius']))
            vs.extend(add(origin,mul(add(mul(normal,math.cos(2*math.pi*j/S)),mul(lat,math.sin(2*math.pi*j/S))),c['rib_radius'])) for j in range(S))
        for i in range(N):
            for j in range(S):
                a=i*S+j; b=i*S+(j+1)%S
                fs.extend([(a,b,b+S),(a,b+S,a+S)])
        for j in range(1,S-1): fs.extend([(0,j+1,j),(N*S,N*S+j,N*S+j+1)])
        parts.append({'name':name,'vertices':vs,'faces':fs,'type':'rib'})
    for k,a in enumerate(corners): rib(f'radial_{k}',a,crown,1)
    for k,mid in enumerate(mids):
        for h,corner in enumerate((corners[k],corners[(k+1)%n])):
            rib(f'wall_{k}_{h}',corner,mid,1.2)
            vs=[corner]; fs=[]
            for i in range(1,N+1):
                a=path(corner,crown,i/N,1); b=path(corner,mid,i/N,1.2)
                vs.extend(section(a,b,j/M,c['web_radius']) for j in range(M+1))
            for j in range(M): fs.append((0,1+j,2+j))
            for i in range(N-1):
                for j in range(M):
                    a=1+i*(M+1)+j; b=a+M+1
                    fs.extend([(a,b,b+1),(a,b+1,a+1)])
            if (h==0 and direction>0) or (h==1 and direction<0): fs=[tuple(reversed(f)) for f in fs]
            # A projected fold is invalid even if the boundary polygon was valid.
            if any(orient(vs[a],vs[b],vs[d])<=EPS for a,b,d in fs):
                raise ValueError('Web folds in plan; adjust crown, heights, footprint or web radius')
            parts.append({'name':f'web_{k}_{h}','vertices':vs,'faces':fs,'type':'web'})
    return parts

def export_obj(parts,target):
    lines=['# Polygonal vault study; metres; Z up']; offset=1
    for part in parts:
        lines.append('o '+part['name'])
        lines.extend('v '+' '.join(f'{x:.10g}' for x in v) for v in part['vertices'])
        lines.extend('f '+' '.join(str(i+offset) for i in f) for f in part['faces'])
        offset+=len(part['vertices'])
    Path(target).write_text('\n'.join(lines)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('config',type=Path); parser.add_argument('output',type=Path)
    args=parser.parse_args(); parts=geometry(json.loads(args.config.read_text()))
    export_obj(parts,args.output)
    print(f'Created {args.output}: {len(parts)} parts, {sum(len(p["faces"]) for p in parts)} triangles')

if __name__=='__main__': main()
