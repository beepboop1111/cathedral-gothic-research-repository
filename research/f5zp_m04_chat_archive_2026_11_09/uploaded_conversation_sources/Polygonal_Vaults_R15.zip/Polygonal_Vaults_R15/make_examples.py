import json
import math
from pathlib import Path
from vault import geometry, export_obj

ROOT=Path(__file__).resolve().parent

def main():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    examples={
        'pentagonal': [[3.5*math.cos(k*math.tau/5),3.5*math.sin(k*math.tau/5)] for k in range(5)],
        'irregular': [[-3,-3],[2,-3.5],[4,-.5],[2.8,3],[-1,4],[-3.5,1]],
        'concave': [[-3,-3],[3,-2],[4,2],[0,1],[-3,3]],
    }
    fig=plt.figure(figsize=(15,6),facecolor='#f5f2eb')
    for idx,(name,points) in enumerate(examples.items(),1):
        c=dict(corners=points,crown_xy=[0,0],spring=0,crown=4.5,apices=[3.6]*len(points),web_radius=12,rib_radius=.075)
        if name=='irregular': c.update(crown_xy=[.25,.1],apices=[3.4,3.7,3.8,3.5,3.6,3.3])
        (ROOT/f'{name}.json').write_text(json.dumps(c,indent=2)+'\n')
        parts=geometry(c); export_obj(parts,ROOT/f'{name}.obj')
        ax=fig.add_subplot(1,3,idx,projection='3d',computed_zorder=False)
        ax.set_facecolor('#f5f2eb')
        for part in parts:
            v=part['vertices']; faces=[[v[i] for i in f] for f in part['faces']]
            ax.add_collection3d(Poly3DCollection(faces,facecolor='#ab9470' if part['type']=='rib' else '#ddd2b8',edgecolor='none',alpha=1,zorder=2 if part['type']=='rib' else 1))
        ax.set(xlim=(-4.5,4.5),ylim=(-4.5,4.5),zlim=(0,6))
        ax.set_box_aspect((9,9,6)); ax.view_init(elev=27,azim=-65)
        ax.set_axis_off(); ax.set_title(name.title(),fontsize=16,pad=0)
    fig.suptitle('Polygonal & irregular vaults • R15',fontsize=22,y=.98)
    fig.text(.5,.06,'Separate mesh studies • adjustable crown and boundary arches • metres',ha='center',fontsize=12)
    fig.subplots_adjust(left=0,right=1,bottom=.12,top=.90,wspace=0)
    fig.savefig(ROOT/'preview.png',dpi=150,facecolor=fig.get_facecolor())

if __name__=='__main__': main()
