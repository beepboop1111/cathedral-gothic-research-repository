# R15 — Polygonal and irregular vault studies

Standalone mesh generator; no Blender add-on or Blender installation required to generate OBJ files. The R14 files are unchanged.

Start with `pentagonal.obj`, `irregular.obj`, or `concave.obj` in any OBJ-capable 3D application. The preview shows the three example studies. Mesh coordinates use metres and Z up; check import axis/scale settings in your application.

## Controls

Each matching JSON file describes a footprint. Corners are XY pairs in consecutive boundary order, clockwise or counterclockwise. `apices[i]` sets the absolute elevation of the arch on the edge from corner i to the next corner. Arches peak at edge midpoints. `crown_xy` moves the central meeting point; `crown` sets its absolute elevation. `spring` is the common springing elevation. `web_radius` controls circular cross-web sections; `rib_radius` sets the circular test rib profile.

From this folder, generate a changed configuration with:

```
python3 vault.py irregular.json my_irregular.obj
```

Generation uses only Python's standard library. Preview reproduction (`python3 make_examples.py`) additionally uses matplotlib. Run checks with `python3 -m unittest -v` from this folder.

## Geometry and supported scope

For n corners, the engine builds n radial rib branches, 2n perimeter half-arches and 2n web panels. It carries forward the R14 normalized arc families: 1.0 radial and 1.2 perimeter shape ratios. These are affine curves, not necessarily circular arches after scaling. Matching boundaries share coordinates; separate objects are not welded. Ribs sit beneath their reference curves. Webs are thin surfaces, without thickness. OBJ uses named parts but no material library.

Convex polygons and star-shaped concave footprints are supported when the crown lies strictly inside the polygon kernel (on the interior side of every edge). This is deliberately not an arbitrary concave-plan solver. Crossing/touching boundaries, duplicate corners, collinear consecutive corners, unsuitable crown positions, nonfinite values, low apices, insufficient web radius and sampled web folds are rejected before writing an output file.

A crown is a radial-rib anchor elevation, not a guaranteed global maximum of the web. Projected triangle checks reject folds within each web panel; they do not prove absence of all cross-panel or rib intersections. No structural adequacy, historical accuracy, rib bearing, watertightness or fabrication readiness is claimed. No ambulatory integration or existing generator replacement is included.

## Verification

Automated checks cover clockwise/counterclockwise rectangular, pentagonal and concave plans, nondegenerate triangles, paired web seams, shared radial boundaries, independent perimeter-apex controls and invalid-input rejection. All three supplied meshes were generated at 48 longitudinal segments, 20 web subdivisions and 16 rib sides. These are initial geometry studies rather than a finished editing interface.
