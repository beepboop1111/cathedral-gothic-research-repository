import copy
import math
import unittest
from vault import geometry, length, sub, cross

def config(points):
    return dict(corners=points, crown_xy=[0,0], spring=0, crown=4.5,
                apices=[3.6]*len(points), web_radius=12, rib_radius=.075,
                segments=12, web_steps=8, rib_sides=8)

class VaultTests(unittest.TestCase):
    def test_valid_plans_and_faces(self):
        for points in ([[-3,-3],[3,-3],[3,3],[-3,3]],
                       [[3*math.cos(k*math.tau/5),3*math.sin(k*math.tau/5)] for k in range(5)],
                       [[-3,-3],[3,-2],[4,2],[0,1],[-3,3]]):
            for p in (points,list(reversed(points))):
                c=config(p); parts=geometry(c)
                self.assertEqual(len(parts),5*len(p))
                for part in parts:
                    v=part['vertices']
                    for a,b,d in part['faces']:
                        self.assertGreater(length(cross(sub(v[b],v[a]),sub(v[d],v[a]))),1e-10)
    def test_shared_web_seams(self):
        c=config([[-3,-3],[3,-2],[4,3],[-2,4]])
        parts={p['name']:p for p in geometry(c)}; M=c['web_steps']; N=c['segments']
        for k in range(4):
            a=parts[f'web_{k}_0']['vertices']; b=parts[f'web_{k}_1']['vertices']
            for j in range(M+1): self.assertLess(length(sub(a[1+(N-1)*(M+1)+j],b[1+(N-1)*(M+1)+j])),1e-10)
            other=parts[f'web_{(k-1)%4}_1']['vertices']
            for i in range(N): self.assertLess(length(sub(a[1+i*(M+1)],other[1+i*(M+1)])),1e-10)
    def test_independent_apex(self):
        c=config([[-3,-3],[3,-2],[4,3],[-2,4]])
        before=geometry(c); c['apices'][1]+=.3; after=geometry(c)
        for a,b in zip(before,after):
            if a['name'].startswith('radial_') or a['name'].startswith(('wall_0','wall_2','wall_3')):
                self.assertEqual(a,b)
    def test_invalid(self):
        base=config([[-3,-3],[3,-3],[3,3],[-3,3]])
        mutations=[{'corners':[[-3,-3],[3,3],[3,-3],[-3,3]]},
                   {'crown_xy':[10,0]}, {'web_radius':.01}, {'crown':0},
                   {'rib_radius':float('nan')}, {'apices':[3]}, {'segments':2}]
        for m in mutations:
            c=copy.deepcopy(base); c.update(m)
            with self.assertRaises(ValueError): geometry(c)

if __name__=='__main__': unittest.main()
