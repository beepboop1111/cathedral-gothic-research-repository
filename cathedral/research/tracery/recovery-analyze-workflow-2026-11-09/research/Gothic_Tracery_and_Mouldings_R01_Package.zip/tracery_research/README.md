# Gothic tracery and mouldings - Research R01

Read the PDF or Markdown report first. This is a substantial synthesis with an explicit incomplete-reading audit, not a certificate of cover-to-cover completion.

- Source_Register.csv: all supplied PDFs and recovered Paley scan, with hashes and duplicate handling.
- Reading_Coverage.csv: each physical page, separating text extraction, prose review and visual survey.
- Sharpe_Window_Catalogue.md: all sixty extracted descriptive entries; dimensions need visual checking.
- figures/: explanatory vector diagram and selected unaltered historical source pages.
- research_data/: extracted text for byte-unique supplied PDFs; OCR is not authoritative.
- Analytic_QA.json: checks of explanatory mathematics, not cathedral geometry.
- Report_QA.json: document checks.
- build_report.py: reproducible report-building script; requires the original supplied PDFs and the retained scratch extraction paths documented in the script. Source downloads and extraction are not fully self-contained in this package.

No geometry, generators or project locks were changed. Morris Part II public transcription found; complete text and illustrated-typology review remain outstanding.
