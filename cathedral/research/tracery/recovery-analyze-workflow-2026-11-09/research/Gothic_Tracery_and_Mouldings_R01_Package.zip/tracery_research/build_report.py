from pathlib import Path
import json, csv, re, hashlib, math, shutil, zipfile, html
import fitz
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle, Arc
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.utils import ImageReader

BASE=Path('/workspace/scratch/49cd97f27c06')
TMP=BASE/'tmp/research'
OUT=BASE/'output/tracery_research'
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'figures').mkdir(exist_ok=True)
(OUT/'research_data').mkdir(exist_ok=True)
inventory=json.loads((TMP/'inventory.json').read_text())
groups={}
for a in inventory: groups.setdefault(a['sha256'],[]).append(a['id'])
canonical={x['id']:groups[x['sha256']][0] for x in inventory}
rows=[]
for x in inventory:
    rows.append(dict(source_id=x['id'],filename=x['file'],pdf_pages=x['pages'],sha256=x['sha256'],canonical_file=canonical[x['id']],text_characters=x['chars'],low_text_pages=len(x['low_text']),review_status='See Reading_Coverage.csv; not cover-to-cover certified'))
paley=TMP/'Paley_1891.pdf'
pp=json.loads((TMP/'Paley.json').read_text())
rows.append(dict(source_id='P01',filename=paley.name,pdf_pages=len(pp),sha256=hashlib.sha256(paley.read_bytes()).hexdigest(),canonical_file='P01',text_characters=sum(map(len,pp)),low_text_pages=sum(len(t.strip())<80 for t in pp),review_status='Selected formation/copying/Decorated text; full reading outstanding'))
with (OUT/'Source_Register.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)

# Conservative review ledger: an extraction never counts as reading.
full={'S11':set(range(3,11)), 'S15':set(range(43,61))|set(range(67,81))|{11,12}, 'S06':{19,20,21,22,26}, 'S10':{42,50,154}, 'S13':{19,20,21,22,23,24,25,26,27,28,29,30},'S12':{13,15,17,18,19,20,21,22},'P01':{72,73}}
partial={'S03':set(range(25,45))|set(range(62,76)), 'S06':set(range(23,451)),'P01':set(range(27,46))|set(range(62,76))}
visual={'S15':{43,53,60,62,64,66,75,78,79},'S13':{19,20,32,33,46,47,78,79,120},'S05':{7,9,25,37,55,73,95,119,149},'S10':{42,43,44,50,51,52,154,155,156}}
with (OUT/'Reading_Coverage.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['source_id','filename','pdf_page_1_based','text_characters','text_review','visual_review','canonical_file','next_work'])
    for x in rows:
        sid=x['source_id'];p=pp if sid=='P01' else json.loads((TMP/(sid+'.json')).read_text())
        for i,t in enumerate(p,1):
            status='extracted only; not close-read'
            if i in partial.get(sid,set()): status='selected passage or page-opening survey; not full-page certified'
            if i in full.get(sid,set()):status='main extracted prose reviewed; illustration detail separate'
            vr='selected plate/page visual survey' if i in visual.get(sid,set()) else 'not individually inspected'
            if x['canonical_file']!=sid:status='exact duplicate; see canonical file';vr='see canonical file'
            w.writerow([sid,x['filename'],i,len(t),status,vr,x['canonical_file'],'close-read/visual verification unless already completed'])

# Keep all supplied-text extractions available, without copying the source PDFs.
for x in inventory:
    if canonical[x['id']]==x['id']:shutil.copy(TMP/(x['id']+'.txt'),OUT/'research_data'/(x['id']+'_extracted_text.txt'))

cat=['# Sharpe - Decorated Windows: all sixty descriptive entries','',
     'Source S10, gri_33125016431344.pdf. The following are uncorrected text-layer extractions, not measured transcriptions. PDF locators are one-based. Read each entry with its elevation and the Treatise. Illegible dimensions are not silently repaired.','']
source=json.loads((TMP/'S10.json').read_text())
for k,n in enumerate(range(10,247,4),1):
    t=' '.join(source[n-1].split())
    cat+= [f'## Example {k:02d} - descriptive PDF page {n}', '', t,'']
(OUT/'Sharpe_Window_Catalogue.md').write_text('\n'.join(cat))

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig,axs=plt.subplots(2,2,figsize=(12,8.4),layout='constrained')
ax=axs[0,0]
ax.set_title('A. Interior face: depth and projection are separate',loc='left',fontweight='bold')
poly=np.array([[-45,-75],[45,-75],[45,-40],[32,-40],[32,-5],[21,-5],[21,22],[11,22],[11,50],[-11,50],[-11,22],[-21,22],[-21,-5],[-32,-5],[-32,-40],[-45,-40]])
ax.add_patch(Polygon(poly,facecolor='#d9d6cc',edgecolor='black',linewidth=1.5))
ax.axhline(0,color='#28617a',ls='--',label='glass datum y = 0 (illustrative)')
for z,c,label in [(50,'#444','primary leading face'),(22,'#777','secondary leading face'),(-5,'#aaa','tertiary leading face')]:
 ax.hlines(z,50,105,color=c,ls=':');ax.text(54,(-20 if z==-5 else z+5),label,fontsize=9)
ax.set_xlim(-70,200);ax.set_ylim(-100,80);ax.set_xlabel('u: across path');ax.set_ylabel('y: inward depth');ax.legend(loc='lower right',fontsize=8);ax.set_aspect('equal')
ax=axs[0,1];ax.set_title('B. Same envelope, different section',loc='left',fontweight='bold')
x=np.linspace(0,1,150)
for off,p,label in [(0,x,'straight chamfer'),(1.5,x**2,'concave profile'),(3,3*x*x-2*x*x*x,'compound curvature')]:
 ax.plot(x+off,p,color='black',lw=2);ax.plot([off,off+1,off+1],[0,0,1],ls=':',color='gray');ax.text(off+.5,-.25,label,ha='center',fontsize=9)
ax.set_xlim(-.1,4.3);ax.set_ylim(-.4,1.3);ax.set_aspect('equal');ax.axis('off')
ax=axs[1,0];ax.set_title('C. Chamfer angle must be measured',loc='left',fontweight='bold')
angles=[(40,40),(60,30),(30,60)]
for k,(du,dv) in enumerate(angles):
 off=k*100;ax.plot([off,off+du],[0,dv],color='black',lw=2);ax.plot([off,off+du,off+du],[0,0,dv],ls='--',color='gray');ax.text(off+du/2,-12,f'{math.degrees(math.atan2(dv,du)):.2f} deg',ha='center');ax.text(off+du/2,dv+8,f'du={du}, dv={dv}',ha='center',fontsize=9)
ax.set_xlim(-10,290);ax.set_ylim(-30,90);ax.axis('off');ax.set_aspect('equal')
ax=axs[1,1];ax.set_title('D. Acute branches lengthen offset intersections',loc='left',fontweight='bold')
beta=np.linspace(15,120,200);ax.plot(beta,1/np.sin(np.radians(beta/2)),color='black');ax.set_xlabel('included angle beta (degrees)');ax.set_ylabel('d / w = 1 / sin(beta / 2)');ax.grid(alpha=.2)
for b in [30,60,90]:
 y=1/math.sin(math.radians(b/2));ax.scatter([b],[y],color='#28617a');ax.annotate(f'{b} deg: {y:.3f}',(b,y),xytext=(8,8),textcoords='offset points',fontsize=9)
fig.suptitle('Section and junction principles - explanatory geometry, not historical profiles',fontweight='bold',fontsize=15)
fig.savefig(OUT/'figures/Depth_Angles_and_Junctions.png',dpi=180)
fig.savefig(OUT/'figures/Depth_Angles_and_Junctions.svg')
plt.close(fig)

qa={'purpose':'Analytic consistency of explanatory examples only; no cathedral/model validation','tests':[]}
def test(name,value,expected,tol=1e-10):
    ok=abs(value-expected)<=tol;qa['tests'].append(dict(name=name,value=value,expected=expected,tolerance=tol,pass_result=ok));assert ok,name
test('Equal-offset chamfer angle degrees',math.degrees(math.atan2(40,40)),45)
test('Raunds width 16 ft 3 in to metres',16*.3048+3*.0254,4.953)
test('90-degree branch ratio',1/math.sin(math.pi/4),math.sqrt(2))
test('60-degree branch ratio',1/math.sin(math.pi/6),2)
test('Circular offset local singular factor at u=R',1-100*(1/100),0)
qa['all_pass']=True
(OUT/'Analytic_QA.json').write_text(json.dumps(qa,indent=2))

# Source figures reproduced without altering the historical drawings.
source_figs=[]
sources={x['id']:BASE/'upload'/x['file'] for x in inventory}
for sid,num,caption in [
 ('S15',60,'Sharpe, Treatise, printed p. 42: Howden order diagram and explicit varying-scale warning.'),
 ('S15',62,'Sharpe, Treatise, plate C: comparison sections. Each item requires its own scale verification.'),
 ('S15',64,'Sharpe, Treatise, plate D: comparison sections; not a common-scale profile library.'),
 ('S15',66,'Sharpe, Treatise, plate E: further comparison sections and back-joint information.'),
 ('S15',79,'Sharpe, Treatise, printed p. 55: paired mullion and tracery sections.'),
 ('S13',20,'Billings, Power of Form, printed p. 16: projection, recession and primary/secondary expression.'),
 ('S05',37,'Brandon, supplied Volume II: Holy Trinity, Sarum, window with mullion and jamb sections. Scale must be read independently.')]:
    d=fitz.open(sources[sid]);p=d[num-1];pix=p.get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False);dest=OUT/'figures'/f'{sid}_PDF_{num:03d}.png';pix.save(dest);source_figs.append((dest,caption))

ST=getSampleStyleSheet()
ST.add(ParagraphStyle(name='BodyResearch',fontName='Helvetica',fontSize=9.5,leading=13.3,spaceAfter=7,allowWidows=0,allowOrphans=0,textColor=colors.HexColor('#202c34')))
ST.add(ParagraphStyle(name='SmallResearch',fontName='Helvetica',fontSize=8,leading=10.5,spaceAfter=4))
ST['Heading1'].fontSize=20;ST['Heading1'].leading=24;ST['Heading1'].textColor=colors.HexColor('#183f52');ST['Heading1'].spaceBefore=14
ST['Heading2'].fontSize=13;ST['Heading2'].leading=17;ST['Heading2'].textColor=colors.HexColor('#183f52');ST['Heading2'].spaceBefore=13
ST['Heading3'].fontSize=10.5;ST['Heading3'].leading=14;ST['Heading3'].spaceBefore=9
def fmt(s):
    s=html.escape(s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'(?<!\*)\*([^*]+)\*',r'<i>\1</i>',s)
    return s
story=[]
lines=(OUT/'Gothic_Tracery_and_Mouldings_R01.md').read_text().splitlines();i=0
while i<len(lines):
    l=lines[i].strip()
    if l.startswith('- '):
        story.append(Paragraph(fmt(l[2:]),ST['SmallResearch'],bulletText='-'));i+=1;continue
    if not l:i+=1;continue
    if l.startswith('|'):
        tbl=[]
        while i<len(lines) and lines[i].strip().startswith('|'):
            rr=[x.strip() for x in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r'[-: ]+',x or '-') for x in rr):tbl.append(rr)
            i+=1
        n=len(tbl[0]);widths=([98,170,240] if n==3 else [155,353] if n==2 else [508/n]*n)
        if n==3 and tbl[0][0] in ['ID','Axis']:widths=[52,212,244] if tbl[0][0]=='ID' else [108,160,240]
        cells=[[Paragraph(fmt(v),ST['SmallResearch']) for v in row] for row in tbl]
        tb=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
        tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e4edf1')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#91a8b4')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#d7e0e4')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
        story += [tb,Spacer(1,9)];continue
    if l.startswith('# '):story.append(Paragraph(fmt(l[2:]),ST['Heading1']))
    elif l.startswith('## '):
        if re.match(r'## (3\.|14\.)',l):story.append(PageBreak())
        story.append(Paragraph(fmt(l[3:]),ST['Heading2']))
    elif l.startswith('### '):story.append(Paragraph(fmt(l[4:]),ST['Heading3']))
    else:
        block=[l];i+=1
        while i<len(lines) and lines[i].strip() and not lines[i].lstrip().startswith(('#','|','- ')):
            block.append(lines[i].strip());i+=1
        story.append(Paragraph(fmt(' '.join(block)),ST['BodyResearch']));continue
    i+=1

story += [PageBreak(),Paragraph('Illustrated research notes',ST['Heading1']),Paragraph('Source pages are reproduced for comparison. Reproduction size here is not an architectural scale. No contour has been altered or represented as a measured reconstruction.',ST['BodyResearch'])]
p=OUT/'figures/Depth_Angles_and_Junctions.png'
story.append(Image(str(p),width=508,height=356));story.append(Paragraph('Explanatory diagram: arbitrary section dimensions; analytic angle and branch examples are independently checked in Analytic_QA.json.',ST['SmallResearch']))
for p,caption in source_figs:
    story+=[PageBreak(),Paragraph(caption,ST['Heading2'])]
    im=ImageReader(str(p));w,h=im.getSize();scale=min(508/w,610/h);story.append(Image(str(p),width=w*scale,height=h*scale));story.append(Paragraph('Historical source reproduced from the supplied PDF. PDF locator is in the filename; no claim of scale calibration.',ST['SmallResearch']))
for name,caption in [('329','Viollet-le-Duc, Meneau, figure 4 - Amiens section family.'),('331','Viollet-le-Duc, Meneau, figure 5 - construction and normal section.')]:
    p=TMP/f'VLD_{name}.png';dest=OUT/'figures'/p.name;shutil.copy(p,dest)
    story+=[PageBreak(),Paragraph(caption,ST['Heading2']),Paragraph('Low-resolution public-domain web illustration. Suitable for identifying labels and relationships; unsuitable for precise contour measurements.',ST['BodyResearch'])]
    im=ImageReader(str(p));w,h=im.getSize();scale=min(340/w,550/h);story.append(Image(str(p),width=w*scale,height=h*scale))

def page(c,d):
    c.setStrokeColor(colors.HexColor('#9fb4bf'));c.line(43,36,551,36);c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#5b6c76'));c.drawString(43,24,'Cathedral Project | Tracery and mouldings | Research R01');c.drawRightString(551,24,str(d.page))
pdf=OUT/'Gothic_Tracery_and_Mouldings_R01.pdf'
doc=SimpleDocTemplate(str(pdf),pagesize=(595.28,841.89),rightMargin=44,leftMargin=43,topMargin=42,bottomMargin=49,title='Gothic Tracery and Mouldings - Research R01',author='Cathedral Project research')
doc.build(story,onFirstPage=page,onLaterPages=page)
rd=fitz.open(pdf);counts=[];bad=[]
for n,p in enumerate(rd,1):
    txt=p.get_text();counts.append(len(txt))
    for b in p.get_text('blocks'):
        if b[0]<40 or b[2]>555 or b[3]>831:bad.append((n,b[:4]))
check={'report_pages':len(rd),'words_markdown':len((OUT/'Gothic_Tracery_and_Mouldings_R01.md').read_text().split()),'out_of_bounds_text_blocks':bad,'source_pdf_files':len(inventory),'byte_unique_supplied_pdfs':len(groups),'supplied_physical_pages':sum(x['pages'] for x in inventory),'unique_physical_pages':sum(x['pages'] for x in inventory if canonical[x['id']]==x['id']),'no_exhaustive_reading_claim':True,'analytic_tests':len(qa['tests'])}
(OUT/'Report_QA.json').write_text(json.dumps(check,indent=2))
for n in [0,3,9,len(rd)-11,len(rd)-3]:
    if 0<=n<len(rd):rd[n].get_pixmap(matrix=fitz.Matrix(1.15,1.15),alpha=False).save(TMP/f'report_review_{n+1:02}.png')
(OUT/'README.md').write_text('''# Gothic tracery and mouldings - Research R01\n\nRead the PDF or Markdown report first. This is a substantial synthesis with an explicit incomplete-reading audit, not a certificate of cover-to-cover completion.\n\n- Source_Register.csv: all supplied PDFs and recovered Paley scan, with hashes and duplicate handling.\n- Reading_Coverage.csv: each physical page, separating text extraction, prose review and visual survey.\n- Sharpe_Window_Catalogue.md: all sixty extracted descriptive entries; dimensions need visual checking.\n- figures/: explanatory vector diagram and selected unaltered historical source pages.\n- research_data/: extracted text for byte-unique supplied PDFs; OCR is not authoritative.\n- Analytic_QA.json: checks of explanatory mathematics, not cathedral geometry.\n- Report_QA.json: document checks.\n- build_report.py: reproducible report-building script; requires the original supplied PDFs and the retained scratch extraction paths documented in the script. Source downloads and extraction are not fully self-contained in this package.\n\nNo geometry, generators or project locks were changed. Morris Part II public transcription found; complete text and illustrated-typology review remain outstanding.\n''')
shutil.copy(__file__,OUT/'build_report.py')
bundle=OUT.parent/'Gothic_Tracery_and_Mouldings_R01_Package.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(OUT.parent))
print(json.dumps(check));print('Package bytes',bundle.stat().st_size)
