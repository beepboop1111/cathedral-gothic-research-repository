# Gothic tracery and mouldings
## Research report R01 - source review, spatial construction and generator requirements

Prepared for the Cathedral Project, 7 November 2026.

**Research status:** substantial source-based synthesis; the requested exhaustive, cover-to-cover and plate-by-plate reading is **not complete**. All 17 supplied PDFs are inventoried and their text layers extracted. There are eight distinct works or volumes, represented by several scans and editions. Selected text passages and plates have been closely examined. Morris Part II has been located as a publicly displayed third-party transcription in addition to the publisher extract; its figures and complete text have not been fully reviewed. The accompanying page ledger separates extraction, close reading, visual survey and outstanding work. A page with an extracted text layer is not counted as a page read. This report does not certify complete knowledge of every regional tradition or every illustration.

**Project status:** historical research only. Existing U01-U07 results remain reported handoff results, not independently rerun validations. No cathedral geometry, generator, dimension or architectural lock has been changed. No new historical measurement becomes an approved project dimension. Structural capacity has not been established.

## 1. Findings that change the way we should model tracery

The essential object is a shaped stone framework in a deep architectural opening. Its elevation, sectional profiles, depth hierarchy, glazing support and stone assembly are related, but none can be recovered reliably from the elevation alone. The lines of a construction drawing may represent moulding axes rather than visible edges. A shaded engraving can imply a depth order without specifying its dimensions.

Sharpe's chapter on mouldings is exceptionally relevant to the present generator. He distinguishes the window arch, the tracery and the foliation as separately describable systems. In the Howden example each has its own orders; some members serve in more than one descriptive system. Counting every visible ridge as another universally recessed layer would misread the evidence. [B3, printed pp. 38-49; S15 PDF pp. 56-73.]

The important distinction is between **order**, **member**, **axis**, **face** and **stone**. An order is a compositional grouping. A member is a roll, fillet, hollow or other component within a profile. An axis locates the construction. A face is a surface or reference plane. A stone is an assembled physical piece that can contain several members and parts of several curved branches. These are not interchangeable entities.

The source evidence does not support making every secondary bar a uniformly scaled copy of a primary bar. A lesser bar can retain only selected members of a larger profile, start at a different axis, or lie behind it by one retiring member rather than by a whole arch order. The profile can also change at a capital. [B3, pp. 49-56; B9, Decorated section.]

Likewise, an elegant elevation is not evidence of a correct section. Elaborate tracery can have very plain chamfered jambs and bars. Conversely, a simple outline can have rich sectional treatment. The correct research question is not 'how ornate is this window?' but 'which contours belong to which members, at what depth, with what continuation and what joints?' [B2, S03 PDF pp. 65, 73-75; B3, pp. 50-56.]

## 2. Source corpus and reading conventions

The report uses eight supplied book units and three agreed specialist references:

| ID | Work | Role and present access |
| --- | --- | --- |
| B1 | E. A. Freeman, *An Essay on the Origin and Development of Window Tracery in England* (1851) | Broad taxonomy, combinations, subordination; supplied full scans |
| B2 | Raphael and J. Arthur Brandon, *An Analysis of Gothic/Gothick Architecture*, Volume I | Architectural explanation, windows, mouldings, masonry context; four supplied versions |
| B2b | Brandon, *Analysis*, supplied Volume II | Continuation of illustrated material, Perpendicular work, woodwork, metalwork and indexes |
| B3 | Edmund Sharpe, *A Treatise on the Rise and Progress of Decorated Window Tracery in England* (1849) | Most direct supplied discussion of orders, sections, back joints, cusps and rear arches |
| B4 | Sharpe, *Decorated Windows* (1849), plate volume | Sixty numbered window examples, descriptions, dimensions and order counts |
| B5 | R. W. Billings, *Illustrations of Geometric Tracery, from the Paneling belonging to Carlisle Cathedral* (1842) | Actual screen-derived patterns and reconstruction limitations |
| B6 | Billings, *The Infinity of Geometric Design Exemplified* (1849) | Controlled design variation, diagrams, branching and figure-ground changes |
| B7 | Billings, *The Power of Form Applied to Geometric Tracery* (1851) | Numbered constructions, profile axes and primary/secondary expression |
| B8 | Viollet-le-Duc, *Dictionnaire raisonne*, Volume VI, article 'Meneau' | French section derivation and construction; article and figures accessed |
| B9 | F. A. Paley, *A Manual of Gothic Moldings*, edited by W. M. Fawcett | Fifth edition (1891) recovered for examination; linked sixth-edition record is 1902 |
| B10 | Richard K. Morris, 'The development of later Gothic mouldings in England c. 1250-1400 - Part II', *Architectural History* 22 (1979), pp. 1-48 | Specialist comparative reference; publisher extract plus selected public transcription passages |

PDF page numbers below are one-based physical pages in the specified file. Printed page numbers and plate labels are retained separately. A scan can interleave blank versos and plates, so a fixed offset must not be used throughout a book. Different editions are not assumed page-identical.

Exact duplicates: S06/S07/S08; S13/S14; S15/S16. These are retained in the register, with the canonical inspected file identified. S09 is another Freeman scan, not a byte duplicate. S17 is another Sharpe scan. Brandon's four Volume I files are separate editions or reproductions and are not silently merged.

The two large Research ZIP archives contain additional cathedral reference collections. Their contents were inventoried only to locate relevant material; the many additional books inside them are **outside the reading claimed by this report**. They must not be counted as reviewed. Ungewitter, Choisy, Colling and other prior cathedral sources remain useful later extensions.

## 3. Freeman - report on the book

### 3.1 Scope and organisation

Freeman supplies a classification by the behaviour of the design, rather than a catalogue of moulding sections. Chapter I treats Geometrical tracery, including early figures, foil and arch tracery, combinations, subarcuation, wheel centrepieces and straight-line intrusions. Chapter II treats Flowing tracery: Reticulated, Ogee, Flowing Wheel, their combinations, transitions and subordination. Chapter III treats Flamboyant and Perpendicular as continuous forms, including Supermullioned, Alternate and Panelled arrangements. Chapter IV includes circular, triangular, square, flat-headed, belfry and spire windows. Additions and corrections are substantive and must be read alongside the main text. [S06 contents, PDF pp. 19-22.]

### 3.2 What it contributes

His most useful distinction is between an independently legible geometrical figure in a window head and spaces generated by continued or intersecting bars. A circle carried above two arches is a different compositional operation from bars rising through the head to make a network. The same opening shape can arise through different constructions.

Combination occurs in at least two ways: different patterns can be juxtaposed, or a larger skeleton can be filled by smaller patterns. In the second case, the major pattern may be marked by greater bar size, greater projection or an additional moulding member. The smaller patterns can recede in successive planes. This provides historical evidence for explicit depth hierarchy, but not a numerical rule for the amount of recession. [Printed p. 4; S06 PDF p. 26.]

Reticulated tracery is especially important for U07: the containing arch can cut an extended net, leaving incomplete units at the sides. Those incomplete units are not automatically errors. They differ from a purpose-fitted arrangement whose figures deliberately terminate against the arch. A generator should support both attitudes and record which source it follows.

Flowing Wheel subdivisions concern direction as well as shape. Divergent figures move away from a central origin; horizontal convergent figures approach from the sides; reversed convergent arrangements reverse the relationship. These names describe a compositional reading, not merely a list of interchangeable teardrop outlines. [Chapter II, printed pp. 104-115.]

Freeman's Perpendicular subdivisions are particularly useful for procedural grammar. In Supermullioned work, bars rise from mullions and light crowns. In Alternate work they rise from the crowns; in Panelled work they continue from the mullions. Transoms, subarches and mixtures complicate these types. The apparent identity of small openings does not mean that their supporting grammar is identical. [Chapter III, especially pp. 173-199.]

### 3.3 Limits and critical reading

Freeman repeatedly judges designs as beautiful, corrupt, meagre or inferior. Those are nineteenth-century aesthetic positions, not geometric failure criteria. His restrictions on 'decorative construction' should be stored as author-specific checks with exceptions, not universal structural laws.

Some similar outlines do not have actual subordination of mouldings. A visible skeleton inferred from pattern must therefore be distinguished from a measured change in projection. The additions also qualify an inside/outside-centre distinction between Geometrical and Flowing curves. That distinction is a useful interpretive observation, not a substitute for recovering the actual arcs.

**Book-specific next requirement:** complete the chapter-by-chapter reading and inspect every illustrated example, including additions and errata. No claim is made that all approximately four hundred illustrations have been individually analysed.

## 4. Brandon Volume I - report on the book

### 4.1 Scope

The supplied versions combine a masonry discussion with illustrated examples and a second section on woodwork and metalwork. Windows, mouldings, doorways, piers, arches and other features appear within a wider architectural account. The versions are not merely four independent authorities: they represent the same work through different editions, scans and a later reproduction.

### 4.2 Tracery and depth

The window discussion follows the development from individual openings to combined lights and then more integrated tracery. The authors explicitly recognise that very similar elevations may need to be distinguished through mouldings and cusping. This is direct support for classifying the window's plan, cusp construction and profile independently from its elevation. [S03 PDF pp. 25-44, particularly 36-38.]

Their account of net tracery notes the visual effect of a repeated pattern cut to the containing arch. Unlike a modern defect detector, they discuss this as a design characteristic and sometimes criticise its aesthetic consequences. We should preserve that distinction between intentional clipping, technical breakage and an author's taste.

The moulding chapter separates wall, soffit and chamfer planes and discusses how moulding practice changes between architectural periods. The underlying rectangular block and its worked edges matter: the section is a shaped piece of masonry, not a bundle of attached decorative cylinders. They describe pointed bowtels, filleted rolls, wave mouldings, ogees, scroll mouldings and sunk chamfers. [Printed pp. 48-61; S03 PDF pp. 62-75.]

A particularly valuable passage describes mixed jamb treatment: some members continue through the arch while another group is carried by a shaft and capital. The window or doorway need not have one global 'continuous' or 'capital-stopped' setting. Continuation belongs to individual groups or members.

The authors also note that rich window tracery can have simple chamfered jambs and mullions. A profile-selection interface should therefore allow an historically plain section without treating that choice as an unfinished state.

### 4.3 Other parts of the book

Capitals, bases, strings, hoodmoulds and cornices explain how profiles meet other architectural elements. Doorways and pier arches provide useful comparisons for continuous versus interrupted mouldings, but their dimensions and exposure conditions cannot be transferred directly to a slender glazed window. Roofs and woodwork supply comparable compositional devices, not automatic evidence for stone assembly.

The account's claims about architectural origins and later 'debasement' require critical treatment. A proposed evolutionary sequence is not proof that a particular moulding was generated by that sequence in the medieval workshop.

### 4.4 Edition handling

S03 is the 1847 scan used for most locators in this report. S01's title page shows 1849; S04 shows 1858; S02 is a reproduction of a 1903 edition. Page counts differ substantially. The separate file register retains all four and prevents a plate reference being transferred to the wrong scan. A complete comparison of edition additions and omissions is outstanding.

## 5. Brandon Volume II - separate report

The supplied S05 volume is predominantly illustrated material, continuing Perpendicular examples and including appendix plates, woodwork, metalwork and indexes. Its sparse OCR does not mean it contains little information. The visual survey confirms paired elevations and sections: the chancel window at Holy Trinity, Sarum, for example, is accompanied by a mullion section and a jamb section; a Cobham sedilia plate includes plans, section cuts and a sill profile. [S05 PDF pp. 25, 37.]

The volume also shows highly elaborate pierced woodwork and metalwork. These examples widen the vocabulary of branching, cusping and frame subdivisions, but material attribution is essential. A metal screen can make slender forms and connections that should not be copied into stone at the same dimensions. A carved timber screen likewise does not supply a masonry joint schedule.

The indexes at the end can connect a building name to multiple features and plates across the work. They are useful finding aids, not evidence that the indexed drawings have all been inspected. Rotated and foldout plates need independent orientation and scale checks.

**Book-specific next requirement:** leaf-by-leaf illustrated catalogue, separating windows, other masonry, woodwork and metalwork, and recording every printed scale. Selected plates were surveyed; the complete review remains outstanding.

## 6. Sharpe's Treatise - report on the book

### 6.1 Organisation and terminology

Part I treats classification, origins, definition, the window arch, scoinson arch, rear vault, foliation and mouldings. Part II describes the Geometrical and Curvilinear periods. The text's dates and its proposed nomenclature belong to Sharpe's historical scheme; they should not be treated as fixed European date boundaries.

His definition of tracery requires the head to be pierced through to the glass plane, rather than merely decorated by recessed shapes on one face. This is a very useful test for distinguishing surface treatment from an actual glazed opening, although modern terminology can use 'plate tracery' more broadly than his definition allows. [Printed pp. 21-24; S15 PDF pp. 39-42.]

### 6.2 A complete opening has more than one arch

The window arch frames the tracery. In a thick wall there may also be a scoinson arch or rear arch supporting and finishing the interior face, with a rear-vaulted space between the two. The internal opening can therefore differ in outline and springing treatment from the exterior frame. Sharpe discusses deep splays, plain and ornamented rear vaults, and rear ribs dying into jambs. [Printed pp. 25-31; S15 PDF pp. 43-49.]

For modelling, this means that 'extrude the elevation by wall thickness' is insufficient. The front arch, glass location, rear arch and connecting surface each need a definition. The rear surface may be a vault-like transition rather than a constant-depth arch extrusion. Its form must be measured from the relevant section, not improvised as a generic funnel.

### 6.3 Foliation is three-dimensional

A soffit cusp can be a separate, comparatively flat stone element near the glass. Some were inserted in grooves in circles. Sharpe explains how missing inserted cusps and filled grooves can make an originally foliated circle appear plain. Thus a surviving uncusped opening is not always proof of an uncusped original design. [Printed pp. 32-37; S15 PDF pp. 50-55.]

A chamfer cusp is associated with the continuation of a chamfer or hollow of the bar. Its edge may lie slightly behind an adjoining fillet, its back can be convex, and the small foliating space may be blind, sunk or pierced. These distinctions require sections, not just a trefoil drawn in elevation.

Double foliation is not simply adding another coplanar outline. Two orders may appear in different parts of a window, or one foliated figure may itself be foliated. The descriptive hierarchy and actual depth arrangement must both be recorded. [Printed pp. 46-49.]

### 6.4 Orders and subordination

Sharpe separates the orders of the arch, tracery and foliation. His Howden example has two orders in each system, with one foliation order corresponding to a tracery order. His observed English series generally has one or two arch orders, one or two tracery orders with a few three-order examples, and usually one foliation order. He expressly admits anomalies and exceptions. Netley provides an unusual deeper arch arrangement. These observations are not universal numerical limits for all Gothic windows. [Printed pp. 38-49; S15 PDF pp. 56-73.]

The source's statement that the tracery is a panel set within the framing arch must also be read carefully. It distinguishes the tracery from the wall-bearing frame. It does not establish that the stone network has no structural work: the network must still sustain itself and interact with glazing, wind, supports, joints and restraints. No generator should translate the historical phrase 'only their own weight' into a modern load model that omits wind or glass.

### 6.5 Back joints constrain profiles

Sharpe describes small subsidiary hollows and enlarged fillets that provide adequate stone behind a moulding where it meets the enclosing arch. At some joints two plain surfaces meet at right angles; elsewhere joints occur in hollows at a specified tangent orientation. These are examples of geometry designed around workable stone contacts, rather than cuts added after decorative surfaces are finished. [Printed pp. 43-44; S15 PDF pp. 67-68.]

Consequently, a junction cannot be validated solely by checking that visible moulding surfaces touch. It needs enough solid material for the intended joint, a plausible contact surface, and no hidden tapered sliver. The additional hollow can have an assembly purpose as well as a visual one.

### 6.6 Profile categories and face differences

Sharpe distinguishes fillet, roll and edge tracery by the leading surface treatment. He documents differing inside and outside profiles in some Geometrical examples, including circular centrepieces. He also compares mullion and tracery sections above capitals. Some retain the same section; others change. [Printed pp. 49-56; S15 PDF pp. 73-80.]

The three large comparison plates C, D and E are crucial. However, Sharpe explicitly says their scales differ for arrangement and comparison, rather than providing accurate detailed measurements. The plates can support identification and relative relationships; dimensions require an independently established scale for each item. [Printed p. 42; S15 PDF p. 60.]

**Reading status:** the spatial, foliation and moulding chapters are the most closely read part of this corpus. The full historical narrative in Part II and every woodcut have not yet been individually reviewed.

## 7. Sharpe's Decorated Windows - report on the plate book

This is a separate source from the Treatise. It supplies sixty numbered examples with descriptive pages, elevations, dimensions and often order counts. It is therefore a bridge between abstract rules and particular windows. The accompanying catalogue preserves each description in extraction order, rather than dropping examples that are not immediately useful to U07.

Raunds is a useful warning against assuming that every large geometrical head must be cusped. The book describes its apparent absence of cusps, but the Treatise also discusses lost inserted cusps at Raunds. The two passages should be read together as evidence about condition and reconstruction. A source's own cross-references can change the interpretation of its plate. [B4 S10 PDF p. 42; B3 printed p. 36.]

Lincoln and Carlisle are important complex examples. Their descriptions identify three orders; the Treatise supplies an explanation of how the orders organise Carlisle's major frame, subordinate openings and foliation. Neither order count alone nor the engraved elevation gives the depth in millimetres of each member. [B4 S10 PDF pp. 50, 154; B3 printed pp. 45-46.]

The book includes surviving, altered and reconstructed examples. Guisborough is described as restored in the drawing from surviving data; such an image is not a direct survey of wholly intact tracery. The report must distinguish measured remains, the author's restoration, later restoration and our own interpretation.

The dimensions printed with elevations can anchor scale, but OCR is unreliable for feet and inches. In Raunds the total width is visually legible as 16 ft 3 in, equivalent to 4.953 m using the exact modern conversion. This is an illustration of unit conversion, not a newly approved project span. Other damaged or unclear values have not been guessed.

**Book-specific next requirement:** visually verify every dimension and plate scale, compare elevations with Treatise profiles, record interior versus exterior face, and assign each of the sixty cases a measured/engraved/restored/uncertain status. The appended catalogue is an extraction aid, not certification that all sixty designs have been reconstructed.

## 8. Billings - Carlisle panel tracery

This short work is unusually valuable because its descriptive text addresses both construction geometry and survival of the objects. The panels were dispersed, damaged and reused; some originals had been removed from their screens. Billings gives a geometric explanation for plates II-XX, including square subdivisions, equilateral triangles, circles and repeated curves. [S11 PDF pp. 5-10.]

The major shared groundwork is frequently a square divided into sixteen squares, but not every example is simply that grid. Some use a parallelogram associated with equilateral triangles. The source therefore supports a reusable construction framework with individual exceptions, rather than one universal square template imposed on every pattern.

Billings notes that the principal curves are geometrically accurate, whereas small foils appear hand-worked. This is important for reconstruction: exact compass circles may be a good model for the main frame while a smaller carved detail may require a measured curve or an uncertainty allowance. Neither an ideal circle nor a spline should be imposed before examining the evidence.

His scale statement is explicit: the examples are drawn at half size except IX and X, which are full size. Digitisation may resize them, so the statement alone is not enough to recover pixels per millimetre. The plate must retain its printed dimensions or an independently verifiable reference.

The author also warns that plate XX cannot be depended on for originality. This is precisely the type of uncertainty that must survive in a reusable profile library. The final report should not present that reconstructed pattern with the same confidence as intact evidence.

**Coverage:** the short descriptive text and plate-by-plate explanations have been read. Individual plate geometries have not all been traced or dimensionally validated. The material and original screen context must be retained before adapting these small patterns to large exterior stone windows.

## 9. Billings - The Infinity of Geometric Design

The book's programme is more extensive than 'many pretty tracery patterns'. The advertisement identifies five investigations: variation of a fixed diagram, new designs on older diagrams, rearrangement of parts, variation through colour, and changed expression without changing the original framework. Its forty plates organise those investigations. [S12 PDF pp. 13, 15.]

The first twenty plates present one hundred designs on a common arrangement of four disconnected circles. Later plates change the circle system, frame shape, branching, ogee enclosure and relations between parts. Plates 26-27 and 35 are especially relevant to figure-ground and colour changes; plates 38-39 to separation and recombination. [List of engravings.]

For procedural development, this supports testing several distinct operations: changing a layout, changing the selected edges of a fixed construction graph, changing the depth assigned to existing members, and changing the visual treatment without changing the geometry. They should not be conflated into a single 'variation' parameter.

This is a design experiment, not a survey proving that every published panel was executed in medieval masonry. Billings' general claims about geometric origins and hidden workshop knowledge should remain attributed interpretations. A successful geometrical construction does not prove historical use, structural adequacy or suitability at a new scale.

**Book-specific next requirement:** full reading of the essay and individual review of the forty plates. The programme, plate list and selected essay passages have been examined; the full atlas is not yet an audited set of reconstructions.

## 10. Billings - The Power of Form

The repeated foundation here is based on three touching circles with triangular and hexagonal relationships. Billings provides the diagram opposite the finished design, numbering curves and lines in their order of formation. This is an especially suitable model for a reproducible construction log. [S13 PDF pp. 17-23, 27.]

The most directly relevant passage is on printed pp. 15-16. The construction line is described as a primary central line on which moulding expression is placed. Alternative sections can share the diagram while producing different light and shade. The more prominent part can continue as the main frame while lower portions subdivide into minor detail. [S13 PDF pp. 19-20; visually inspected.]

This means that a centreline graph is not itself a stone outline. It requires a section, depth assignment, selected continuations and a rule for how subordinate members enter or leave the principal frame. An intersection of graph edges is likewise not enough to determine the solid at a branch.

The author acknowledges that variations are not equally successful. The design experiment demonstrates possibility, not equal architectural value. His analogies to natural and symbolic forms should not be treated as numerical evidence for masonry construction.

**Book-specific next requirement:** audit all one hundred numbered designs and diagram pairs. Selected pairs and the key profile explanation have been visually checked; the remaining pairs need explicit review. S14 is an exact duplicate and adds no independent evidence.

## 11. Viollet-le-Duc - 'Meneau'

This article links French window layouts to sections and stone assembly. In Amiens figure 4, DEF generates the principal mullion, GEH a secondary section, KEL lower cusps, DEM the cut at ed, and DMD a specified simplified profile. Central-eye cusps remain an exception, fitted in a rebate. Figure 5 connects normal sections and retained moulding thickness with a geometric layout. The illustrations have been inspected, but the web images are too small for precision tracing. [B8, figs. 4-5.]

Later examples discuss displaced axes for subordinate members, metal restraints and load-related interpretations. These are the author's historical explanations, not structural verification of our models. His article supports studying a related section family, including exceptions, rather than assuming one uniformly scaled profile everywhere. It also documents later single-section practice. The article covers Paris, Reims, Amiens, Troyes, Carcassonne and later work; neither one example nor one phase is a universal French rule.

**Outstanding:** high-resolution original pages, scale verification and measured contours. The agreed scope is the article, not a claim to have read all of Volume VI.

## 12. Paley/Fawcett - report on the manual

The recovered fifth edition (1891) differs from the linked sixth-edition record (1902). Its twelve sections cover introduction, formation, copying, early mouldings, Early English, Decorated, Perpendicular, columns, capitals, bases, hoodmoulds/strings and conclusion, followed by plate descriptions. Relevant formation, copying and Decorated passages were examined; the entire manual and all plates remain to be read.

The practical method starts with wall, soffit and chamfer planes, then records profile dimensions. It warns against assuming a 45-degree chamfer and against inferring exact curves solely by eye. The Decorated discussion distinguishes a retiring member from an entire order, and warns that jamb and mullion inclinations can differ. Sections above capitals can change. These observations directly affect a profile library. [B9, fifth edition PDF pp. 27-45, 62-75.]

The editor also acknowledges uncertainty in identifying some examples. Plate descriptions and edition-specific locations must therefore accompany any extracted profile. Doorways, ribs and capitals must not be relabelled as window-mullion evidence.

## 13. Morris Part II - report and access limits

Richard K. Morris, *Architectural History* 22 (1979), pp. 1-48, DOI 10.2307/1568368. The publisher's 2016 date concerns online publication. A public third-party transcription was found after the initial publisher-extract review; its OCR needs checking against the original figures.

The article covers mullions, ribs, capitals and bases, followed by a synthesis and index. Its mullion discussion distinguishes a roll-and-chamfer family from paired chamfer/hollow-chamfer designs. The first includes axial rolls, filleted versions and elaborated principal mullions; the second stresses duplicated chamfer forms along the diagonal plane. Their regional distributions differ. This is useful evidence against selecting profiles by a single national period label.

The publisher extract warns about restored mullions, and note 119 recommends comparing the corresponding half-profile on the surround. Part I contains complementary types.

**Not completed:** reading every article passage, inspecting the full illustrated typology and checking OCR dates, scales and profile details. Selected accessible prose is reviewed; the entire article is not certified as read. No complete copyrighted article is redistributed in the package.

## 14. A taxonomy that can accommodate all the evidence

No single flat list can describe all Gothic tracery. The same object can be bar tracery, Geometrical in pattern, doubly foliated, circular in frame and used as a screen. The classifications below are independent axes. The table includes families discussed in the corpus and further research categories whose detailed historical treatment remains open.

| Axis | Categories | Meaning |
| --- | --- | --- |
| Fabric and void | Plate; bar; mixed or transitional | Pierced plate versus articulated bars and associated solid fields |
| Basic design grammar | Geometrical; foil; arch; intersecting | Independent figures, foils, continued light-head arches and intersections |
| Flowing grammar | Reticulated; ogee; divergent; convergent; mixed | Repeated nets, reversed curvature and directional composition |
| Continuous grammar | Flamboyant; Perpendicular | Flowing or vertical continuity across the head |
| Perpendicular subdivision | Supermullioned; Alternate; Panelled; mixtures | Origin and continuation of vertical bars |
| Grouping | Subarcuated; complementary-light; wheel-centrepiece; hierarchical infill | How a large design contains smaller systems |
| Foil treatment | Uncusped; soffit cusp; chamfer cusp; split cusp; double foliation | Distinct sectional and carving operations |
| Frame | Pointed; ogee; segmental; depressed/four-centred; round; triangular; square | Boundary condition, not automatically the tracery family |
| Architectural use | Glazed window; blind panel; screen; parapet; hanging/drop work | Different assembly, exposure and support conditions |
| Surface/profile | Fillet; roll; edge; chamfer; wave; composite | Shape and expression of the section |
| Section hierarchy | Uniform; derived primary-secondary-tertiary; mixed | Which profile members continue and which recede |
| Evidence | Surveyed; engraved; restored; inferred; proposed | Confidence and provenance, independent of beauty |

### 14.1 Pattern families and modelling questions

| Family or device | Construction to understand | Particular risk |
| --- | --- | --- |
| Plate tracery | Openings through a retained stone field | Mistaking shallow relief for a through-opening |
| Early two-light/circle | Two light-heads and an independent upper figure | Confusing construction axes with opening edges |
| Multiple-circle heads | Tangent or near-tangent circles within a containing arch | Incorrect spacing once real bar widths are included |
| Spherical triangle/square | Curvilinear figures made of arcs | Treating 'spherical' as a non-planar surface requirement |
| Foil tracery | Foil outline acting as a principal figure | Confusing a foil-shaped figure with an inserted cusp |
| Y/arch tracery | Branching or continuing arches from the lights | Forcing an independent circle grammar onto it |
| Intersecting tracery | Repeated arch families crossing in the head | Assuming each crossing is a stone joint or an overpass |
| Subarcuated designs | Smaller windows grouped beneath major arches | Losing hierarchy when profiles are flattened |
| Complementary-light designs | Extra central or residual light within a grouped system | Narrow fork material and awkward crown meetings |
| Wheel/rose | Radial or rotational composition, often with a central figure | Assuming every radial boundary has the same section |
| Reticulated | Repeating net clipped by the frame | Deleting intentional partial edge units |
| Intersecting ogees | Reversal of curvature within arch systems | Kinks, reversed normals and offset collapse |
| Flowing Wheel | Diverging/converging curved figures | Losing direction by using interchangeable motif stamps |
| Flamboyant | Interwoven flame-like figures and counter-curves | Applying English moulding details without source support |
| Dagger/mouchette/soufflet | Individual motifs within larger arrangements | Treating variable regional names as exact universal geometry |
| Loop tracery | Loop-dominated arrangements, sometimes uncusped | Adding cusps automatically because the design is Gothic |
| Supermullioned | Bars from mullions and light crowns | Wrong upper-light spacing or unnecessary geometric figures |
| Alternate | Bars from crowns, staggered relative to lower mullions | Accidentally generating Supermullioned topology |
| Panelled/rectilinear | Vertical continuation and transomed panels | Confusing a surface panel with a glazed window |
| Kentish split-cusp | V-like split cusp arrangements | A plan-only motif fails to explain depth and attachment |
| Blind tracery | Relief retained against a backing wall | Generating through-holes or unsupported rear surfaces |
| Drop tracery | Pendant/openwork below an arch | Assuming support conditions of standing mullions |
| Non-pointed frames | Circular, triangular, square and segmental enclosures | Calling every clipped pattern a purpose-fitted design |
| Hybrid/transition | Mixed grammars in one composition | Treating classification ambiguity as failed geometry |

The vocabulary above is a working research map. Detailed loop, regional Flamboyant, Iberian, German and other continental traditions need additional specialist sources before an 'all types' historical claim is justified. A generic motif inventory is not a complete account of those traditions.

## 15. Depth: the parameters that an elevation cannot supply

Use an explicit coordinate convention. Let x be horizontal across the window, z vertical and y inward through the wall. Let the glass reference plane be y = 0. This is a modelling convention, not a claim that medieval masons used these coordinates.

| Quantity | What must be recorded | Do not confuse it with |
| --- | --- | --- |
| Wall depth | Exterior and interior wall faces | Full thickness of every bar |
| Tracery body depth | Actual fore-aft stone extent | Face width seen in elevation |
| Projection/recession | Location of leading fillets or rolls | Overall thickness alone |
| Order membership | Primary/secondary/tertiary grouping | Number of decorative grooves |
| Member-axis offset | Difference between construction axes | Uniform scaling |
| Glass position | Pane datum and support line | Geometric centre of wall or bar |
| Glazing rebate | Step, bearing, groove and access | A decorative hollow |
| Cusp depth | Body, front edge, back and attachment | Foil outline alone |
| Jamb splay | Varying width through wall depth | Chamfer in a moulding section |
| Rear arch/vault | Interior support and transition | Back face of a straight extrusion |

An earlier layout may place glazing near the exterior with a large interior splay. Another can have a more central position and more similar faces. These are source-specific arrangements; the source observations must not become a universal rule that every Geometrical window is asymmetric or every later window perfectly symmetric.

Depth can also vary within a profile system without stacking separate slabs. A smaller member can be contained in the depth of a larger section, sharing part of its outline. To visualise this properly we need normal sections, a horizontal jamb/mullion plan and at least one oblique view. A frontal render cannot establish the depth relationship.

## 16. Angles and profiles

### 16.1 Distinguish the angles

Four angles commonly get conflated: the opening's jamb splay through wall depth; the chamfer angle within a normal moulding section; the meeting angle of two paths in elevation; and the orientation of a stone joint. A fifth issue, the rotation of a section around its own path, is a sweep-frame choice. None can safely be inferred from one of the others.

For a straight chamfer in local section coordinates (u across the path, v through depth), its inclination relative to the u direction is atan2(delta-v, delta-u). For equal absolute offsets it is 45 degrees; for unequal offsets it is not. A jamb splay described relative to the depth direction uses a different reference and should be labelled separately.

### 16.2 Section vocabulary

| Element | Section behaviour | What to measure |
| --- | --- | --- |
| Plain chamfer | Straight cut replacing an arris | Two offsets and actual angle |
| Hollow chamfer | Concave cut within/near a chamfer envelope | Depth, ends, radius or measured curve |
| Sunk chamfer | Recessed flat or shallow treatment behind retained edges | Recession and edge widths |
| Roll/bowtel | Convex rounded member | Centre, radius, extent and attachment |
| Pointed/filleted roll | Roll retaining an arris or flat leading surface | Nose/fillet width and adjacent curvature |
| Ogee | Joined convex and concave curvature | Arc centres, radii, inflection and tangent agreement |
| Double ogee | Paired compound curvature | Relative member sizes; symmetry only if supported |
| Wave moulding | Undulating chamfer-related profile | Central projection, hollows and reference envelope |
| Scroll form | Asymmetric rolled/filleted expression | Orientation and context of use |
| Deep hollow/undercut | Re-entrant surface and narrow throat | Actual throat, lip, residual stone and access |
| Fillet | Narrow plane dividing or leading members | Width, plane and termination |
| Rebate/groove | Step or channel for assembly/glazing | Bearing, clearance and remaining stone |

This is descriptive vocabulary. A measured outline may not be an exact circle, and tangency must be tested rather than assumed. Conversely, a noisy scan should not lead us to replace an intended circle by an arbitrary spline. Report both the measured trace and a proposed ideal construction with residuals.

### 16.3 Undercuts and light

Two sections can have the same overall width and depth yet produce very different shadows. A hollow can retreat behind a lip; a narrow fillet can catch light between deep recesses; an angled flank can widen towards the rear. These features explain why flat extrusions and generic bevels often look wrong even when their elevation matches.

Undercutting also creates thin lips and sheltered surfaces. It requires a record of minimum material, tool approach and exposure. The fact that a computer can close a mesh does not establish that the resulting stone can be carved, transported or survive.

## 17. Sweeps, intersections and advanced masonry shapes

The following mathematics is an original modelling framework proposed for the project. It is not presented as a quotation from a medieval or nineteenth-century construction manual.

For an elevation path r(s), parameterised by arc length, use the unit tangent t(s), a unit normal n(s) in the elevation plane, and a fixed unit depth direction b. A section point (u,v) produces X(s,u,v) = r(s) + u*n(s) + v*b. For planar tracery this keeps the wall-depth direction fixed while the section turns with the curve. Do not use a global 'up' direction that becomes singular at vertical tangents.

For a constant offset u along an arc with signed curvature kappa, the longitudinal scale factor is 1 - u*kappa under the chosen normal convention. It vanishes at the local curvature centre. This identifies a local offset singularity; it is not a complete test for collisions elsewhere in the window. On a circle the offset radii are R plus or minus u. Both local and global checks are needed.

At an ogee reversal, the section normal should vary continuously when the path is tangent-continuous. Curvature may change sign or jump between circular pieces without a tangent kink. The orientation system must distinguish this from an actual discontinuity. Do not force artificial rounding of an intentionally sharp cusp.

### 17.1 Junction types that must be separate operations

| Situation | Plausible geometric operation | Necessary evidence/check |
| --- | --- | --- |
| Two equal bars meet | Symmetric merge or mitre-like boundary | Actual section and stone cut |
| Secondary enters primary | Subordinate members disappear into or merge with a larger profile | Continuation of each fillet/roll and residual body |
| Two curves touch | Tangent meeting of moulding envelopes | G1 agreement where intended; no pinched neck |
| Network crossing | Shared junction, interruption or special node | Depth evidence; never assume an over/under weave |
| Bar meets frame | Designed penetration or abutment with a back joint | Sufficient backing stone and contact surface |
| Integral cusp | Cusp carved within a larger stone | Neck width, depth and adjoining hollow |
| Inserted cusp | Separate piece fitted in groove/rebate | Groove, bearing, assembly and condition evidence |
| Capital transition | Stopped or changed section | Corresponding above/below-capital cuts |
| Blind work | Relief with retained backing | Backing depth and true open/closed spaces |
| Drop work | Pendant branches connected to overhead work | Support path, stone subdivision and restraint |

Boolean union can help form an experimental solid but it does not decide which moulding members should continue. It can also leave tiny wedges, hidden cavities or impossible joints. Branch design should be inspected with a series of normal and horizontal cuts, not just a shaded exterior.

### 17.2 Why acute forks are demanding

In a simplified equal-width offset construction, the intersection of two offset boundaries at an included angle beta lies at distance d = w/sin(beta/2) from the corner along its bisector, where w is the perpendicular offset from each centreline. As beta gets small, the intersection moves far from the node. This is an analytical warning about long wedges, not a prescribed historical joint rule.

For beta = 90 degrees, d/w = 1.4142; at 60 degrees it is 2.0000; at 30 degrees it is 3.8637. A joint splitter that chooses a midpoint without understanding this geometry can create a long, thin stone tongue despite passing a maximum-length check.

Possible source-led responses include changing the member termination, deriving a different subordinate section, forming a junction within one stone, moving a joint, or retaining more body behind the visible moulding. None should be silently applied as an architectural alteration to an approved layout.

### 17.3 Joints are not decorations

Separate the visible seam from the complete cutting surface. A radial seam in elevation does not establish the three-dimensional bed, and an arc midpoint is not necessarily a good stone cut. Check the joint through all profile depths; an acceptable front line can end inside another bar or create an acute back edge.

Record whether a stone contains a single arc, a fork, a cusp, a shared node or part of the frame. Assess size, volume, slender branches, minimum neck, concavity, lifting/handling assumptions and template count. A 2.50 m limit is an existing project QA parameter, not a universal historical maximum.

Metal bars, dowels, lead bedding and glazing attachments must remain separate evidence records. Historical explanations of their function are not modern structural certification. Material, corrosion, stone bedding, load, wind and support conditions all matter to capacity.

## 18. Research data to retain for each selected profile

| Record group | Required fields |
| --- | --- |
| Provenance | Author, title, edition, year, printed page/plate, PDF page, building and location |
| Evidence | Original or restoration; measured/engraved/inferred; uncertainty; image resolution |
| Scale | Printed dimensions, graphical scale, digitisation check and unit conversion |
| Orientation | Exterior/interior, glass datum, up, path tangent and section-normal directions |
| Envelope | Face width, body depth, stock/block limits and asymmetry |
| Members | Ordered rolls, hollows, fillets, chamfers, undercuts and grooves |
| Curves | Centres, radii, endpoints, arc directions, tangent checks and fit residuals |
| Hierarchy | Parent profile, derived members, member axes and projection changes |
| Continuity | Members continuing, stopping, changing or penetrating at every junction |
| Glazing | Glass plane, rebates, grooves, bars and fittings actually evidenced |
| Assembly | Stone IDs, cuts, back joints, integral versus inserted cusp and contact faces |
| Status | Historical, experimental, geometrically validated, architecturally reviewed, approved or locked |

Unknown values stay unknown. If a section is normalised for comparison, label it dimensionless; do not export it as 1:1 architectural geometry until the scale is established. A visually convincing reconstruction can remain historically uncertain.

## 19. Validation requirements for the next modelling phase

The research supports a layered validation process. Technical validity means files open and meshes are well formed. Geometric validity means the intended arcs, sections, intersections and dimensions agree. Architectural validity concerns profile hierarchy, jamb relationships, passages for glazing and plausible assembly. Historical validity means the claim is supported by the cited evidence. Structural validity needs its own material, load, restraint and capacity model. Passing one layer does not pass the others.

Suggested numerical checks include endpoint separation, radius fit residual, tangent-angle error, width and depth deviations, offset singularity margin, minimum neck and lip dimensions, face-to-face joint completion, collision/clearance and unit consistency. Tolerances must be selected from source quality and project requirements. Do not declare zero error from a low-resolution engraving merely because a parametric curve is internally exact.

Regression fixtures should retain existing approved geometry and compare only the changed component. The U07 handoff's claim of ten passing windows is not independently reproduced in this research. The inconsistent Reims survey summaries also remain unresolved. Neither issue is repaired by reading more architectural literature.

## 20. What the next source studies should demonstrate

1. **Amiens figure 4:** map the generating section and derivatives, retaining exceptional inserted cusps. Obtain a high-resolution page before measuring. This is a source study, not approval of a profile for the cathedral.
2. **Howden west window:** compare Sharpe's section hierarchy with its elevation; identify which foliation member is also a tracery member and inspect the frame back joint.
3. **Heckington or Boston:** compare mullion, jamb and tracery sections and the small difference of inclination described in the moulding literature.
4. **Carlisle east window:** trace the three-order hierarchy and stone-junction problems of an advanced Flowing design. Keep its possible phases and restoration history visible.
5. **An inserted-cusp example:** compare a near-glass separate cusp with a chamfer-derived cusp; include section, groove and assembly evidence.
6. **Perpendicular example in Brandon II:** relate a depression of the head arch and panel divisions to a genuine mullion/jamb section.
7. **Billings controlled variant:** hold construction axes constant while changing a selected section, then compare shadows and actual depth without changing the layout.

These are complementary investigations. They should not become a requirement that every profile be compatible with every layout. The user chooses the profiles; research establishes their documented behaviour and the limits of adaptation.

## 21. Completion audit and remaining work

This report answers the spatial questions in considerable depth, but it does not fulfil the literal instruction to read every page and every illustration without omission. The attached source register and page ledger make that limitation reviewable instead of concealing it behind the word 'comprehensive'.

| Work remaining | Why it matters |
| --- | --- |
| Close-read all unreviewed text pages | Extraction and snippets do not establish full comprehension |
| Inspect each plate individually at sufficient resolution | Contact sheets cannot reveal all undercuts, labels and joints |
| Resolve Brandon edition differences | Later additions and scan omissions can alter locators |
| Verify every printed dimension in Sharpe's plate volume | OCR confuses feet, inches, fractions and digits |
| Obtain a reliable illustrated Morris Part II copy | Public transcription found; full text review and figure inspection remain incomplete |
| Recover higher-resolution VLD sections | Current web figures cannot support accurate contours |
| Expand regional continental sources | English/French evidence does not exhaust Gothic tracery |
| Make measured profile and junction studies | Theory alone does not demonstrate geometric reconstruction |
| Establish separate structural analysis | Historical discussion and closed solids are insufficient |

No geometry was regenerated, no GitHub operation was performed, and no model was opened in Blender or Exhibit as part of this report. Accordingly no new model validation is claimed.

## 22. External references and access record

These URLs are source access points, not proof that every page has been read:

- Viollet-le-Duc, Volume VI: https://www.gutenberg.org/cache/epub/30786/pg30786-images.html - 'Meneau', figs. 1-12; figs. 4 and 5 visually inspected.
- Paley, sixth-edition catalogue/preview record: https://books.google.com/books?id=VE0AAAAAYAAJ - 1902 record.
- Paley/Fawcett, recovered fifth edition: https://archive.org/details/gri_33125006556563 - 1891 scan, 204 PDF pages.
- Morris, Part II: https://doi.org/10.2307/1568368 - original publication 1979; publisher extract and references accessed. Public transcription: https://www.scribd.com/document/369903061/1568368 - selected passages reviewed, OCR unverified.
- Morris, Part I: https://www.cambridge.org/core/journals/architectural-history/article/abs/development-of-later-gothic-mouldings-in-england-c-12501400-part-i/719AC8E4376E106FCA26501DB0346C07 - complementary lead; not read in full.
- Canterbury Historical and Archaeological Society tracery index: https://www.canterbury-archaeology.org.uk/tracery-index - visual and terminology aid, not a measured section manual.

The individual supplied-file names, byte hashes, page counts and duplicate relationships are in Source_Register.csv. Reading_Coverage.csv lists every page in those files and the recovered Paley scan. Sharpe_Window_Catalogue.md preserves the sixty descriptive entries for further checking. Diagrams in this report are explanatory constructions with declared assumptions; they are not traced historical profiles.
