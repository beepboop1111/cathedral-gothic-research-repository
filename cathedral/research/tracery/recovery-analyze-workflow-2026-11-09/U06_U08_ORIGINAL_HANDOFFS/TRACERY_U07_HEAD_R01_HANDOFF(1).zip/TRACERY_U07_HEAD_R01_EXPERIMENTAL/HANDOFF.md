# U07 head R01 — isolated contour study

**EXPERIMENTAL. This is a local junction-contour candidate, not a completed architectural window.**
Parent is the U06 two-light sexfoil window, identified by SHA-256 in `BASELINE.json`.
The U06 engines are copied byte-for-byte and remain unchanged. This wrapper affects only
this one window. Other windows, approved cathedral geometry, historical scans and generators
were not edited. No GitHub operations were performed.

## Actual change

The old `fork_fill=25` procedure shrank and regrew opening polygons with mitred joins.
It replaced the tips of four unseeded spandrel openings with short straight closures.
U07 disables that cleanup for its isolated candidate, recovers the exact intersections of the
existing compass circles, and introduces eleven local tangent-circle transitions.

These rounded closures are a **trial design decision**, not an assertion of historical intent.
Their SVG paths are in the red dashed uncertain layer. Primary specified arc portions are
black; construction circles/centres are gray dashed. Intentional pointed arch crowns and
foil cusps are protected and retain their original geometry.

The inherited 25 mm value is reused as the maximum transition radius. Each endpoint can
consume no more than half of its original primary arc; where that limit is reached the
radius is reduced by solving the actual geometric constraints. Resolved radii are:

| Opening | Radii (mm) |
|---|---|
| S01 above foil | 22.271127, 22.271127 |
| S02 left of foil | 7.987787, 25, 25 |
| S03 right of foil | 25, 7.987787, 25 |
| S04 below foil | 25, 25, 25 |

Full-precision centres, tangent points, parent circles, sweep directions, and numerical
residuals are recorded in `results/junctions.json` and embedded in the editable SVG.
Near a zero-angle tangency, the inherited polygon cleanup had displaced an apparent
intersection by about 66 mm despite small radial chord errors. The source circles,
not that ill-conditioned polygon intersection, determine the recovered junction.

## Preserved dimensions and relationships

- Physical 1:1 scale; source coordinates in mm, GLB coordinates in metres.
- Clear span 2400 mm; enclosing frame width 160 mm; outer span 2720 mm.
- Main springing 3600 mm; main intrados crown 5678.460969 mm and extrados crown 5861.327044 mm.
- Same two lancet centres, radii, springings, crowns and opening contours.
- Same six-foil contour, ring centre (0, 4941.640786 mm), outer radius 640 mm and 80 mm ring band.
- Seven opening identities and roles; continuous stone; no detached geometry added.
- Original depth orders 300 / 240 / 180 mm and glazing plane unchanged.

Both rendered comparisons hide the inherited mouldings and all masonry joints. This is
a matched *plain-band* comparison, not a misleading comparison of a detailed old model
against a detailed new one. Original chosen profile configuration is retained in `config/baseline.json`.
The bands are meshed as one closed stepped solid for the purpose of inspecting the contours.

## Validation and limits

Five tests cover preserved primary geometry, independent circle tangency equations,
radius constraints, circle-chain closure and exact zero-angle tangency recovery.
Each before/after export passes 32 checks, including one watertight consistently wound
stone body with seven openings, matching mesh/plan footprint and world-coordinate GLB scale.
The minimum stone web is 79.76015655 mm (original recorded 79.544597 mm; original requirement 71 mm).
Maximum unit tangent-vector mismatch is about 6.76e-14. Local arc sampling has 0.25 mm sagitta;
polygon symmetry differs by 0.27855 mm because of tessellation phase, within the two-sided
0.5 mm bound. The canonical circles and transitions are mirrored; no scale adjustment is used.

Both GLBs were re-imported in Blender 4.3.2 and checked on MR.COMPUTER in Blender 5.0.1.
The repaired GLB was passed to Exhibit; its application process was observed. No automated
visual inspection of Exhibit is claimed. The PNG was inspected from the matched Blender renders.
Blender 5.1+ remains unverified; default validation still requires it, while explicit compatibility
mode permits this bounded experiment on the available older installations.

Historical, architectural and structural approval remain separate. The missing F5ZL-C support
schedule remains unresolved. The inherited intersecting-study hairline gap is outside this pass.

## Reproduce

Install the pinned U06 dependencies plus Pillow and Matplotlib, then:

```bash
python run_u07.py --blender blender
```

For explicitly labelled older-runtime testing:

```bash
python run_u07.py --blender blender --compatibility-runtime
```

This regenerates only files inside this experimental package. Failed tests or Blender checks
stop the pipeline before rendering. Inputs, scripts, SVG, full GLBs and editable Blender
review scenes are included; the chat deliverable is the final comparison PNG.

## Next bounded work

Use this head to inspect the unchanged selected moulding profiles at the repaired junctions.
Resolve their mitres, depth steps and termination continuity before designing new stone cuts.
Do not treat this contour experiment as a finished moulding or masonry-joint solution, and
do not alter other windows or primary arch/foil dimensions by inference.
