"""Isolated, dimension-preserving window-head junction study."""
import copy
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import shapely
import trimesh
from shapely.geometry import Point

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine'))
import tracery_universal_U01 as T
import tracery_section_U02 as U
import tracery_joints_U03 as J
from u06_export import export_glb
from u06_qa import check, all_pass, check_export,projected_footprint
from junctions import source_circles,fillet_opening

def write_json(path,data):
    def convert(v):
        if isinstance(v,np.generic):return v.item()
        if isinstance(v,np.ndarray):return v.tolist()
        raise TypeError(type(v).__name__)
    Path(path).write_text(json.dumps(data,indent=2,default=convert))

class JunctionModel(T.Model):
    def __init__(self,spec,scale=1.0):
        spec=copy.deepcopy(spec)
        radius=float(spec['fork_fill'])*scale
        spec['fork_fill']=0
        super().__init__(spec,scale)
        circles=source_circles(self)
        protected=[r['apex'] for r in self.con['arches'].values()]
        self.junctions_repaired={}
        for opening in self.voids:
            if opening['role']!='spandrel':continue
            raw=opening['poly']
            poly,fillets,segments=fillet_opening(raw,circles,protected,radius,.25*scale)
            opening['poly']=poly
            self.junctions_repaired[opening['id']]=dict(fillets=fillets,segments=segments,
                raw_area_mm2=raw.area,new_area_mm2=poly.area)
        self.stone=self.outline.difference(shapely.union_all([v['poly'] for v in self.voids]))
        self.corrections.append(dict(type='explicit_tangent_junction_arcs',
            fillets=sum(len(v['fillets']) for v in self.junctions_repaired.values())))

def plain_band_mesh(sectioned):
    """One closed stepped solid; preserve all original order depths, no moulding or joints."""
    m=sectioned.m
    orders={k:dict(H=sectioned.order_of(k)['H'],prof=np.array([[0.0,0.0],[1.0,0.0]]))
            for k in range(len(sectioned.orders)+4)}
    regions={k:shapely.union_all(v) for k,v in sectioned.regions.items()}
    keys=sorted(regions)
    cons=shapely.union_all([r.boundary for r in regions.values()])
    def label(xs,ys):
        result=np.full(len(xs),-1,dtype=int)
        for k in keys:
            mask=shapely.contains_xy(regions[k],xs,ys)&(result<0);result[mask]=k
        miss=result<0
        if miss.any():
            points=shapely.points(np.c_[xs[miss],ys[miss]])
            distance=np.array([shapely.distance(points,regions[k]) for k in keys])
            result[miss]=np.array(keys)[np.argmin(distance,axis=0)]
        return result
    meshes=[];metadata=[]
    for polygon in T.polys(m.stone):
        V,F,info=J.block_mesh(polygon,cons,{},label,orders,
            shapely.union_all([v['poly'] for v in m.voids]),sectioned.zg,m.size,m.tol)
        meshes.append(trimesh.Trimesh(V,F,process=False));metadata.append(info)
    return trimesh.util.concatenate(meshes),metadata

def geometric_checks(before,after):
    b,a=before.m,after.m
    checks=[check('primary circle centres, radii, springings and crowns preserved',b.con==a.con),
        check('outer stone envelope preserved exactly',b.outline.equals_exact(a.outline,0)),
        check('opening identities and roles preserved',[(v['id'],v['role']) for v in b.voids]==[(v['id'],v['role']) for v in a.voids]),
        check('order depths and glazing plane preserved',
              [o['H'] for o in before.orders]==[o['H'] for o in after.orders] and before.zg==after.zg)]
    for v in b.voids:
        if v['role']!='spandrel':
            w=next(x for x in a.voids if x['id']==v['id'])
            checks.append(check(f'{v["id"]}: primary light / foil contour preserved exactly',v['poly'].equals_exact(w['poly'],0)))
    actual=a.stone
    checks.extend([check('continuous stone region',actual.geom_type=='Polygon'),
        check('exactly seven pierced openings',len(actual.interiors)==7),
        check('all openings contained in outer frame',all(a.outline.contains(v['poly']) for v in a.voids)),
        check('valid final stone and opening geometry',actual.is_valid and all(v['poly'].is_valid for v in a.voids))])
    for name,report in a.junctions_repaired.items():
        for i,f in enumerate(report['fillets']):
            checks.append(check(f'{name} transition {i+1}: tangency continuity',f['tangent_vector_error']<1e-7,
                detail={'radius_mm':f['radius'],'tangent_vector_error':f['tangent_vector_error']}))
    webs=[]
    for i,v in enumerate(a.voids):
        webs.append(v['poly'].distance(a.outline.exterior))
        for w in a.voids[i+1:]:webs.append(v['poly'].distance(w['poly']))
    checks.append(check('minimum stone web retained above original requirement',min(webs)>=b.web['required'],
        detail={'minimum_web_mm':min(webs),'before_minimum_web_mm':b.web['min'],'required_mm':b.web['required']}))
    # The analytic construction and all local circles mirror exactly. The polygon
    # tessellation is allowed only its stated quarter-millimetre display tolerance.
    reflected=shapely.affinity.scale(actual,xfact=-1,yfact=1,origin=(0,0))
    sym=float(shapely.hausdorff_distance(actual.boundary,reflected.boundary))
    checks.append(check('bilateral head symmetry',sym<=.5,detail={'max_boundary_error_mm':sym}))
    return checks,dict(minimum_web_mm=min(webs),symmetry_error_mm=sym,
        area_difference_mm2=actual.area-b.stone.area,
        fillets=sum(len(v['fillets']) for v in a.junctions_repaired.values()),
        maximum_tangent_vector_error=max(f['tangent_vector_error'] for v in a.junctions_repaired.values() for f in v['fillets']))

def make():
    data=json.loads((ROOT/'config/baseline.json').read_text());spec=data['spec']
    spec['u06_units']=data['units']
    section=copy.deepcopy(data['section'])
    # Hide the inherited chosen profiles, preserving their widths and all depths.
    for order in section['orders']:
        width=sum(e[1] for e in order['profile'])
        order['profile']=[['fillet',width]]
    section.update(profile_sampling='adaptive',profile_tolerance=.25)
    before=U.Sectioned(copy.deepcopy(spec),copy.deepcopy(section))
    after=U.Sectioned(copy.deepcopy(spec),copy.deepcopy(section),model_cls=JunctionModel)
    geometry,measurements=geometric_checks(before,after)
    if not all_pass(geometry):
        write_json(ROOT/'results/failed_geometry.json',geometry)
        raise RuntimeError('head geometry checks failed')
    manifest={}
    for variant,obj in [('before',before),('after',after)]:
        out=ROOT/'results'/variant;out.mkdir(parents=True,exist_ok=True)
        mesh,info=plain_band_mesh(obj);q=T.mesh_qa(mesh)
        footprint=projected_footprint([mesh])
        footprint_error=float(shapely.hausdorff_distance(footprint.boundary,obj.m.stone.boundary))
        checks=geometry+[check('plain stepped band: one closed, consistently wound solid with seven openings',
            q['watertight'] and q['winding_consistent'] and q['bodies']==1 and q['euler']==2-2*len(obj.m.voids)
            and q['nonmanifold_edges']==q['degenerate_faces']==0 and q['volume']>0),
            check('full order boundaries retained in meshing',all(i['fallback']==0 and i['violations']==0 for i in info)),
            check('actual stepped mesh preserves intended plan footprint',footprint_error<=.01,
                  detail={'max_boundary_error_mm':footprint_error})]
        if not all_pass(checks):
            write_json(out/'failed_mesh.json',dict(checks=checks,mesh=q,metadata=info))
            raise RuntimeError(f'{variant}: mesh checks failed')
        parts=[('stone',mesh,(.80,.76,.68,1.0),.85)]
        parts.extend(p for p in obj.parts if p[0] in ('wall','glass'))
        binary=export_glb(parts,obj.m.id,obj.m.spec,out/'geometry.glb')
        expected={}
        for name,part,_,_ in parts:
            lo,hi=part.bounds*.001
            expected[name]=dict(vertices=len(part.vertices),faces=len(part.faces),
                bounds_m=[lo.tolist(),hi.tolist()],bounds_blender_m=[[lo[0],-hi[2],lo[1]],[hi[0],-lo[2],hi[1]]])
        # Reuse the proven world-coordinate export checker without rebuilding any model.
        class ExportView:pass
        view=ExportView();view.m=obj.m;view.parts=parts
        checks+=check_export(binary,view,expected)
        report=dict(version='U07-head-R01-experimental',status='EXPERIMENTAL',checks=checks,parts=expected,
            geometry='geometry.glb',geometry_sha256=hashlib.sha256(binary).hexdigest(),measurements=measurements,
            source_units='mm',export_units='m',display='plain bands; inherited order depths retained; mouldings and joints hidden')
        write_json(out/'manifest.json',report);manifest[variant]=report
    write_json(ROOT/'results/junctions.json',after.m.junctions_repaired)
    write_json(ROOT/'results/QA.json',dict(status='EXPERIMENTAL',measurements=measurements,
        protected_dimensions=json.loads((ROOT/'BASELINE.json').read_text())['active_dimensional_constraints'],checks=geometry))
    return before,after,manifest

if __name__=='__main__':
    make()
    print('U07 plain head GLBs generated; primary dimensions preserved.')
