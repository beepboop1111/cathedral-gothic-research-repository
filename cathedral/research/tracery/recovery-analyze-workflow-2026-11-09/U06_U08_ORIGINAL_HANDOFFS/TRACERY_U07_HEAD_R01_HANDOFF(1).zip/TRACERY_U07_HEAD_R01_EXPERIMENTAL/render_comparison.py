"""Matched front orthographic views of verified 1:1 before/after GLBs."""
import json
import math
from pathlib import Path
import bpy
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

ROOT=Path(__file__).resolve().parent
reports=json.loads((ROOT/'results/junctions.json').read_text())

def marker(opening,selection):
    records=reports[opening]['fillets']
    if selection=='left':return min(records,key=lambda f:f['centre'][0])
    if selection=='top':return max(records,key=lambda f:f['corner'][1])
    return min(records,key=lambda f:f['corner'][1])

markers=[marker('S01','left'),marker('S02','top'),marker('S04','bottom')]
for variant in ['before','after']:
    folder=ROOT/'results'/variant
    validation=json.loads((folder/'blender_QA.json').read_text())
    if not validation['all_ok']:raise RuntimeError(f'unvalidated GLB: {variant}')
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
    bpy.ops.import_scene.gltf(filepath=str(folder/'geometry.glb'))
    bpy.context.view_layer.update()
    world=bpy.data.worlds.new('Head comparison world');world.use_nodes=True
    world.node_tree.nodes['Background'].inputs[0].default_value=(.86,.87,.89,1)
    world.node_tree.nodes['Background'].inputs[1].default_value=.65;scene.world=world
    sun=bpy.data.lights.new('Raking sun','SUN');sun.energy=2.7;sun.angle=math.radians(8)
    light=bpy.data.objects.new('Raking sun',sun);scene.collection.objects.link(light)
    light.rotation_euler=Vector((.8,.6,-.8)).to_track_quat('-Z','Y').to_euler()
    camera_data=bpy.data.cameras.new('Matched orthographic head camera');camera_data.type='ORTHO'
    camera=bpy.data.objects.new('Matched orthographic head camera',camera_data);scene.collection.objects.link(camera)
    target=Vector((0,.4,(3.5+5.861327044)/2))
    camera.location=target+Vector((0,-20,0));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
    camera_data.ortho_scale=2.856;camera_data.clip_start=.01;camera_data.clip_end=100;scene.camera=camera
    scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=40;scene.cycles.use_denoising=False
    scene.render.resolution_x,scene.render.resolution_y=1300,1200;scene.render.resolution_percentage=100
    scene.render.film_transparent=False;scene.render.image_settings.file_format='PNG'
    scene.render.filepath=str(folder/'head.png')
    bpy.context.view_layer.update()
    projected=[]
    for f in markers:
        point=Vector((f['centre'][0]*.001,.25,f['centre'][1]*.001))
        uv=world_to_camera_view(scene,camera,point)
        projected.append(dict(u=float(uv.x),v=float(uv.y),radius_mm=f['radius']))
    (folder/'camera.json').write_text(json.dumps(dict(orthographic_scale_m=camera_data.ortho_scale,
        camera_location_m=list(camera.location),target_m=list(target),markers=projected),indent=2))
    bpy.ops.render.render(write_still=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(folder/f'U07_{variant}_plain_head.blend'))
print('U07 matched before/after GLB head renders complete.')
