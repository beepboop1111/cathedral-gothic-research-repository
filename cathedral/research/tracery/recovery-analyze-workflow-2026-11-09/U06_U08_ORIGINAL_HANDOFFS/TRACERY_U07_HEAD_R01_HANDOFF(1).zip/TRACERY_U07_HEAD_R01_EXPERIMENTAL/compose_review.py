"""One matched before/after image, with three local contour close-ups."""
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent
BG,INK,MUTED,TEAL,OLD='#f3f1eb','#172c36','#58686e','#236e70','#94735d'
image=Image.new('RGB',(2200,1820),BG);draw=ImageDraw.Draw(image)
def font(size,bold=False):
    name='DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'
    p=Path('/usr/share/fonts/truetype/dejavu')/name
    return ImageFont.truetype(str(p),size) if p.exists() else ImageFont.load_default(size=size)
def text(x,y,s,size=28,colour=INK,bold=False):draw.text((x,y),s,font=font(size,bold),fill=colour)
def badge(x,y,n,colour):
    draw.ellipse((x-20,y-20,x+20,y+20),fill=BG,outline=colour,width=4)
    draw.text((x,y),str(n),font=font(23,True),fill=colour,anchor='mm')

text(60,38,'UNIFIED CATHEDRAL GENERATOR   /   U07 HEAD R01   /   EXPERIMENTAL',25,TEAL,True)
text(60,88,'Repairing the head junction contours',65,INK,True)
text(60,179,'Matched plain-band views. Main arches, foil, overall size and order depths retained.',31,MUTED)
source={};cameras={};placements={}
for i,(variant,title,colour) in enumerate([('before','Before · flat tip closures',OLD),('after','After · tangent arc closures',TEAL)]):
    x=60+i*1060
    text(x,245,title,36,colour,True)
    photo=Image.open(ROOT/'results'/variant/'head.png').convert('RGB');source[variant]=photo
    photo.thumbnail((1020,942),Image.Resampling.LANCZOS)
    image.paste(photo,(x,310));placements[variant]=(x,310,photo.width,photo.height)
    cam=json.loads((ROOT/'results'/variant/'camera.json').read_text());cameras[variant]=cam
    for n,marker in enumerate(cam['markers'],1):
        px=x+marker['u']*photo.width;py=310+(1-marker['v'])*photo.height
        # The numbered circle sits beside each junction to leave its edge visible.
        bx=px+42;by=py-30
        draw.line((px,py,bx-15,by+12),fill=colour,width=3);badge(bx,by,n,colour)

draw.line((60,1285,2140,1285),fill='#d4d8d3',width=2)
labels=['Upper opening · curved ends','Frame–foil meeting · smooth turn','Lower fork · curved root']
for n,label in enumerate(labels):
    x=60+n*710
    text(x,1320,f'{n+1}  {label}',26,INK,True)
    for i,variant in enumerate(['before','after']):
        photo=source[variant];marker=cameras[variant]['markers'][n]
        cx=marker['u']*photo.width;cy=(1-marker['v'])*photo.height
        # Each paired crop covers exactly the same 220 mm of the source model.
        half=(.220/cameras[variant]['orthographic_scale_m'])*photo.width/2
        crop=photo.crop((round(cx-half),round(cy-half),round(cx+half),round(cy+half)))
        crop=crop.resize((320,250),Image.Resampling.LANCZOS)
        image.paste(crop,(x+i*340,1372))
        colour=OLD if variant=='before' else TEAL
        text(x+i*340,1636,'Before' if variant=='before' else 'After',23,colour,True)

text(60,1700,'11 explicit circle transitions replace the four openings’ generic flat closures. Pointed arch crowns remain pointed.',26,INK)
text(60,1747,'This pass isolates the contours. Moulding continuity and masonry joint design remain unresolved.',25,MUTED)
text(60,1780,'1:1 geometry · inherited depths 300 / 240 / 180 mm · geometric checks only; no historical or structural approval.',21,MUTED)
path=ROOT/'TRACERY_U07_HEAD_R01_COMPARISON.png';image.save(path,optimize=True);print(path)
