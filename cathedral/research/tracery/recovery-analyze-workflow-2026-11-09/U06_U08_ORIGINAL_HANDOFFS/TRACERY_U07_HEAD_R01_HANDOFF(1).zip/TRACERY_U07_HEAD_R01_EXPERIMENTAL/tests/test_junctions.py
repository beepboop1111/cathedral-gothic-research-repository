import json
import sys
import unittest
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'engine')]
import tracery_universal_U01 as T
from head_generator import JunctionModel
from junctions import intersection,source_circles

class JunctionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spec=json.loads((ROOT/'config/baseline.json').read_text())['spec']
        cls.before=T.Model(cls.spec);cls.after=JunctionModel(cls.spec)

    def test_primary_dimensions_and_openings_are_unchanged(self):
        self.assertEqual(self.before.con,self.after.con)
        self.assertTrue(self.before.outline.equals_exact(self.after.outline,0))
        for v in self.before.voids:
            if v['role']!='spandrel':
                after=next(w for w in self.after.voids if w['id']==v['id'])
                self.assertTrue(v['poly'].equals_exact(after['poly'],0))

    def test_independent_circle_tangency_equations(self):
        circles={c['id']:c['circle'] for c in source_circles(self.after)}
        for opening in self.after.junctions_repaired.values():
            for f in opening['fillets']:
                for parent_key,point_key in [('parent_in','tangent_in'),('parent_out','tangent_out')]:
                    c=np.array(circles[f[parent_key]][:2]);r=circles[f[parent_key]][2]
                    p=np.array(f[point_key]);centre=np.array(f['centre'])
                    self.assertAlmostEqual(np.linalg.norm(p-c),r,places=7)
                    self.assertAlmostEqual(np.linalg.norm(p-centre),f['radius'],places=7)
                    normal1=(p-c)/r;normal2=(p-centre)/f['radius']
                    self.assertLess(abs(normal1[0]*normal2[1]-normal1[1]*normal2[0]),1e-8)

    def test_radius_limits_preserve_pointed_arch_crowns(self):
        caps=[f for r in self.after.junctions_repaired.values() for f in r['fillets']]
        self.assertEqual(len(caps),11)
        self.assertTrue(all(0<f['radius']<=self.spec['fork_fill'] for f in caps))
        self.assertTrue(any(f['limited_by_source_arc_budget'] for f in caps))
        for name,arc in self.before.con['arches'].items():
            if name=='outline':continue
            point=np.array(arc['apex'])
            self.assertTrue(all(np.linalg.norm(point-np.array(f['corner']))>1 for f in caps))
            from shapely.geometry import Point
            self.assertLess(self.after.stone.boundary.distance(Point(point)),1e-6)

    def test_circle_chain_closes_without_splines_or_straight_caps(self):
        for result in self.after.junctions_repaired.values():
            segments=result['segments']
            for a,b in zip(segments,segments[1:]+segments[:1]):
                np.testing.assert_allclose(a['end'],b['start'],rtol=0,atol=1e-7)
                self.assertIn(a['kind'],['primary','fillet'])
            self.assertTrue(all(s['circle'][2]>0 for s in segments))

    def test_zero_angle_primary_tangency_is_recovered_exactly(self):
        p=intersection([0,3600,1200],[-1200,3600,2400])
        np.testing.assert_allclose(p[0],[1200,3600],rtol=0,atol=1e-7)

if __name__=='__main__':unittest.main(verbosity=2)
