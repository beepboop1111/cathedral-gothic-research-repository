"""Reproduce only the isolated U07 head study, with real Blender QA before rendering."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--blender',default='blender')
p.add_argument('--compatibility-runtime',action='store_true');args=p.parse_args()
subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=ROOT,check=True)
subprocess.run([sys.executable,'head_generator.py'],cwd=ROOT,check=True)
for variant in ['before','after']:
    command=[args.blender,'-b','--factory-startup','--python-exit-code','7','--python',str(ROOT/'blender_check.py'),
             '--',str(ROOT/'results'/variant/'manifest.json')]
    if args.compatibility_runtime:command.append('--compatibility-runtime')
    subprocess.run(command,cwd=ROOT,check=True)
subprocess.run([sys.executable,'write_svg.py'],cwd=ROOT,check=True)
subprocess.run([args.blender,'-b','--factory-startup','--python-exit-code','7','--python',str(ROOT/'render_comparison.py')],cwd=ROOT,check=True)
subprocess.run([sys.executable,'compose_review.py'],cwd=ROOT,check=True)
