"""Editable exact circle arcs for the head junctions; clear experimental layers."""
import json
from pathlib import Path
from xml.etree.ElementTree import Element,SubElement,ElementTree

ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT/'results/junctions.json').read_text())
svg=Element('svg',xmlns='http://www.w3.org/2000/svg',width='2820mm',height='2461.327044mm',
            viewBox='-1410 -5911.327044 2820 2461.327044')
SubElement(svg,'title').text='U07 plain-head junction study: inherited primary arcs and experimental tangent fillets'
SubElement(svg,'metadata').text=json.dumps(dict(status='EXPERIMENTAL',units='mm',scale='1:1',
    primary_construction_precision_mm=.000001,junctions=data))
g=SubElement(svg,'g',transform='scale(1,-1)',fill='none')
confirmed=SubElement(g,'g',id='confirmed',stroke='black',**{'stroke-width':'2'})
construction=SubElement(g,'g',id='construction',stroke='#888888',**{'stroke-width':'1','stroke-dasharray':'8 6'})
uncertain=SubElement(g,'g',id='uncertain',stroke='#c62828',**{'stroke-width':'2','stroke-dasharray':'8 5'})
for name,report in data.items():
    for i,s in enumerate(report['segments']):
        a,b=s['start'],s['end'];r=s['circle'][2]
        path=f'M {a[0]} {a[1]} A {r} {r} 0 0 {1 if s["direction"]>0 else 0} {b[0]} {b[1]}'
        parent=uncertain if s['kind']=='fillet' else confirmed
        SubElement(parent,'path',id=f'{name}_{i}',d=path,**{'data-circle':json.dumps(s['circle']),
            'data-kind':s['kind'],'data-sweep-direction':str(s['direction'])})
    for i,f in enumerate(report['fillets']):
        cx,cy=f['centre'];r=f['radius']
        SubElement(construction,'circle',id=f'{name}_construction_{i}',cx=str(cx),cy=str(cy),r=str(r))
        SubElement(construction,'path',d=f'M {cx-4} {cy} h 8 M {cx} {cy-4} v 8')
ElementTree(svg).write(ROOT/'results/U07_EDITABLE_JUNCTIONS.svg',encoding='utf-8',xml_declaration=True)
print('Exact junction SVG written with physical millimetre dimensions.')
