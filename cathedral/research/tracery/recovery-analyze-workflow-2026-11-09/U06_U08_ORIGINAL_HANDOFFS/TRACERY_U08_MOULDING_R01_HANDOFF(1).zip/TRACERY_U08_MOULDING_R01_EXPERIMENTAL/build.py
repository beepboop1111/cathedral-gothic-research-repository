"""Reapply inherited profiles, then join order surfaces with shared vertex columns."""
import copy,hashlib,json
from pathlib import Path
import numpy as np
import head_generator as H
from head_generator import U,T,write_json,export_glb,check,check_export,all_pass,projected_footprint
ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT/'config/baseline.json').read_text());spec=data['spec'];spec['u06_units']=data['units']
section=copy.deepcopy(data['section']);section.update(profile_sampling='adaptive',profile_tolerance=.25)
model=U.Sectioned(spec,section,model_cls=H.JunctionModel)
mesh,info=H.continuous_profile_mesh(model)
q=T.mesh_qa(mesh)
error=float(H.shapely.hausdorff_distance(projected_footprint([mesh]).boundary,model.m.stone.boundary))
tests=[check('single closed connected profiled stone with seven openings',q['watertight'] and q['winding_consistent'] and q['bodies']==1 and q['euler']==-12 and q['volume']>0),
 check('no nonmanifold, degenerate or unused vertices',q['nonmanifold_edges']==q['degenerate_faces']==q['unreferenced_vertices']==0),
 check('complete order and moulding linework retained',all(i['fallback']==0 and i['violations']==0 for i in info)),
 check('U07 opening footprint preserved',error<=.01,detail={'error_mm':error}),
 check('inherited profiles and depths unchanged',all(o['raw']==s['profile'] and 2*o['H']==s['depth'] for o,s in zip(model.orders,data['section']['orders'])))]
write_json(ROOT/'results/continuity_QA.json',dict(checks=tests,mesh=q,metadata=info))
if not all_pass(tests):raise RuntimeError('continuity checks failed')
for variant in ['before','after']:
 folder=ROOT/'results'/variant;folder.mkdir(exist_ok=True)
 parts=model.parts if variant=='before' else [('stone',mesh,(.80,.76,.68,1),.85)]+[p for p in model.parts if p[0] in ('wall','glass')]
 binary=export_glb(parts,model.m.id,spec,folder/'geometry.glb');expected={}
 for name,part,_,_ in parts:
  lo,hi=part.bounds*.001;expected[name]=dict(vertices=len(part.vertices),faces=len(part.faces),bounds_m=[lo.tolist(),hi.tolist()],bounds_blender_m=[[lo[0],-hi[2],lo[1]],[hi[0],-lo[2],hi[1]]])
 class View:pass
 view=View();view.m=model.m;view.parts=parts
 checks=(tests if variant=='after' else [check('reference uses separate closed order pieces',True,detail='Baseline interfaces may touch or overlap; no assembled continuity pass is claimed.')])+check_export(binary,view,expected)
 write_json(folder/'manifest.json',dict(status='EXPERIMENTAL',geometry='geometry.glb',geometry_sha256=hashlib.sha256(binary).hexdigest(),parts=expected,checks=checks))
write_json(ROOT/'results/junctions.json',model.m.junctions_repaired)
write_json(ROOT/'results/parameters.json',dict(spec=spec,section=section,scope='No stone joints. U07 contour and original profiles retained.'))
print('Profiled comparison built:',q['vertices'],'vertices;',q['faces'],'faces; footprint error',error)
