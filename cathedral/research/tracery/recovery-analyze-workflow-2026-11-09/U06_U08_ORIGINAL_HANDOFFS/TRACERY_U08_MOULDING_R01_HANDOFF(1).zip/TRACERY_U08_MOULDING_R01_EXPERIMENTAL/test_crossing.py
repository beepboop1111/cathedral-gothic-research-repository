"""Independent regression for an order-height crossing at y=1."""
import unittest
import head_generator as H
import numpy as np
from shapely.geometry import Polygon,LineString
class CrossingTest(unittest.TestCase):
 def test_crossing_is_split_and_closed_without_changing_volume(self):
  B=Polygon([(-1,0),(1,0),(1,2),(-1,2)])
  orders={0:dict(H=3.,prof=np.array([[0.,0.],[2.,2.]])),1:dict(H=2.,prof=np.array([[0.,0.],[2.,0.]]))}
  label=lambda x,y:np.where(x<0,0,1)
  V,F,info=H.J._tri_block(B,[B.boundary,LineString([(0,0),(0,2)])],{},lambda x,y:(round(x/1e-7),round(y/1e-7)),label,orders,LineString([(-1,0),(1,0)]),0,2,.001,1e-7,0)
  mesh=H.trimesh.Trimesh(V,F,process=False)
  self.assertEqual(info['crossing_splits'],1)
  self.assertEqual(info['violations'],0)
  self.assertTrue(mesh.is_watertight)
  self.assertAlmostEqual(mesh.volume,16.,places=8)
if __name__=='__main__':unittest.main(verbosity=2)
