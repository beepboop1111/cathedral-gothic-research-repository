# U08 moulding continuity R01

EXPERIMENTAL. Parent: U07 plain-head contour study. Its contours and primary
dimensions are retained. The inherited three profiles and 300/240/180 mm order
depths are reapplied unchanged. Stone joints remain excluded.

The first attempt to join the profiled orders exposed 20 shared edges on which
the two order surfaces exchanged height. The original riser builder reported
40 directed violations and left 160 nonmanifold edges. U08 subdivides those
shared edges at the exact crossing of the existing piecewise-linear heights,
uses shared vertex columns, and closes each riser with consistent orientation.
Both front and back faces are handled. The profile definitions are unchanged;
new crossing vertices interpolate the existing mesh surfaces, not new profiles.

The candidate is one closed connected profiled stone body with seven openings.
It has 11,022 vertices and 22,068 faces; source footprint deviation is zero.
It passes Python topology/export checks and Blender re-import checks. Intentional
profile creases, mitres and order depth steps remain: this is C0 surface closure,
not a claim of global tangent smoothness or complete architectural approval.

The baseline consists of independent closed order pieces. Its Blender assembly
check flags seven touching/overlapping surface pairs; these are reference
interfaces, not seven proven volume collisions. It is rendered only as a
diagnostic comparison. The repaired candidate passes the full checker.

`test_crossing.py` independently constructs two order height fields that cross
at y=1. It verifies the split, zero remaining violations, watertightness and the
analytic total volume of 16 cubic units. The real-window QA is in
`results/continuity_QA.json`; the actual import checks are in `results/after`.

Reproduce with the U07 pinned dependencies:

```bash
python test_crossing.py
python build.py
blender -b --factory-startup --python-exit-code 7 --python blender_check.py -- results/after/manifest.json --compatibility-runtime
blender -b --factory-startup --python-exit-code 7 --python render_comparison.py
python compose_review.py
```

Omit compatibility mode on Blender 5.1+. Available runtimes here are 4.3.2 and
MR.COMPUTER 5.0.1; 5.1+ is not verified. Full geometric closure does not establish
historical, architectural or structural approval. F5ZL-C remains unresolved.

The old U06 and U07 packages and all other cathedral geometry remain unchanged.
The new edge-crossing implementation is confined to this U08 engine copy.
The comparison uses matched cameras and the same profiles, with no stone cuts.
