"""Recover circle chains and replace convex compound-junction tips with G1 arcs.

Primary pointed crowns are protected. No proportional or primary-circle fitting
is performed. The former 25 mm tip parameter becomes an explicit fillet radius.
"""
import math
import numpy as np
import shapely
from shapely.geometry import Point, Polygon

TAU=2*math.pi

def intersection(a,b,tolerance=1e-7):
    ca,cb=np.array(a[:2],float),np.array(b[:2],float)
    ra,rb=float(a[2]),float(b[2]);dv=cb-ca;d=np.linalg.norm(dv)
    if d<=tolerance or d>ra+rb+tolerance or d<abs(ra-rb)-tolerance:
        return []
    along=(ra*ra-rb*rb+d*d)/(2*d);h2=ra*ra-along*along
    if h2 < -tolerance*max(ra,rb,1):return []
    mid=ca+along*dv/d;normal=np.array([-dv[1],dv[0]])/d
    h=math.sqrt(max(0,float(h2)))
    return [mid+h*normal,mid-h*normal] if h>tolerance else [mid]

def arc_delta(circle,a,b,direction):
    c=np.asarray(circle[:2]);a0=math.atan2(*(np.asarray(a)-c)[::-1]);a1=math.atan2(*(np.asarray(b)-c)[::-1])
    return ((a1-a0)*direction)%TAU

def arc_points(circle,a,b,direction,tol):
    c=np.asarray(circle[:2]);r=circle[2]
    theta=math.atan2(*(np.asarray(a)-c)[::-1]);delta=arc_delta(circle,a,b,direction)
    step=2*math.acos(max(-1,min(1,1-tol/r)))
    n=max(1,math.ceil(delta/step))
    angles=theta+direction*np.linspace(0,delta,n+1)
    points=c+r*np.c_[np.cos(angles),np.sin(angles)]
    points[0],points[-1]=a,b
    return points

def source_circles(model):
    """Unique primary circles bounding the four spandrel openings."""
    items=[]
    for name,record in model.con['arches'].items():
        if name=='outline':continue
        for side in ('CL','CR'):
            circle=record[side]
            if not any(np.allclose(circle,x['circle'],rtol=0,atol=1e-5) for x in items):
                items.append(dict(id=f'{name}.{side}',circle=circle))
    record=model.con['circles']['W.O'];cx,cy=record['centre']
    items.append(dict(id='W.O.outer',circle=[cx,cy,record['r_outer']]))
    return items

def recover_runs(poly,circles,tolerance):
    points=np.asarray(poly.exterior.coords)[:-1]
    labels=[]
    for a,b in zip(points,np.roll(points,-1,axis=0)):
        def score(item):
            c=np.array(item['circle'][:2]);r=item['circle'][2]
            return abs(np.linalg.norm(a-c)-r)+abs(np.linalg.norm(b-c)-r)
        labels.append(min(range(len(circles)),key=lambda k:score(circles[k])))
    changes=[i for i in range(len(points)) if labels[i]!=labels[i-1]]
    if len(changes)<2:raise ValueError('expected a compound circle-chain opening')
    runs=[]
    for a,b in zip(changes,changes[1:]+[changes[0]+len(points)]):
        indices=np.arange(a,b+1)%len(points);p=points[indices];item=circles[labels[a]]
        c=np.asarray(item['circle'][:2]);angles=np.unwrap(np.arctan2(p[:,1]-c[1],p[:,0]-c[0]))
        direction=1 if angles[-1]>angles[0] else -1
        residual=float(np.max(np.abs(np.linalg.norm(p-c,axis=1)-item['circle'][2])))
        if residual>2*tolerance:raise ValueError(f'circle attribution residual {residual}')
        runs.append(dict(circle=item['circle'],id=item['id'],direction=direction,raw=p,
                         start=p[0],end=p[-1],source_residual=residual))
    corners=[]
    for i,run in enumerate(runs):
        other=runs[(i+1)%len(runs)]
        candidates=intersection(run['circle'],other['circle'])
        if not candidates:raise ValueError('source circles do not intersect')
        point=min(candidates,key=lambda p:np.linalg.norm(p-run['end']))
        # Near tangency, a sub-millimetre chord error can move a polygon's
        # apparent intersection by an entire sample chord. Recover the exact
        # circle intersection using that conditioning bound, not a fit.
        conditioned_limit=max(2*tolerance,math.sqrt(8*max(run['circle'][2],other['circle'][2])*tolerance))
        if np.linalg.norm(point-run['end'])>conditioned_limit:
            raise ValueError('source intersection too far from sampled contour')
        run['end']=point;other['start']=point;corners.append(point)
    return runs,corners

def tangent(circle,point,direction):
    radial=(np.asarray(point)-np.asarray(circle[:2]))/circle[2]
    return direction*np.array([-radial[1],radial[0]])

def fillet_opening(poly,circles,protected,radius,tolerance=.25):
    runs,corners=recover_runs(poly,circles,max(tolerance,.5))
    # Reconstruct the intended compass boundary before selecting an interior
    # fillet centre. The sampled source trims zero-angle tips during cleanup.
    analytic_points=[]
    for r in runs:
        analytic_points.extend(arc_points(r['circle'],r['start'],r['end'],r['direction'],tolerance/2)[:-1])
    analytic_domain=Polygon(analytic_points)
    if not analytic_domain.is_valid:raise ValueError('invalid recovered circle-chain domain')
    fillets=[None]*len(runs);diagnostics=[]
    for i,(run,corner) in enumerate(zip(runs,corners)):
        nxt=runs[(i+1)%len(runs)]
        if any(np.linalg.norm(corner-p)<1e-4 for p in protected):continue
        tin=tangent(run['circle'],corner,run['direction']);tout=tangent(nxt['circle'],corner,nxt['direction'])
        turn=math.atan2(float(tin[0]*tout[1]-tin[1]*tout[0]),float(np.dot(tin,tout)))
        # Numerically opposite tangents have an ambiguous signed pi; the corner is convex.
        if abs(abs(turn)-math.pi)<1e-5:turn=math.pi
        if turn<1e-4:continue
        def feasible(rfillet):
            a=list(run['circle']);b=list(nxt['circle'])
            a[2]-=run['direction']*rfillet;b[2]-=nxt['direction']*rfillet
            valid=[]
            for centre in intersection(a,b):
                if not analytic_domain.buffer(tolerance).contains(Point(centre)):continue
                p=[]
                for r in (run,nxt):
                    c=np.array(r['circle'][:2]);v=centre-c
                    p.append(c+r['circle'][2]*v/np.linalg.norm(v))
                q1,q2=p
                # Each endpoint may consume at most half its source arc. This
                # keeps neighbouring blends apart and preserves pointed crowns.
                back=arc_delta(run['circle'],q1,run['end'],run['direction'])
                forward=arc_delta(nxt['circle'],nxt['start'],q2,nxt['direction'])
                if back>.5*arc_delta(run['circle'],run['start'],run['end'],run['direction'])+1e-8:continue
                if forward>.5*arc_delta(nxt['circle'],nxt['start'],nxt['end'],nxt['direction'])+1e-8:continue
                circle=[float(centre[0]),float(centre[1]),rfillet]
                if arc_delta(circle,q1,q2,1)>math.pi+1e-4:continue
                valid.append((centre,q1,q2,circle))
            return min(valid,key=lambda v:np.linalg.norm(v[0]-corner)) if valid else None
        chosen=feasible(radius)
        resolved_radius=radius
        if chosen is None:
            lo,hi=1e-4,radius
            if feasible(lo) is None:raise ValueError(f'no feasible tangent circle at {corner.tolist()}')
            for _ in range(50):
                mid=(lo+hi)/2
                if feasible(mid) is None:hi=mid
                else:lo=mid
            resolved_radius=max(1e-4,lo-1e-5)
            chosen=feasible(resolved_radius)
        centre,q1,q2,circle=chosen
        t1=tangent(run['circle'],q1,run['direction']);t2=tangent(nxt['circle'],q2,nxt['direction'])
        f1=tangent(circle,q1,1);f2=tangent(circle,q2,1)
        error=max(np.linalg.norm(t1-f1),np.linalg.norm(t2-f2))
        if error>1e-7:raise ValueError(f'non-tangent fillet ({error})')
        fillets[i]=dict(circle=circle,start=q1,end=q2,direction=1)
        diagnostics.append(dict(corner=corner.tolist(),centre=centre.tolist(),radius=resolved_radius,
            requested_radius=radius,limited_by_source_arc_budget=resolved_radius<radius,
            tangent_in=q1.tolist(),tangent_out=q2.tolist(),parent_in=run['id'],parent_out=nxt['id'],
            tangent_vector_error=float(error),setback_mm=float(np.linalg.norm(centre-corner))))
    points=[];segments=[]
    for i,run in enumerate(runs):
        before,after=fillets[i-1],fillets[i]
        a=before['end'] if before else run['start'];b=after['start'] if after else run['end']
        if arc_delta(run['circle'],a,b,run['direction'])>arc_delta(run['circle'],run['start'],run['end'],run['direction'])+1e-4:
            raise ValueError('neighbouring fillets consume a source arc')
        segment=dict(circle=run['circle'],start=np.asarray(a).tolist(),end=np.asarray(b).tolist(),direction=run['direction'],kind='primary',parent=run['id'])
        points.extend(arc_points(**{k:segment[k] for k in ['circle','direction']},a=a,b=b,tol=tolerance)[:-1])
        segments.append(segment)
        if after:
            points.extend(arc_points(after['circle'],after['start'],after['end'],1,tolerance)[:-1])
            segments.append(dict(circle=after['circle'],start=after['start'].tolist(),end=after['end'].tolist(),direction=1,kind='fillet'))
    result=Polygon(points)
    if not result.is_valid or result.area<=0:raise ValueError('invalid filleted opening')
    return result,diagnostics,segments
