"""Small independent oracles plus failure-path tests for the reliability contract."""
import copy
import io
import json
import math
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'engine')]
import numpy as np
import trimesh
from u06_profiles import profile_polyline
from u06_export import metres_per_unit, export_glb
from u06_qa import profile_error
import tracery

class ProfileTests(unittest.TestCase):
    def test_independent_analytic_dense_samples(self):
        for kind in ('roll','hollow','ogee'):
            for width,rise,tol in ((50,50,.25),(16,14,.1),(50,10,.05),(5,60,.2)):
                with self.subTest(kind=kind,width=width,rise=rise):
                    r=profile_error([[kind,width,rise]],tol)[0]
                    self.assertLessEqual(r['max_error'],tol)

    def test_uniform_scaling_retains_sampling(self):
        a=profile_polyline([['roll',50,50]],float,tolerance=.25)
        b=profile_polyline([['roll',100,100]],float,tolerance=.5)
        np.testing.assert_allclose(b,2*a,rtol=0,atol=1e-12)

    def test_legacy_fixture_error_is_reduced(self):
        old=profile_polyline([['roll',50,50]],float)
        new=profile_polyline([['roll',50,50]],float,tolerance=.25)
        self.assertEqual(len(old)-1,6)
        self.assertEqual(len(new)-1,8)
        self.assertLessEqual(profile_error([['roll',50,50]],.25)[0]['max_error'],.25)

class UnitTests(unittest.TestCase):
    def test_export_converts_once_and_preserves_source(self):
        mesh=trimesh.creation.box(extents=[1000,2000,500]);old=mesh.vertices.copy()
        data=export_glb([('stone',mesh,(.8,.8,.8,1),.8)],'unit_probe',{'u06_units':{'length_unit':'mm'}},None)
        scene=trimesh.load(io.BytesIO(data),file_type='glb',force='scene',process=False)
        np.testing.assert_allclose(scene.extents,[1,2,.5],atol=1e-7,rtol=0)
        np.testing.assert_array_equal(mesh.vertices,old)

    def test_uncalibrated_pixels_blocked(self):
        for units in ({'length_unit':'source_px'}, {'length_unit':'source_px','calibration':{'mm_per_px':2}},
                      {'length_unit':'source_px','calibration':{'mm_per_px':True,'evidence':'bad'}}):
            with self.assertRaises(ValueError):metres_per_unit({'u06_units':units})

    def test_evidenced_calibration_is_explicit(self):
        self.assertEqual(metres_per_unit({'u06_units':{'length_unit':'source_px',
            'calibration':{'mm_per_px':2,'evidence':'test-only calibration'}}}),.002)

    def test_unknown_units_blocked(self):
        for unit in ('metres','pixels','inch',None):
            with self.assertRaises(ValueError):metres_per_unit({'u06_units':{'length_unit':unit}})

    def test_svg_user_coordinates_have_explicit_physical_scale(self):
        from xml.etree import ElementTree
        spec,_,_=tracery.inputs('bar_2light_sexfoil')
        model=tracery.T.Model(spec)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'source.svg';tracery.write_svg(model,p)
            root=ElementTree.parse(p).getroot();width=float(root.get('width').removesuffix('mm'))
            self.assertAlmostEqual(width,float(root.get('viewBox').split()[2]),places=6)

class FailurePathTests(unittest.TestCase):
    def run_cli(self,args):
        return subprocess.run([sys.executable,str(ROOT/'tracery.py'),*args],capture_output=True,text=True)

    def test_wrong_opening_count_stops_before_export(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);override=td/'invalid.json';override.write_text(json.dumps({'expect':{'light':999,'foil':1}}))
            r=self.run_cli(['build','--out',str(td/'run'),'--override',str(override),'--cache',str(td/'cache'),
                            '--compatibility-runtime'])
            self.assertNotEqual(r.returncode,0,r.stdout+r.stderr)
            report=json.loads((td/'run/manifest.json').read_text())
            self.assertEqual(report['status'],'FAILED')
            self.assertTrue(any(not c['ok'] for c in report['checks']))
            self.assertFalse(any((td/'run').rglob('*.glb')))

    def test_pixel_model_stops_before_export(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            r=self.run_cli(['build','--model','stleu_fig80_rebuild','--out',str(td/'run')])
            self.assertNotEqual(r.returncode,0)
            self.assertFalse(any((td/'run').rglob('*.glb')))

    def test_failed_blender_manifest_has_nonzero_exit_and_no_render(self):
        # A tiny synthetic cube makes this a real Blender test without regenerating a window.
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);mesh=trimesh.creation.box()
            data=export_glb([('stone',mesh,(.8,.8,.8,1),.8)],'cube',{'u06_units':{'length_unit':'m'}},td/'geometry.glb')
            bb=mesh.bounds.tolist()
            import hashlib
            report=dict(checks=[{'ok':True}],geometry='geometry.glb',geometry_sha256=hashlib.sha256(data).hexdigest(),
                parts={'stone':dict(vertices=len(mesh.vertices)+1,faces=len(mesh.faces),
                    bounds_blender_m=[[bb[0][0],-bb[1][2],bb[0][1]],[bb[1][0],-bb[0][2],bb[1][1]]])})
            (td/'manifest.json').write_text(json.dumps(report))
            r=self.run_cli(['validate',str(td/'manifest.json'),'--render','--compatibility-runtime'])
            self.assertNotEqual(r.returncode,0,r.stdout+r.stderr)
            q=json.loads((td/'blender_QA.json').read_text())
            self.assertFalse(q['all_ok'])
            self.assertFalse(any(td.glob('*.png')))

    def test_input_nan_is_blocked(self):
        spec,sec,joints=tracery.inputs('bar_2light_sexfoil');sec['profile_tolerance']=math.nan
        with self.assertRaises(ValueError):tracery.validate_inputs(spec,sec,joints)

    def test_blender_catches_collisions_between_closed_stones(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);parts=[];expected={}
            for i,name in enumerate(('stone_A','stone_B')):
                mesh=trimesh.creation.box();mesh.apply_translation([i*.4,0,0])
                parts.append((name,mesh,(.8,.8,.8,1),.8));bb=mesh.bounds.tolist()
                expected[name]=dict(vertices=len(mesh.vertices),faces=len(mesh.faces),
                    bounds_blender_m=[[bb[0][0],-bb[1][2],bb[0][1]],[bb[1][0],-bb[0][2],bb[1][1]]])
            data=export_glb(parts,'overlap',{'u06_units':{'length_unit':'m'}},td/'geometry.glb')
            import hashlib
            report=dict(checks=[{'ok':True}],geometry='geometry.glb',geometry_sha256=hashlib.sha256(data).hexdigest(),parts=expected)
            (td/'manifest.json').write_text(json.dumps(report))
            r=self.run_cli(['validate',str(td/'manifest.json'),'--compatibility-runtime'])
            self.assertNotEqual(r.returncode,0)
            q=json.loads((td/'blender_QA.json').read_text())
            self.assertTrue(all(p['ok'] for p in q['parts'].values()))
            self.assertTrue(q['assembly']['stone_surface_collision_pairs'])

class DomainTests(unittest.TestCase):
    def test_closed_constraint_outside_concave_block_is_not_stone(self):
        # Triangle can legitimately fill this enclosed outside cell. The material
        # domain filter must remove it before front/back surfaces are constructed.
        from shapely.geometry import Polygon, LineString
        import tracery_joints_U03 as J
        B=Polygon([(0,0),(10,0),(10,10),(6,10),(6,4),(4,4),(4,10),(0,10)])
        lines=[B.boundary,LineString([(4,9),(6,9)])]
        order={0:dict(H=1.0,prof=np.array([[0.0,0.0],[1.0,0.0]]))}
        zero=lambda x,y:np.zeros(len(x),dtype=int)
        V,F,info=J._tri_block(B,lines,{},lambda x,y:(round(x/1e-6),round(y/1e-6)),zero,
            order,B.boundary,0,10,.01,1e-6,0)
        mesh=trimesh.Trimesh(V,F,process=False)
        from u06_qa import projected_footprint
        actual=projected_footprint([mesh])
        self.assertLess(actual.symmetric_difference(B).area,1e-8)
        self.assertTrue(mesh.is_watertight)

if __name__=='__main__':
    unittest.main(verbosity=2)
