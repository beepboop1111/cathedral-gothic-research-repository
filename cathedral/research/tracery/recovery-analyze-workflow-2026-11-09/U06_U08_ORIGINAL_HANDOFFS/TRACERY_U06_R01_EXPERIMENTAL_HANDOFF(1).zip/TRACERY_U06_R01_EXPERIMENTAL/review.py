"""One review PNG from verified model renders and numerical QA; no model generation."""
from pathlib import Path
import io
import json
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'engine'))
from u06_profiles import profile_polyline, SHAPES
from u06_qa import profile_error
q=json.loads((ROOT/'QA_SUMMARY.json').read_text())
BG,INK,MUTED,TEAL='#f3f1eb','#172c36','#566870','#236e70'
im=Image.new('RGB',(2200,1800),BG);d=ImageDraw.Draw(im)
def font(size,bold=False):
    p=Path('/usr/share/fonts/truetype/dejavu')/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')
    return ImageFont.truetype(str(p),size) if p.exists() else ImageFont.load_default(size=size)
def text(x,y,s,size=28,fill=INK,bold=False):d.text((x,y),s,font=font(size,bold),fill=fill)
def wrap(x,y,s,width,size=27,fill=MUTED):
    line=''
    for word in s.split():
        candidate=(line+' '+word).strip()
        if d.textlength(candidate,font=font(size))>width and line:
            text(x,y,line,size,fill);y+=size+9;line=word
        else:line=candidate
    if line:text(x,y,line,size,fill)
def photo(path,box):
    p=Image.open(path).convert('RGBA');x,y,w,h=box
    p.thumbnail((w,h),Image.Resampling.LANCZOS)
    im.paste(p,(x+(w-p.width)//2,y+(h-p.height)//2),p)

text(60,40,'UNIFIED CATHEDRAL GENERATOR   /   U06 R01   /   EXPERIMENTAL',25,TEAL,True)
text(60,94,'Scale, curves and QA corrected.',70,INK,True)
text(60,185,'Original U01–U05 preserved. Four physical tracery families checked against recovered source plans.',30,MUTED)

d.rounded_rectangle((60,255,790,1375),radius=20,fill='#e7e7e1')
photo(ROOT/'results/FINAL_2LIGHT/render_whole.png',(75,270,700,945))
text(95,1233,'46 stones · 48 imported meshes',30,INK,True)
text(95,1282,'Metre export · 4.120 m wall width',27,TEAL,True)
text(95,1330,'1:1 geometry; camera adjusted for review',23,MUTED)

d.rounded_rectangle((830,255,2140,925),radius=20,fill='#e7e7e1')
photo(ROOT/'results/FINAL_2LIGHT/render_head.png',(850,270,1270,600))
text(865,877,'Actual GLB re-import · moulded head, cusps and separate masonry stones',25,INK,True)

# A precise analytic benchmark makes the sampling improvement visible.
fig,ax=plt.subplots(figsize=(7.3,4.0),dpi=100)
x=np.linspace(0,50,20001);y=np.array([50*(1-SHAPES['roll'](v/50)) for v in x])
old=profile_polyline([['roll',50,50]],float)
new=profile_polyline([['roll',50,50]],float,tolerance=.25)
ax.plot(x,y,color='#172c36',lw=2,label='Analytic curve')
ax.plot(old[:,0],old[:,1],color='#929b9e',lw=1.8,marker='o',ms=3,label='Old: 6 segments')
ax.plot(new[:,0],new[:,1],color=TEAL,lw=1.6,marker='o',ms=3,label='U06: 8 segments')
ax.set_aspect('equal');ax.set_xlabel('Width (mm)');ax.set_ylabel('Drop (mm)')
ax.spines[['top','right']].set_visible(False);ax.legend(frameon=False,fontsize=10,loc='upper right')
ax.grid(alpha=.12);fig.tight_layout()
b=io.BytesIO();fig.savefig(b,format='png',facecolor='white');plt.close(fig)
plot=Image.open(io.BytesIO(b.getvalue())).convert('RGB')
d.rounded_rectangle((830,965,1570,1375),radius=18,fill='white')
plot.thumbnail((720,390));im.paste(plot,(840,975))

d.rounded_rectangle((1600,965,2140,1375),radius=18,fill='white')
text(1630,990,'50 × 50 mm roll benchmark',25,INK,True)
text(1630,1050,'2.129 → 0.241 mm',35,TEAL,True)
text(1630,1104,'Maximum curve deviation',24,MUTED)
text(1630,1154,'Target: ≤ 0.250 mm',26,INK,True)
text(1630,1220,'Cache preparation',25,INK,True)
c=q['cache']
text(1630,1260,f"{c['cold_generation_and_export_seconds']:.2f} → {c['warm_generation_and_export_seconds']:.3f} s",32,TEAL,True)
text(1630,1310,'Blender QA reruns on cache hits',21,MUTED)

d.line((60,1420,2140,1420),fill='#d4d8d3',width=2)
text(60,1450,'VALIDATION RESULTS',26,TEAL,True)
text(60,1500,f"{q['python_checks_total']}/{q['python_checks_total']} Python checks",34,INK,True)
text(60,1555,f"{q['imported_meshes_total']} mesh objects · {q['unit_tests']} regression tests",27,INK)
text(60,1600,'Bad units, failed counts and collisions stop release.',25,MUTED)

text(910,1450,'Family',25,MUTED,True);text(1470,1450,'Checks',25,MUTED,True);text(1760,1450,'Meshes',25,MUTED,True)
for i,(key,label) in enumerate([('2LIGHT','Two-light'),('4LIGHT','Four-light'),('INTERSECTING','Intersecting'),('ROSE','Rose')]):
    y0=1495+i*38;case=q['cases'][key]
    text(910,y0,label,25);text(1470,y0,str(case['checks_total']),25);text(1760,y0,str(case['imported_meshes']),25)
text(60,1685,'Compatibility checks: Blender 4.3.2 (all models); MR.COMPUTER Blender 5.0.1 (representative model).',23,MUTED)
text(60,1722,'Blender 5.1+ remains unverified. Strict runtime gate blocks older versions. Historical / structural approval is separate.',22,MUTED)
text(60,1756,'Recorded for architectural review: inherited 0.021 mm hairline clearance in the intersecting study.',22,MUTED)
out=ROOT/'TRACERY_U06_R01_RESULT.png';im.save(out,optimize=True);print(out)
