"""The single unit boundary for every U06 GLB exporter."""
import math
from pathlib import Path
import trimesh

def metres_per_unit(spec):
    units = spec.get('u06_units')
    if not isinstance(units, dict):
        raise ValueError('U06 export requires structured u06_units metadata')
    kind = units.get('length_unit')
    if kind in ('mm', 'm'):
        return {'mm': 0.001, 'm': 1.0}[kind]
    if kind == 'source_px':
        cal = units.get('calibration') or {}
        value = cal.get('mm_per_px')
        if (isinstance(value, bool) or not isinstance(value, (int, float))
                or not math.isfinite(value) or value <= 0 or not cal.get('evidence')):
            raise ValueError('uncalibrated source pixels cannot be exported as architectural GLB')
        return value * 0.001
    raise ValueError(f'unsupported length unit: {kind!r}')

def export_glb(parts, model_id, spec, path):
    factor = metres_per_unit(spec)
    scene = trimesh.Scene()
    scene.metadata['u06'] = dict(status='EXPERIMENTAL', source_units=spec['u06_units'],
                                 export_unit='m', metres_per_unit=factor)
    for name, source, rgba, roughness in parts:
        mesh = trimesh.Trimesh(source.vertices.copy() * factor, source.faces.copy(), process=False)
        mesh.units = 'm'
        mesh.visual = trimesh.visual.TextureVisuals(material=trimesh.visual.material.PBRMaterial(
            name=f'{name}_mat', baseColorFactor=list(rgba), metallicFactor=0.0, roughnessFactor=roughness))
        scene.add_geometry(mesh, node_name=f'{model_id}__{name}', geom_name=f'{model_id}__{name}')
    data = scene.export(file_type='glb', include_normals=False)
    if path is not None:
        Path(path).write_bytes(data)
    return data
