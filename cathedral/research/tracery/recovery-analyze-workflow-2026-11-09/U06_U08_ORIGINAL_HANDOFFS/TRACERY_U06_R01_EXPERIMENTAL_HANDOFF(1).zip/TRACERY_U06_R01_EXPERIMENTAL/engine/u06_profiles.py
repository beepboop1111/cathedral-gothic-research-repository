"""Tolerance-bounded analytic profiles, retaining a legacy regression mode."""
import math
import numpy as np

SHAPES = {
    'chamfer': lambda s: s,
    'roll': lambda s: math.sqrt(max(0.0, 1 - (1 - s) ** 2)),
    'hollow': lambda s: 1 - math.sqrt(max(0.0, 1 - s * s)),
    'ogee': lambda s: 0.5 * (1 - math.cos(math.pi * s)),
}

def curved_points(kind, width, rise, tolerance):
    """Points from (0,0) to (width,rise), with a conservative chord error bound.

    A quarter ellipse is a linear image of a unit circle: max(width,rise)
    times its circular sagitta bounds the Euclidean error. For the cosine ogee,
    max |y''| / (8*n*n) bounds vertical interpolation error and hence distance.
    """
    if not (math.isfinite(tolerance) and tolerance > 0):
        raise ValueError('profile tolerance must be finite and positive')
    if kind in ('roll', 'hollow'):
        radius = max(width, abs(rise))
        angle_step = 2 * math.acos(max(-1.0, min(1.0, 1 - tolerance / radius)))
        n = max(1, math.ceil((math.pi / 2) / max(angle_step, 1e-12)))
        theta = np.linspace(0, math.pi / 2, n + 1)
        if kind == 'roll':
            points = np.c_[width * (1 - np.cos(theta)), rise * np.sin(theta)]
        else:
            points = np.c_[width * np.sin(theta), rise * (1 - np.cos(theta))]
    elif kind == 'ogee':
        n = max(1, math.ceil(math.pi / 4 * math.sqrt(abs(rise) / tolerance)))
        s = np.linspace(0, 1, n + 1)
        points = np.c_[width * s, rise * (1 - np.cos(math.pi * s)) / 2]
    else:
        points = np.array([[0.0, 0.0], [width, rise]])
    points[0], points[-1] = (0.0, 0.0), (width, rise)
    return points

def profile_polyline(elems, L, nseg=6, *, tolerance=None):
    """Legacy output when tolerance=None; bounded analytic sampling otherwise."""
    total = sum(L(e[2]) for e in elems if e[0] in SHAPES)
    d, drop, pts = 0.0, total, [(0.0, total)]
    for e in elems:
        kind, width = e[0], L(e[1])
        if not math.isfinite(width) or width <= 0:
            raise ValueError('profile width must be finite and positive')
        if kind == 'fillet':
            d += width
            pts.append((d, drop))
        elif kind == 'groove':
            pts += [(d + width / 2, drop + L(e[2])), (d + width, drop)]
            d += width
        elif kind in SHAPES:
            rise = L(e[2])
            if not math.isfinite(rise) or rise < 0:
                raise ValueError('profile rise must be finite and nonnegative')
            if tolerance is None:
                n = 1 if kind == 'chamfer' else nseg
                samples = [(width * i / n, rise * SHAPES[kind](i / n)) for i in range(1, n + 1)]
            else:
                samples = curved_points(kind, width, rise, tolerance)[1:]
            pts.extend((d + x, drop - y) for x, y in samples)
            d, drop = d + width, drop - rise
        else:
            raise ValueError(f'unknown profile element {kind}')
    points = np.array(pts)
    if abs(points[-1, 1]) < 1e-12:
        points[-1, 1] = max(points[-1, 1], 0.0)
    return points
