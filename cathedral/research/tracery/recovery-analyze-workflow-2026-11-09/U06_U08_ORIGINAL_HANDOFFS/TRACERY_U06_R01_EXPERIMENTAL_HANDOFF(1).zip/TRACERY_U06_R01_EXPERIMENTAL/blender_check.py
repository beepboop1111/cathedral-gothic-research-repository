"""Blender-only validation: strict exit codes, no render in QA-only mode."""
import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree

def bounds(points):
    return [[min(v[i] for v in points) for i in range(3)],
            [max(v[i] for v in points) for i in range(3)]]

def check_model(manifest, compatibility=False):
    path=Path(manifest)
    data=json.loads(path.read_text())
    required=bpy.app.version >= (5,1,0)
    runtime_ok=required or (compatibility and bpy.app.version >= (4,3,0))
    result=dict(blender=bpy.app.version_string,required_blender='5.1+',
        required_blender_satisfied=required,compatibility_only=not required,
        all_ok=False,parts={},assembly={},errors=[],
        coverage='World bounds, counts, manifold topology, degenerate and duplicate faces; BVH self pairs exclude shared vertices; stone-pair intersections tested separately.')
    if not runtime_ok:
        result['errors'].append('Blender 5.1+ required; compatibility mode must be explicitly requested for an older runtime')
        return result,[]
    if not data.get('checks') or not all(c['ok'] for c in data['checks']):
        result['errors'].append('Python QA is missing or contains failed checks')
        return result,[]
    glb=path.parent/data['geometry']
    if hashlib.sha256(glb.read_bytes()).hexdigest()!=data['geometry_sha256']:
        result['errors'].append('GLB checksum does not match manifest')
        return result,[]
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.scene.unit_settings.system='METRIC'
    bpy.context.scene.unit_settings.scale_length=1.0
    bpy.ops.import_scene.gltf(filepath=str(glb))
    bpy.context.view_layer.update()
    objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
    trees={}
    for obj in objects:
        name=obj.name.split('__',1)[-1]
        if name not in data['parts'] or name in result['parts']:
            result['errors'].append(f'unexpected or duplicate part {name}')
            continue
        bm=bmesh.new();bm.from_mesh(obj.data);bm.transform(obj.matrix_world)
        bm.verts.ensure_lookup_table();bm.faces.ensure_lookup_table()
        bb=bounds([v.co for v in bm.verts])
        size=max(b-a for a,b in zip(*bb))
        tree=BVHTree.FromBMesh(bm,epsilon=0.0)
        pairs=tree.overlap(tree)
        nonadjacent=sum(1 for i,j in pairs if i<j and
            not set(v.index for v in bm.faces[i].verts).intersection(v.index for v in bm.faces[j].verts))
        face_keys=[tuple(sorted(v.index for v in f.verts)) for f in bm.faces]
        expected=data['parts'][name]
        r=dict(vertices=len(bm.verts),faces=len(bm.faces),bounds_m=bb,
            nonmanifold_edges=sum(not e.is_manifold for e in bm.edges),
            nonmanifold_vertices=sum(not v.is_manifold for v in bm.verts),
            degenerate_faces=sum(f.calc_area()<1e-12*size*size for f in bm.faces),
            duplicate_faces=len(face_keys)-len(set(face_keys)),nonadjacent_self_pairs=nonadjacent)
        r['counts_match']=(r['vertices']==expected['vertices'] and r['faces']==expected['faces'])
        r['bounds_match']=all(abs(a-b)<=1e-6 for a,b in zip(sum(bb,[]),sum(expected['bounds_blender_m'],[])))
        r['ok']=(r['counts_match'] and r['bounds_match'] and r['degenerate_faces']==0
            and r['duplicate_faces']==0 and nonadjacent==0
            and (name=='glass' or (r['nonmanifold_edges']==r['nonmanifold_vertices']==0)))
        result['parts'][name]=r
        if name.startswith('stone_'):
            trees[name]=(tree,bb)
            obj.data.shade_smooth();obj.data.set_sharp_from_angle(angle=math.radians(32))
        bm.free()
    collision_pairs=[];candidates=0
    names=sorted(trees)
    for i,a in enumerate(names):
        ta,ba=trees[a]
        for b in names[i+1:]:
            tb,bb=trees[b]
            if all(min(ba[1][k],bb[1][k])>max(ba[0][k],bb[0][k]) for k in range(3)):
                candidates+=1
                intersections=ta.overlap(tb)
                if intersections:
                    collision_pairs.append(dict(a=a,b=b,face_pairs=len(intersections)))
    result['assembly']=dict(stone_pair_candidates=candidates,stone_surface_collision_pairs=collision_pairs,
        scope='Stone-to-stone surfaces; wall contacts and structural bearing capacity not assessed.')
    result['all_ok']=(not result['errors'] and set(result['parts'])==set(data['parts'])
                      and all(r['ok'] for r in result['parts'].values()) and not collision_pairs)
    return result,objects

def render_preview(folder,objects):
    scene=bpy.context.scene
    world=bpy.data.worlds.new('U06 review world');world.use_nodes=True
    world.node_tree.nodes['Background'].inputs[0].default_value=(.86,.87,.89,1)
    world.node_tree.nodes['Background'].inputs[1].default_value=.65
    scene.world=world
    light=bpy.data.lights.new('Raking sunlight','SUN');light.energy=2.6;light.angle=math.radians(8)
    obj=bpy.data.objects.new('Raking sunlight',light);scene.collection.objects.link(obj)
    obj.rotation_euler=Vector((.8,.6,-.8)).to_track_quat('-Z','Y').to_euler()
    camera_data=bpy.data.cameras.new('U06 review camera');camera_data.type='ORTHO'
    camera=bpy.data.objects.new('U06 review camera',camera_data);scene.collection.objects.link(camera)
    camera_data.clip_start,camera_data.clip_end=.01,100
    scene.camera=camera
    scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=32
    # Deterministic CPU path also works on builds without OpenImageDenoise.
    scene.cycles.use_denoising=False
    scene.render.film_transparent=True
    scene.render.image_settings.file_format='PNG'
    all_points=[o.matrix_world@Vector(c) for o in objects for c in o.bound_box]
    bb=bounds(all_points);lo,hi=map(Vector,bb);height=hi.z-lo.z
    target=(lo+hi)/2
    camera.location=target+Vector((7,-23,4));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
    camera_data.ortho_scale=height*1.13
    scene.render.resolution_x,scene.render.resolution_y=1000,1350
    scene.render.resolution_percentage=100
    scene.render.filepath=str(folder/'render_whole.png');bpy.ops.render.render(write_still=True)
    stones=[o for o in objects if '__stone_' in o.name]
    lo,hi=map(Vector,bounds([o.matrix_world@Vector(c) for o in stones for c in o.bound_box]))
    target=Vector(((lo.x+hi.x)/2,lo.y,lo.z+.82*(hi.z-lo.z)))
    camera.location=target+Vector((5,-23,3));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
    camera_data.ortho_scale=(hi.x-lo.x)*1.16
    scene.render.resolution_x,scene.render.resolution_y=1400,1000
    scene.render.filepath=str(folder/'render_head.png');bpy.ops.render.render(write_still=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(folder/'U06_EXPERIMENTAL_review.blend'))

def main():
    argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:]
    parser=argparse.ArgumentParser()
    parser.add_argument('manifest');parser.add_argument('--render',action='store_true')
    parser.add_argument('--compatibility-runtime',action='store_true')
    args=parser.parse_args(argv);folder=Path(args.manifest).resolve().parent
    try:
        result,objects=check_model(args.manifest,args.compatibility_runtime)
    except Exception as exc:
        result=dict(blender=bpy.app.version_string,all_ok=False,errors=[str(exc)])
        objects=[]
    (folder/'blender_QA.json').write_text(json.dumps(result,indent=2))
    print('U06_BLENDER',result['blender'],'all_ok',result['all_ok'])
    if not result['all_ok']:
        sys.exit(8)
    if args.render:
        render_preview(folder,objects)
    sys.exit(0)

if __name__=='__main__':
    main()
