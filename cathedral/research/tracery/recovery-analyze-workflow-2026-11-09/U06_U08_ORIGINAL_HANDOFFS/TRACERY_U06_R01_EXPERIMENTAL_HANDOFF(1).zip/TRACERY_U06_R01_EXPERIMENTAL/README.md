# Tracery U06 R01 — isolated reliability pass

**EXPERIMENTAL. No cathedral geometry is approved or replaced by this package.**

Parent: `universal-generator-U01-U05-2026-11-07(2).zip`, SHA-256
`411c740189cab347cd02a6b717a5e6ec9781f64b26d739beaf90975e9e876e7a`.
Original U01–U05 files and results remain untouched. This package contains isolated
copies of four engine modules, a small reliability layer, explicit inputs, portable
regression fixtures, tests, measured output, and a review scene.

## What changed

- All three engine GLB export paths use one exporter. Physical source millimetres
  become glTF metres exactly once. Raw geometry remains in its source coordinates.
  Every exported vertex and world transform is checked, and the wall width is
  independently checked from span + frame + wall-margin inputs.
- Units are structured data in `config/units.json`. Source pixels require a positive
  calibration and evidence before architectural GLB export. Historical St-Leu pixels
  remain uncalibrated; the missing original historical STL regression is unresolved.
- Required QA failures return nonzero status. Failed candidate files remain under
  `candidate/` for diagnosis; they are never promoted to `geometry.glb` at the output root.
  Existing output checkpoints cannot be overwritten.
- Profiles use a conservative chord-error bound, rather than six fixed segments.
  Quarter-circle/ellipse and cosine-ogee curves use analytic bounds. Fillets,
  chamfers, and the original triangular groove retain their specified straight edges.
  Default section tolerance is **0.25 source mm**; XY construction tessellation is
  still the original **0.5 mm**. Those are different error budgets, not a combined
  0.25 mm guarantee for every 3D surface. Dense independent profile samples are tested.
- Stone footprints are checked both against recovered parent block plans and against
  the actual meshed surfaces. The rose exposed triangles outside concave block domains:
  centroid domain filtering removes these faces. A post-mesh footprint check rejects
  any remaining leakage or missing material. Boundary vertices are protected during welding.
- The archived rose GLB itself had protrusions up to about **2.289 mm** outside the
  intended parent plans. U06 preserves the source layout and removes erroneous material;
  it does not copy those mesh defects into the regression baseline. Before/after
  deviations are recorded in each manifest. Parent plans were recovered with the
  **unmodified original generator**, skipping only its final jointed 3D mesh stage.
- Python tests cover bad opening counts, uncalibrated units, count mismatches, overlapping
  closed stones, physical SVG scale, and an outside cell in a concave triangulation.
  Blender checks object topology and stone-to-stone surface collisions independently.
- One CLI replaces the staged runner chain for U06. A content-addressed **per-model**
  cache reuses generated GLB/SVG/construction data when inputs, engine/QA code,
  dependencies, and fixtures match. Blender re-import QA still runs on every invocation.
  Separate reusable construction/section/joint caches are a future extension, not claimed here.
- `--render` is explicit. QA-only commands create no PNG or Blender review scene.
  SVGs include true analytic arch paths and circular construction, with separately
  labelled tolerance-sampled boolean contours; physical SVG dimensions are explicit.
  The original construction record retains its six-decimal derived coordinate precision.

## Run

Use Python 3.12+ with the pinned dependencies, and the Blender application:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python tracery.py build --out out/my_first_checkpoint --render
```

The default requires **Blender 5.1+**. On a 4.3–5.0 installation, a bounded experiment
can be run explicitly:

```bash
python tracery.py build --out out/compatibility_check --compatibility-runtime --render
```

That command records `EXPERIMENTAL_COMPATIBILITY_PASS`, with
`required_blender_satisfied: false`; it does not certify Blender 5.1+ compatibility.
Without the override, an older Blender produces a failed checkpoint and no promoted GLB.

Choose a model with `--model`: `bar_2light_sexfoil`, `bar_4light_recursive`,
`intersecting_3light`, or `rose_12_chassis`. To validate an existing checkpoint:

```bash
python tracery.py validate out/my_first_checkpoint/manifest.json
```

For source-compatibility studies, `--profile-mode legacy` retains the old section
sampling. It still uses corrected units, strict QA, and the repaired domain filter.
`--profile-tolerance` is in the declared source unit. Use separate output directories;
the command refuses to overwrite an existing manifest. There are no GitHub operations.

## Output and coordinate contract

- `geometry.glb`: metres, X right / Y up / Z depth; Blender imports Z up.
- `source.svg`: confirmed specified geometry black, construction dashed gray,
  uncertain layer dashed red. “Confirmed” describes the input geometry, not historical approval.
- `construction.json`: original analytic construction record and semantic identities.
- `manifest.json`: exact raw inputs, versions, cache key, SHA-256, QA and measurements.
- `blender_QA.json`: actual imported bounds, per-part checks, collision results and runtime limits.
- `U06_EXPERIMENTAL_review.blend`, `render_whole.png`, `render_head.png`: only with `--render`.

The review scene keeps metre-scale objects intact; the camera is adjusted for display.
Any diagnostic failure folders included in the archive are evidence, not deliverable models.

## Validation boundaries

Technical and geometric checks do not constitute architectural, historical, or
structural sign-off. Depths, profiles, courses and joints remain trial values.
The intersecting study retains an inherited roughly **0.021 mm** closest hairline
separation; this is flagged for review, not silently represented as a satisfactory
6 mm architectural joint. Wall bearing/contact capacity and mortar are not assessed.
BVH self-intersection checks exclude faces sharing a vertex; independent footprint,
height-field, topology and assembly checks supplement that limited test.

The four repaired M02/M03 windows, Brandon M04 research, approved vault generators,
F5ZK-C, F5ZN-A, Pass 6J and the unresolved F5ZL-C support schedule are outside this change.

See `QA_SUMMARY.json`, `HANDOFF.md`, `BASELINE.json`, and `ENGINE_CHANGES.patch`.
