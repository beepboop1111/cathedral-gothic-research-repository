"""Python checks and independent physical/export measurements."""
import hashlib
import io
import json
import numpy as np
import shapely
import trimesh
from shapely.geometry import LineString
from pathlib import Path

from u06_export import metres_per_unit
from u06_profiles import SHAPES, profile_polyline
import tracery_universal_U01 as T

def check(name, ok, kind='geometric', detail=None):
    return dict(name=name, ok=bool(ok), kind=kind, detail=detail)

def array_hash(mesh):
    h = hashlib.sha256()
    h.update(np.asarray(mesh.vertices, dtype='<f8').tobytes())
    h.update(np.asarray(mesh.faces, dtype='<i8').tobytes())
    return h.hexdigest()

def profile_error(elems, tolerance):
    """Independent dense samples of each analytic segment against its polyline."""
    results = []
    for element in elems:
        if element[0] not in ('roll', 'hollow', 'ogee'):
            continue
        kind, width, rise = element
        points = profile_polyline([element], float, tolerance=tolerance)
        x = np.linspace(0, width, 20001)
        y = np.array([rise * (1 - SHAPES[kind](t / width)) for t in x])
        error = float(shapely.distance(shapely.points(np.c_[x, y]), LineString(points)).max())
        results.append(dict(kind=kind, width=width, rise=rise, segments=len(points)-1,
                            max_error=error, tolerance=tolerance))
    return results

def projected_footprint(meshes):
    faces=[]
    for mesh in meshes:
        p=mesh.triangles[:,:,:2]
        a,b=p[:,1]-p[:,0],p[:,2]-p[:,0]
        signed=a[:,0]*b[:,1]-a[:,1]*b[:,0]
        faces.extend(shapely.polygons(p[signed>1e-8]))
    return shapely.union_all(faces)

def measure_jointed(j):
    tests = [dict(c) for c in j.m.checks] + [dict(c) for c in j.u.checks] + [dict(c) for c in j.checks]
    parts = {}
    mesh_footprint_errors=[]
    factor = metres_per_unit(j.m.spec)
    for name, mesh, _, _ in j.parts:
        qa = T.mesh_qa(mesh)
        bounds = mesh.bounds * factor
        parts[name] = dict(vertices=len(mesh.vertices), faces=len(mesh.faces),
            bounds_m=bounds.tolist(), bounds_blender_m=[
                [bounds[0,0], -bounds[1,2], bounds[0,1]],
                [bounds[1,0], -bounds[0,2], bounds[1,1]]],
            source_hash=array_hash(mesh), source_qa=qa)
        if name != 'glass':
            ok = (qa['watertight'] and qa['winding_consistent'] and qa['volume'] > 0
                  and qa['nonmanifold_edges'] == qa['degenerate_faces'] == qa['unreferenced_vertices'] == 0
                  and qa['bodies'] == 1)
            if name.startswith('stone_'):
                md = j.meta[name]
                vmin = sum(2 * (j.u.order_of(k)['H'] - j.u.order_of(k)['prof'][:,1].max()) * area
                           for k, area in md['label_areas'].items())
                vmax = sum(2 * j.u.order_of(k)['H'] * area for k, area in md['label_areas'].items())
                ok &= qa['euler'] == 2 - 2 * md['holes'] and vmin * (1-1e-9) <= qa['volume'] <= vmax * (1+1e-9)
                planned=next(b['poly'] for b in j.blocks if b['name']==name)
                actual=projected_footprint([mesh])
                err=float(shapely.hausdorff_distance(planned.boundary,actual.boundary))
                mesh_footprint_errors.append(dict(name=name,boundary_error=err,
                    extra_area=actual.difference(planned).area,missing_area=planned.difference(actual).area))
            tests.append(check(f'{name}: closed, one body, winding, genus and volume', ok))
    footprint_limit=max(.02*j.m.tol,1e-9*j.m.size)
    tests.append(check('every exported stone follows its planned footprint',
        all(r['boundary_error']<=footprint_limit for r in mesh_footprint_errors),detail={
            'max_boundary_error':max(r['boundary_error'] for r in mesh_footprint_errors),
            'limit':footprint_limit,'offending_stones':[r for r in mesh_footprint_errors if r['boundary_error']>footprint_limit]}))
    # Jointed stones have disjoint XY footprints. Their extruded height fields therefore
    # cannot collide if the footprints are disjoint; this is an assembly check across stones.
    max_overlap, closest, candidates = 0.0, float('inf'), 0
    polygons = [b['poly'] for b in j.blocks]
    tree = shapely.STRtree(polygons)
    for i, a in enumerate(polygons):
        for k in tree.query(a.buffer(j.jw * 1.25)):
            k = int(k)
            if k <= i:
                continue
            b = polygons[k]
            candidates += 1
            max_overlap = max(max_overlap, a.intersection(b).area)
            closest = min(closest, a.distance(b))
    tests.append(check('all stone footprints have disjoint interiors', max_overlap <= 1e-8,
                       detail={'max_overlap_source_area':max_overlap, 'candidate_pairs':candidates}))
    tests.append(check('stone-to-stone clearance is positive', closest > 1e-6,
                       detail={'minimum_clearance_source_units':closest,
                               'note':'Measures actual closest clearance, not a structural bearing assessment.'}))
    profiles = []
    if j.u.section.get('profile_sampling') == 'adaptive':
        tol = j.u.section['profile_tolerance']
        for order, settings in enumerate(j.u.section['orders']):
            profiles.extend(dict(order=order, **p) for p in profile_error(settings['profile'], tol))
        tests.append(check('analytic moulding samples satisfy profile tolerance',
                           all(p['max_error'] <= p['tolerance'] * (1+1e-9) for p in profiles), detail=profiles))
    return tests, parts, dict(profiles=profiles, minimum_stone_clearance=closest,
        max_stone_overlap_area=max_overlap, stone_count=len(j.blocks),meshed_footprint_errors=mesh_footprint_errors,
        narrow_clearance_review=closest<j.jw/2)

def footprint_regression(j, fixture):
    """Compare against archived GLB vertices, retaining their known source-mm basis.

    The parent GLBs' *declared* metres were erroneous. Their raw vertex values
    are compared in source mm here; this is not a physical interpretation of them.
    """
    fixture=Path(fixture)
    hashes=json.loads((fixture.parent/'SHA256.json').read_text())
    plan_path=fixture.with_name(f'{j.m.id}_planned_U05.json')
    valid=all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in (fixture,plan_path))
    if not valid:
        return [check('archived regression fixture checksum',False,'technical')]
    scene=trimesh.load(fixture,force='scene',process=False)
    old=projected_footprint([mesh for name,mesh in scene.geometry.items() if '__stone_' in name])
    new=projected_footprint([mesh for name,mesh,_,_ in j.parts if name.startswith('stone_')])
    old_plan=json.loads(plan_path.read_text())
    plan=shapely.union_all([shapely.from_wkt(b['wkt']) for b in old_plan['blocks']])
    current_plan=shapely.union_all([b['poly'] for b in j.blocks])
    plan_error=float(shapely.hausdorff_distance(plan.boundary,current_plan.boundary))
    error=float(shapely.hausdorff_distance(plan.boundary,new.boundary))
    old_error=float(shapely.hausdorff_distance(plan.boundary,old.boundary))
    limit=2*np.finfo(np.float32).eps*j.m.size
    area_error=plan.symmetric_difference(new).area
    ok=error<=limit and area_error<=(plan.length+new.length)*limit
    return [check('archived regression fixture checksum',True,'technical'),
            check('all planned stone footprints unchanged from recovered U05 plans',
                plan_error<=1e-8 and [b['name'] for b in j.blocks]==[b['name'] for b in old_plan['blocks']],
                detail={'plan_boundary_error':plan_error}),
            check('meshed stone footprint follows recovered U05 design',ok,
                detail={'new_mesh_max_boundary_error':error,'archived_mesh_max_boundary_error':old_error,
                        'float32_limit':limit,'area_difference':area_error,
                        'note':'U06 clips triangulation to the original block domain; archived mesh protrusions are recorded, not adopted as source design.'})]

def check_export(data, j, parts):
    scene = trimesh.load(io.BytesIO(data), file_type='glb', process=False, force='scene')
    factor = metres_per_unit(j.m.spec)
    expected = {f'{j.m.id}__{name}':mesh for name,mesh,_,_ in j.parts}
    tests = [check('GLB contains exactly the expected parts', set(scene.geometry) == set(expected), 'technical')]
    world_bounds = []
    for node in scene.graph.nodes_geometry:
        transform, name = scene.graph[node]
        mesh = scene.geometry[name].copy()
        mesh.apply_transform(transform)
        source = expected[name]
        ok = (np.array_equal(mesh.faces, source.faces) and len(mesh.vertices) == len(source.vertices)
              and np.allclose(mesh.vertices, source.vertices*factor, atol=1e-6, rtol=0))
        tests.append(check(f'{name}: GLB world coordinates in metres and faces preserved', ok, 'technical'))
        world_bounds.append(mesh.bounds)
    # This independent formula reads the declared clear span and frame/wall dimensions.
    spec = j.m.spec
    if spec.get('mode') == 'bar' and 'span' in spec['outline'].get('arch', {}):
        width = (spec['outline']['arch']['span'] + 2*spec['outline']['frame'] + 2*spec['wall']['margin']) * factor
        wall_name = f'{j.m.id}__wall'
        transform, _ = scene.graph[wall_name]
        wall = scene.geometry[wall_name].copy();wall.apply_transform(transform)
        tests.append(check('physical wall width matches independent input dimension formula',
                           abs(wall.extents[0] - width) < 1e-6, detail={'expected_m':width,'actual_m':wall.extents[0]}))
    return tests

def all_pass(checks):
    return bool(checks) and all(c.get('ok') is True for c in checks)
