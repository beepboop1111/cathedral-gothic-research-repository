# U06 R01 continuation checkpoint

Status: EXPERIMENTAL compatibility tests passed; no architectural approval or lock promotion.
Baseline is the original attached U01–U05 archive, identified by SHA-256 in `BASELINE.json`.
Existing cathedral geometry, approved generators, original scans, and prior archives were not edited.

## Completed

1. Unified GLB export at one physical-unit boundary; representative wall width is 4.120 m.
2. Required QA failures stop the command and block candidate promotion.
3. Tolerance-bounded moulding profiles, with independent dense analytic samples.
4. Portable hashed archived GLBs and original procedural block-plan fixtures for four physical families.
5. Actual mesh footprint, per-object Blender and cross-stone collision checks.
6. Repaired rose outside-domain triangles while retaining its recovered original block layout.
7. Explicit 1:1 physical SVG dimensions, analytic source arcs and labelled sampled contours.
8. Per-model content cache, QA-only operation, immutable output checkpoint folders.
9. Four models: 833/833 Python checks; 294/294 imported mesh objects pass in Blender 4.3.2.
10. Fourteen unit/regression/failure-path tests pass. A separate strict runtime test correctly
    rejects Blender below 5.1 and promotes no GLB. Cache reuse creates no renders.
11. The final representative GLB is byte-identical to the one checked on MR.COMPUTER in
    Blender 5.0.1: all 48 objects pass, no stone collisions flagged. Exhibit was launched
    with that file and its application process was observed; visual inspection was not automated.

Authoritative numeric results and limitations: `QA_SUMMARY.json` and the four `results/FINAL_*`
model manifests. `results/FINAL_STRICT_RUNTIME` is an intentional failed runtime gate, not a model.
`results/FINAL_CACHE_WARM` is a cache test. Only the two-light checkpoint has rendered views.

## Preserved parameters

Raw inherited specifications, profiles, orders, depths, joints and trial dimensions remain in
`config/`. `config/units.json` supplies explicit units; section profile tolerance is 0.25 mm.
The original 0.5 mm XY construction tolerance remains unchanged. Architectural model scale is 1:1.
GLB metre conversion does not change the physical design. Input and construction coordinates
remain recorded in their original units. The original construction-record rounding is retained
because joint generation reads it; raw JSON inputs retain their supplied precision.

U06 copies only the four source engine modules. The exact differences are in `ENGINE_CHANGES.patch`.
No new topology type or selected moulding profile was substituted.

## Next bounded work

Run the unchanged checkpoint on Blender 5.1+ without `--compatibility-runtime`. Recover the missing
historical St-Leu fixture and scale evidence as a separate source-research task. Review the inherited
0.021 mm intersecting-study hairline gap before calling those architectural joints satisfactory.
Keep F5ZL-C and structural capacity unresolved. If further speed is needed, add separate
construction/section/joint caches after profiling; the implemented cache is currently per model.

Do not regenerate the four repaired M02/M03 windows or approved cathedral generators to continue
this reliability pass. No GitHub operations are needed.
