#!/usr/bin/env python3
"""U06 single entry point: bounded build, strict QA, GLB, Blender check, optional render."""
import argparse
import copy
import hashlib
import importlib.metadata
import json
import math
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'engine'))
import numpy as np
import tracery_universal_U01 as T
import tracery_joints_U03 as J
from u06_export import metres_per_unit
from u06_qa import all_pass, check, check_export, measure_jointed, footprint_regression

VERSION = 'U06-R01-experimental'

def json_value(value):
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, indent=2, default=json_value, allow_nan=False))
    temporary.replace(path)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def files_hash(paths):
    h = hashlib.sha256()
    for path in sorted(paths):
        h.update(path.name.encode());h.update(path.read_bytes())
    return h.hexdigest()

def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',',':'), allow_nan=False).encode()).hexdigest()

def inputs(model_id, mode='adaptive', tolerance=0.25, override=None):
    specs = {s['id']:s for s in json.loads((ROOT/'config/specs_U05.json').read_text())}
    sections = json.loads((ROOT/'config/sections_U05.json').read_text())
    joints = json.loads((ROOT/'config/joints_U05.json').read_text())
    units = json.loads((ROOT/'config/units.json').read_text())
    spec, section, joint = copy.deepcopy(specs[model_id]), copy.deepcopy(sections[model_id]), copy.deepcopy(joints[model_id])
    spec['u06_units'] = units[model_id]
    section.update(profile_sampling=mode, profile_tolerance=tolerance)
    if override:
        spec.update(json.loads(Path(override).read_text()))
    return spec, section, joint

def validate_inputs(spec, section, joints):
    metres_per_unit(spec)  # refuses source pixels without evidence of calibration
    def finite(value):
        if isinstance(value, dict):
            return all(finite(x) for x in value.values())
        if isinstance(value, list):
            return all(finite(x) for x in value)
        return not isinstance(value, (int,float)) or isinstance(value, bool) or math.isfinite(value)
    if not all(finite(v) for v in (spec, section, joints)):
        raise ValueError('nonfinite input')
    if spec.get('tolerance',0) <= 0 or section['profile_tolerance'] <= 0:
        raise ValueError('curve and profile tolerances must be positive')
    for key in ('joint_width','course','voussoir','min_block'):
        if joints[key] <= 0:
            raise ValueError(f'{key} must be positive')
    if not section['orders'] or any(o['depth'] <= 0 for o in section['orders']):
        raise ValueError('orders must have positive depths')

def model_class(spec):
    if spec.get('type') == 'rose':
        import tracery_rose_U04 as R
        return R.RoseModel, R.RoseJointed
    return T.Model, J.Jointed

def write_svg(model, path):
    """Analytic arch arcs + circular construction; clipped opening contours are sampled.

    Distinguish the retained exact source primitives from the boolean contours, which
    remain at the explicitly recorded model tolerance rather than masquerading as arcs.
    """
    from xml.etree.ElementTree import Element, SubElement, ElementTree
    x0,y0,x1,y1=model.outline.bounds
    margin=(x1-x0)*0.06; sw=(x1-x0)/1100
    root=Element('svg',xmlns='http://www.w3.org/2000/svg',viewBox=f'{x0-margin} {-y1-margin} {x1-x0+2*margin} {y1-y0+2*margin}')
    try:
        mm_per_unit=1000*metres_per_unit(model.spec)
        root.set('width',f'{(x1-x0+2*margin)*mm_per_unit:.12g}mm')
        root.set('height',f'{(y1-y0+2*margin)*mm_per_unit:.12g}mm')
    except ValueError:
        pass  # Pixel studies retain pixel coordinates and acquire no physical scale.
    SubElement(root,'title').text=f'{model.id}: exact source arcs and tolerance-sampled boolean contours'
    SubElement(root,'metadata').text=json.dumps(dict(status='EXPERIMENTAL',units=model.spec['u06_units'],
        boolean_contour_tolerance=model.tol,construction_record_precision_source_units=0.000001,
        confirmed='specified generated geometry, not historical approval'))
    group=SubElement(root,'g',transform='scale(1,-1)')
    confirmed=SubElement(group,'g',id='confirmed',fill='none',stroke='black',**{'stroke-width':str(sw)})
    construction=SubElement(group,'g',id='construction',fill='none',stroke='#888888',
        **{'stroke-width':str(sw*.7),'stroke-dasharray':f'{sw*5} {sw*4}'})
    SubElement(group,'g',id='uncertain',fill='none',stroke='#c62828',**{'stroke-dasharray':f'{sw*5} {sw*4}'})
    for name,record in model.con['arches'].items():
        cl,cr=record['CL'],record['CR'];sl,sr,ap=record['spring_l'],record['spring_r'],record['apex']
        route=f'M {sl[0]} {sl[1]} A {cl[2]} {cl[2]} 0 0 0 {ap[0]} {ap[1]} A {cr[2]} {cr[2]} 0 0 0 {sr[0]} {sr[1]}'
        SubElement(confirmed,'path',id=f'arc_{name}',d=route,**{'data-centres':json.dumps([cl,cr])})
        # Long construction circles would overwhelm the measured window: show centres as crosses.
        for centre in (cl,cr):
            x,y,_=centre
            SubElement(construction,'path',d=f'M {x-sw*3} {y} h {sw*6} M {x} {y-sw*3} v {sw*6}')
    for name,record in model.con.get('circles',{}).items():
        circles=record if isinstance(record,list) else []
        if isinstance(record,dict):
            circles += [record[k] for k in ('centre_line','outer','inner') if k in record and isinstance(record[k],list)]
            if 'centre' in record and 'r_outer' in record:
                cx,cy=record['centre']
                circles += [[cx,cy,record['r_outer']],[cx,cy,record['r_outer']-record['band']]]
                circles += record.get('foil',{}).get('lobes',[])
        for k,c in enumerate(circles):
            if isinstance(c,list) and len(c)==3:
                SubElement(construction,'circle',id=f'circle_{name}_{k}',cx=str(c[0]),cy=str(c[1]),r=str(c[2]))
    for v in model.voids:
        coords=list(v['poly'].exterior.coords)
        route='M '+' L '.join(f'{x:.12g} {y:.12g}' for x,y in coords)+' Z'
        SubElement(confirmed,'path',id=f'opening_{v["id"]}',d=route,**{'data-representation':'sampled_boolean','data-tolerance':str(model.tol)})
    ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)

def run_blender(manifest, executable='blender', render=False, compatibility=False):
    args=[executable,'-b','--factory-startup','--python-exit-code','7','--python',str(ROOT/'blender_check.py'),
          '--',str(manifest)]
    if render:
        args.append('--render')
    if compatibility:
        args.append('--compatibility-runtime')
    completed=subprocess.run(args,capture_output=True,text=True)
    (Path(manifest).parent/'blender.log').write_text(completed.stdout+completed.stderr)
    return completed.returncode

def build(args):
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)
    if (out/'manifest.json').exists():
        raise ValueError('choose a new output directory; an existing checkpoint will not be overwritten')
    report=dict(version=VERSION,status='BUILDING',checks=[],protected_baseline='U01-U05 unchanged',
                approval='EXPERIMENTAL',validation=dict(historical='not assessed',structural='not assessed',architectural='trial rules only'))
    start=time.perf_counter()
    try:
        spec,section,joints=inputs(args.model,args.profile_mode,args.profile_tolerance,args.override)
        report['inputs']=dict(spec=spec,section=section,joints=joints)
        validate_inputs(spec,section,joints)
        versions={name:importlib.metadata.version(name) for name in ['numpy','scipy','shapely','trimesh','triangle']}
        code=files_hash(list((ROOT/'engine').glob('*.py'))+[ROOT/'tracery.py',ROOT/'u06_qa.py'])
        fixture=ROOT/'fixtures'/f'{args.model}_U05.glb'
        fixture_hash=dict(mesh=sha(fixture),registry=sha(ROOT/'fixtures/SHA256.json')) if fixture.exists() else None
        key=canonical_hash(dict(inputs=report['inputs'],code=code,fixture=fixture_hash,python=sys.version,dependencies=versions))
        report.update(cache_key=key,dependencies=versions,source_code_hash=code,cache_hit=False)
        cache=Path(args.cache).resolve()/key
        candidate=out/'candidate';candidate.mkdir()
        if (cache/'build.json').exists():
            stored=json.loads((cache/'build.json').read_text())
            if all((cache/name).is_file() and sha(cache/name)==digest for name,digest in stored['file_hashes'].items()):
                for name in stored['file_hashes']:
                    shutil.copy2(cache/name,candidate/name)
                report.update(checks=stored['checks'],parts=stored['parts'],metrics=stored['metrics'],cache_hit=True)
        if not report['cache_hit']:
            cls,jointed_cls=model_class(spec)
            pre=cls(spec)
            report['checks']=[dict(c) for c in pre.checks]
            if not all_pass(report['checks']):
                raise ValueError('construction preflight failed')
            model=jointed_cls(spec,section,joints)
            report['checks'],report['parts'],report['metrics']=measure_jointed(model)
            if fixture.exists():
                report['checks']+=footprint_regression(model,fixture)
            # Independent archived topology fixture for the representative two-light case.
            if args.model=='bar_2light_sexfoil':
                baseline=json.loads((ROOT/'fixtures/bar_2light_sexfoil_construction_U01.json').read_text())
                report['checks'].append(check('U01 opening identities and stone face area unchanged',
                    [v['id'] for v in model.m.voids]==[v['id'] for v in baseline['openings']]
                    and abs(model.m.stone.area-baseline['stone_face_area']) < 1e-5))
            if not all_pass(report['checks']):
                raise ValueError('geometric or trial architectural QA failed before export')
            data=model.export_glb(candidate/'geometry.glb')
            report['checks']+=check_export(data,model,report['parts'])
            if not all_pass(report['checks']):
                raise ValueError('GLB export QA failed')
            write_svg(model.m,candidate/'source.svg')
            write_json(candidate/'construction.json',model.m.record())
            cache.mkdir(parents=True,exist_ok=True)
            names=['geometry.glb','source.svg','construction.json']
            for name in names:
                shutil.copy2(candidate/name,cache/name)
            write_json(cache/'build.json',dict(checks=report['checks'],parts=report['parts'],metrics=report['metrics'],
                       file_hashes={name:sha(cache/name) for name in names}))
        report.update(status='AWAITING_BLENDER',geometry='candidate/geometry.glb',
                      geometry_sha256=sha(candidate/'geometry.glb'),elapsed_build_seconds=time.perf_counter()-start)
        write_json(out/'manifest.json',report)
        rc=run_blender(out/'manifest.json',args.blender,args.render,args.compatibility_runtime)
        if rc:
            raise ValueError(f'Blender validation failed (exit {rc}); see blender_QA.json and blender.log')
        blender=json.loads((out/'blender_QA.json').read_text())
        if not blender.get('all_ok'):
            raise ValueError('Blender reported failed checks')
        for name in ['geometry.glb','source.svg','construction.json']:
            (candidate/name).replace(out/name)
        candidate.rmdir()
        report.update(status='EXPERIMENTAL_COMPATIBILITY_PASS' if blender['compatibility_only'] else 'EXPERIMENTAL_QA_PASS',
                      geometry='geometry.glb',blender=blender['blender'],
                      required_blender_satisfied=blender['required_blender_satisfied'],all_ok=True,
                      elapsed_total_seconds=time.perf_counter()-start)
        write_json(out/'manifest.json',report)
        print(json.dumps(dict(status=report['status'],cache_hit=report['cache_hit'],
            checks=len(report['checks']),meshes=len(report['parts']),seconds=round(report['elapsed_total_seconds'],2))))
        return 0
    except Exception as exc:
        report.update(status='FAILED',all_ok=False,error=str(exc),elapsed_total_seconds=time.perf_counter()-start)
        write_json(out/'manifest.json',report)
        print(f'FAILED: {exc}',file=sys.stderr)
        return 2

def parser():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='command',required=True)
    p=sub.add_parser('build')
    p.add_argument('--model',default='bar_2light_sexfoil')
    p.add_argument('--out',required=True)
    p.add_argument('--cache',default=str(ROOT/'.cache'))
    p.add_argument('--blender',default='blender')
    p.add_argument('--render',action='store_true')
    p.add_argument('--compatibility-runtime',action='store_true',help='allow Blender 4.3–5.0 for a labelled experiment; default requires 5.1+')
    p.add_argument('--profile-mode',choices=['legacy','adaptive'],default='adaptive')
    p.add_argument('--profile-tolerance',type=float,default=0.25,help='profile chord error, in model input units')
    p.add_argument('--override',help='JSON object overriding isolated experiment inputs; never changes saved specs')
    p=sub.add_parser('validate')
    p.add_argument('manifest')
    p.add_argument('--blender',default='blender')
    p.add_argument('--render',action='store_true')
    p.add_argument('--compatibility-runtime',action='store_true')
    return ap

if __name__=='__main__':
    args=parser().parse_args()
    try:
        rc=build(args) if args.command=='build' else run_blender(Path(args.manifest).resolve(),args.blender,args.render,args.compatibility_runtime)
    except Exception as exc:
        print(f'FAILED: {exc}',file=sys.stderr);rc=2
    sys.exit(rc)
