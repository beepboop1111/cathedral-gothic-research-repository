# One-page architecture brief — enormous F5ZP east end

**Guiding architectural question:** How can the cathedral support an unusually immense chevet without producing an ungainly slab or isolating its chapels from the building's main Gothic rhythm?

**Design answer:** Two readable outlines. The lower, actual masonry outline contains three eastern ambulatory layers and a family of graduated chapel projections. The largest chapel at 90° is a miniature sanctuary with two long bays and a polygonal apse; the northeast and southeast companions each have a generous single bay and apse; lateral chapels diminish back toward the choir. Their entrances are coordinated, but each chapel remains an identifiable sacred space. The axial entrance remains exceptional, without a central ground pier interrupting it.

The higher, outward **skeletal outline** surrounds this masonry mass with *freestanding* high buttress towers and long flyers, possibly doubled near the choir and chevet. Its ribs, openings and interstices must preserve visible windows, roofs and chapels. The towers frame the axial chapel from the flanks; they do not fill each apse recess or create a solid curtain. This lattice widens the perceived building and suggests further aisles while preserving open air.

**Long view, west to east:** the nave fixes the main module; the crossing reads as a spacious center; the last choir bays progressively spread the perceived external support system; the seven-sector chevet fans out and culminates at a dominant axial projection nested within the two flanking towers. The buttress crown should look structurally plausible *without* falsely claiming load-path validation.

**Composition to continue:** R07 original orange axial plan (unshifted, 600-unit threshold) remains the datum. Test B (companions at 50° and 130°; wider gaps) alongside A (70° and 110°; grouped entrance) before choosing stations. Test attached **local receiving walls** for low vault ribs separately from outer **freestanding buttress towers**. Do not apply early Eastern_Chapels_R01 fixed positions or provisional height numbers to R07.

**Presentation next:** paired 1:1 entire-cathedral plans of A/B; a chevet-level plan highlighting open gaps, glazing and tower reservations; long north/south perspective and straight-on axial view against actual choir roof silhouettes; numerical clearance and bearing report; approval gates clearly marked. Keep heights and actual flyers outside the *current plan-only* milestone unless authorized as a new separate experimental section study.

**Status:** the architectural vision is user-preferred and documented; the exact buttress locations, joins, heights, flyers, load paths and station choice remain unapproved and require further evidence.


**Vertical proportions — source preservation (R02):** Protected inner/middle chevet vault stack uses spring Z3000, boss Z4296, upper web Z4394, gallery soffit Z4425, floor Z4521. The distinct axial two-bay design lock selects bosses Z4250, roof eaves Z4400 and continuous ridge Z5100→Z5250, subject to checking actual choir roof and bearing geometry. *No approved numeric heights for companion chapels, smaller chapels, new lower ring or freestanding towers.* Their composition and open silhouette remain the design intent; see R02 height annex for superseded trial values.
