# START THE NEXT CHAT — F5ZP INTEGRATED EAST-END ARCHITECTURE

Use both HANDOFF.md (this package) and the bundled **R07 Portable Handoff ZIP** plus the F5ZE full cathedral dimensions addendum.

**Work goal:** continue the enormous chevet as ONE composition of chapel masonry, visible windows and roofs, clear exterior recesses, freestanding high buttress towers, long/double-tier flying arches, and properly located **local** receiving walls/engaged piers. Preserve the preferred two-outline silhouette and gradual expansion from choir shoulders to an axial culmination.

**Do not conflate variants:** B 50°/90°/130° is preferred after R21's limited comparison but not locked; A 70°/90°/110° remains a grouped entrance study. The R07 unshifted axial chapel footprint is the active experimental PLAN reference. Do not paste R01 trial tower positions (30500, ±2600) onto R07 without new 1:1 fit checks.

**Start with plan:** inspect the exact current F5ZN-A reference, R07 and F5ZE grid; compare A/B companion chapels and outward tower/flyer reservations on full-cathedral plan; measure visible recesses and actual passage boundaries. Save separate trial variants and numerical QA. No unverified heights; preserve the separately documented two-bay roof design lock until a dedicated section pass.

**Protected:** F5ZK-C, F5ZN-A, working inner/middle vault generator, original V13 webs, Pass 6J, original R03 chapel, and current R07 source; do not reinstate discarded L01–L14; F5ZL-C remains missing. No architectural/structural approval or destructive source change without the appropriate source and approval.

**Mandatory distinction:** technical mesh or local geometric contact passes are NOT proof of historical authenticity, whole-cathedral fit, or a load-bearing stone structure.


**R02 HEIGHT ADDENDUM:** Before designing new 3D architecture, read `06_height_recovery/HEIGHTS_RECOVERY_AND_AUTHORITY.md`. Protect AMB-I/M spring Z3000, boss Z4296, web Z4394 and gallery floor Z4521; preserve the separately user-accepted axial chapel twin-boss Z4250 and roof eaves Z4400 / ridges Z5100→Z5250 design target. **Do not invent numeric heights for the new lower third layer, companion NE/SE chapels, apse roof, smaller chapels or freestanding towers.** Older R03 and early R01 heights are comparisons only. R07 orange plan remains unmodified.
