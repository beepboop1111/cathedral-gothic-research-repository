# F5ZP — Chevet / chapels height recovery addendum R02

**Status:** source-derived vertical height register, NOT a new architecture approval. All measurements are in 1:1 native project units. The original F5ZK-C checkpoint uses vertical `y` field labels from a historical coordinate convention; the values are displayed here as Blender **Z elevation**. No metres-per-native-unit conversion is established.

## 1. Protected inner and middle chevet vault rings

The saved `CATHEDRAL_F5ZK_C_CURVED_CHEVET_AMBULATORY_IDENTITY.json` (SHA-256 `d1185e4a2fe9c92b12a3e544fddca32bf65650257cfddc28137002d8e819fa85`) documents the SAME common low-storey vertical stack for both **AMB-I** and **AMB-M**:

| Feature | Z elevation | Classification |
|---|---:|---|
| Tas-de-charge bottom | 2616 | Documented construction set-out (four 96-unit courses, to spring) |
| Springing | **3000** | Protected original low chevet-ring reference |
| Boss / rib crown | **4296** | Protected original low chevet-ring reference |
| Upper web reference | 4394 | Documented vault-web reference; not proof of real web clearance |
| Gallery soffit | 4425 | Documented gallery set-out; local web-to-soffit nominal difference 31 |
| Gallery floor | **4521** | Protected low-storey vertical datum |

These two families have 7 bays apiece and unchanged saved reference geometry. The source also provides per-bay doubleau and boundary arch apex elevations; see `F5ZK_C_PROTECTED_INNER_MIDDLE_BAY_ARCH_APEXES.csv`. AMB-I radial doubleau apex is Z3832; AMB-M Z3864. **These are arch apexes, not vault boss elevations.**

`F5ZN_A_COMPREHENSIVE_FLOOR_PLAN_CHECKPOINT.json` (SHA-256 `97014cf07fccf1d5ed91e78b5cb20d557d55931cfd706921d46342a35dabb352`) independently lists low-storey spring 3000, boss 4296, gallery floor 4521. It also lists **a distinct high-storey** spring 13500 and ordinary choir boss 16225, and a high-storey gallery-floor entry of 4950. Its own warning flags the 4521/4950 disagreement: do not merge stacks, average values or claim this conflict is resolved. The high-storey values are recovered compiled references, NOT freshly approved high-choir structure.

### Critical outer ring distinction

The old F5ZK-C **AMB-O** family was recorded with spring 3000 and boss 4296, but this applies to the **former ring geometry**, which was discarded as a live design constraint. It cannot authorize the current *third-layer, fourteen-lower-vault* concept.

The later 2D `F5ZP_Third_Layer_14_Low_Vaults_2D_R01_EXPERIMENTAL/README.md` (SHA-256 `321742af3b73397e7f83b035623f8e6547f708152fc3b1ff00d7ce1da1376169`) expressly says **no third-layer spring, crown or window head/sill elevation is selected**, and its plotted proportions are dimensionless. Earlier trial outer spring Z2300, apex Z3550 and two crown targets Z3900 / Z3980 belong to R13/R20 experimental studies, **not approved** third-ring heights. This distinction preserves the request that the new outer ring be *significantly lower*, without inventing an exact number or reviving rejected entrance/window constraints.

## 2. Axial chapel: user-accepted separate design lock

The MR COMPUTER source `AXIAL_CHAPEL_DESIGN_LOCK_R01.md` (SHA-256 `f7a52d6685145a9c0375da7a4b2f6983c3227cb48b3d3a43466f9e52721f36db`) records the user's explicit instruction "okay just lock that and move on please" for the two rectangular chapel bays and their continuous trial roof:

| Component | Elevation | Authority / caveat |
|---|---:|---|
| Chapel bay 1 boss, X28600–31000 | **4250** | User-accepted design lock for that study |
| Chapel bay 2 boss, X31000–33400 | **4250** | Same equal-height design lock |
| Both bay springings | 1800 | Recorded for study, explicitly subject to actual bearing reconciliation |
| Continuous roof eaves | **4400** | User-accepted roof design target |
| Continuous roof ridge, west | **5100** | User-accepted roof design target |
| Continuous roof ridge, east | **5250** | User-accepted roof design target |

**This lock does not cover:** axial apse roof, companion chapel heights, buttress tower heights, approved generator output or verified actual choir-roof relationship. The roof must remain *visually subordinate to the main choir*, but actual 3D clearance against the real choir roof remains unverified. Do not silently overwrite either R03 or F5ZN-A originals.

The **older original R03** chapel (technically repaired for winding/export in R04 without vertex changes) instead had ambulatory approach boss Z3620, Bay 1 boss Z4150, Bay 2 boss Z4400, apse boss Z4550, entrance soffit crown Z3750 and entrance back crown Z3923.328125. These values are retained *as historical experimental evidence*, not combined with the later Z4250 equal-bay lock. **No new approval for an apse vault crown has been found.**

The separate R06 approach experiment set a trial raised boss Z4296, which is coincident in elevation with the protected ring boss but **did not resolve** legitimate 3D bearings. It is excluded from automatic height application to the R07 plan.

## 3. Companion chapels, smaller chapels, outer towers — heights NOT approved

The early `Eastern_Chapels_R01_EXPERIMENTAL` source QA (SHA-256 `f16212f083db150ac568ebee59440423bbad206d2607df3c0c59d32f0814b3da`) records for **north and south companion chapels**: eaves Z2700 and roof ridge Z3200 → Z3350. Its early axial trial had eaves Z2700 and ridge Z3200 → Z3700. The two early freestanding towers had trial maximum height Z7000. These **were explicitly trial values**. Their early chapel footprints (T3/T4/T5 and apse near X31474) do **not** register to the later axial R07 orange plan (apse near X34588.821). No user-accepted numerical companion chapel or individual tower height was recovered.

Other smaller/shallow satellite chapels: the **graduated-height/silhouette intent** is preserved, but their individual boss, eave, roof-ridge, entrance-head, and flyer dimensions remain **unresolved**. Record blank, not zero; no auto-interpolation.

## 4. How to use this in the next chat

1. Preserve the R07 orange plan geometry and three-chapel open buttress crown composition; this annex adds source height metadata **without recomputing the plan or creating geometry**.
2. Keep inner/middle AMB-I/M spring/boss/gallery datums protected. The old AMB-O schedule is *not* authoritative for the redesigned fourteen-vault third ring.
3. Carry forward the axial two-bay equal boss + roof design lock separately from the old progressive R03 and R06 trial elevations. Its springing still needs architectural bearing proof.
4. Preserve the explicit **not established** status for both companion chapels, the apse, all smaller chapels and freestanding buttress towers. Continue the whole-cathedral visual design with schematic envelopes until real design heights are selected.
5. Do not confuse 3D mesh technical validity, user-accepted design targets, authoritative source geometry, and structural adequacy. F5ZL-C remains missing; geometry and generators remain untouched.

## Source registry

See `SOURCE_HEIGHT_DOCUMENTS_REGISTER.csv` for full MR COMPUTER paths and read-only SHA-256 values. These original files were examined; **the master-source JSON files themselves are not embedded here as byte-identical copies**. The numeric tables here are sourced extracts, and the current height decision does not change saved approved geometry.
