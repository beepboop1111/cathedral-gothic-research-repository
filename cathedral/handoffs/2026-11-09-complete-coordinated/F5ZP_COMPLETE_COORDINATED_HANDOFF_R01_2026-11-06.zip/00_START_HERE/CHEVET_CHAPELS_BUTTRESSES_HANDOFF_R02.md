# F5ZP — Chevet, Eastern Chapels & Buttress Crown: Integrated Architectural Planning Handoff R01

**Prepared:** 2026-11-05/06 · **Status:** architectural planning recovery and experimental-development continuity, **NOT** a new approved model or generator.  
**Use with:** F5ZP R07 orange-overlay axial floor-plan handoff + recovered F5ZE whole-cathedral dimension schedule.  
**This handoff exists because the chapels, receiving masonry, flyers and outward chevet expansion were designed TOGETHER to shape the entire cathedral. Do not fragment them into unrelated local models.**

## 1 — Read first: two silhouettes of one enormous chevet

The principal visual idea is not simply to attach three chapels to a large cathedral. It is to resolve the transition from the exceptionally broad choir and chevet into a coordinated, layered Gothic east-end composition:

1. **Actual stone outline:** choir and curved ambulatory walls, the lower third-ambulatory approach, chapel bodies, progressively deeper eastern sanctuaries, and their individual apses.
2. **Wider open structural outline:** free-standing outward buttress towers, long flying arches (potentially two tiers in choir/chevet sectors) and open gaps framing the chapels. The towers and flights make the east end seem wider, suggesting additional aisles **without** enclosing them as solid new aisles.

The towers are an architectural foreground/background rhythm, **not** a wall closing the spaces between chapels. Retain views through to chapel windows, wall faces, roofs and principal high choir walls. Let the chapel masses project inside the buttress framework; do not allow every open recess to be filled with a detached pier. Transition gradually from the straight choir's buttress rhythm into the seven-sector fan, with the axial chapel and flanking towers as the visual culmination. This hierarchy is user-preferred conceptual architecture, not a frozen engineering design.

### Retained composition

- Three **major eastern chapels**: axial at 90°, broad companion chapels north and south. The axial chapel has **two elongated vaulted bays + polygonal apse**; each major companion has **one broad principal bay + polygonal apse**.
- The other chapels toward the straight choir become **progressively shallower and smaller**, maintaining the overall sweep. This is an ordering rule, **not** evidence of completed individual wall plans.
- One main entrance per chapel; the axial portal is the largest and most ceremonial and should remain **a single uninterrupted grand arch**, not be divided by a new ground-level center pier. The seven-major/fourteen-subsidiary vault rhythm is an independent geometric problem; its shared/offset bearings must be resolved without inventing an entrance-center pier.
- Companion chapel walls may share a **short inner common partition** at the frontage then diverge outward, opening generous recesses between apse bodies. Keep slender axial side-wall faces visible. The trial R03 junction demonstrates the concept for axial/NE locally but is not an approved shared pier.
- The **major freestanding flanking towers** should sit outside/beside the companion apses, visually framing the principal axial chapel rather than appearing on the central axis or crowding every inter-apse gap. Long upper and/or double-level flyers converge on genuinely justified high-level receiving locations; no authentic flyer landing has yet been validated.

**Architectural reading from a distant view:** nave and crossing establish the main longitudinal scale; straight choir progressively widens in perceived structure, the choir roof/high windows stay legible behind a denser lattice of flyers, and the chevet terminates in a deep axial sanctuary surrounded by companions and an open buttress crown. The expanded chevet should feel *earned by the existing cathedral*, not like a separate oversized building bolted to its eastern end.

## 2 — Authority and source hierarchy; what cannot change

- **Protect** F5ZK-C floor plan, documented 1:1 native coordinate frame, F5ZN-A dimension set and saved inner/middle ambulatory objects and original working generator. Protect V13 web geometry and Pass 6J pier-development records. Do not replace any generator or silently promote source-neutral prototypes.
- Chevet coordinates: center **(20213, 0)**, +X east, +Y north, Z up. Seven *outer identity* sector centers 30°, 50°, 70°, 90°, 110°, 130°, 150°, clockwise from north. The saved **inner/middle** bay centers are nonuniform and are NOT those same angles (14°, 40.5°, 65.75°, 90°, 114.25°, 139.5°, 166°). Do not shift actual 14 preserved vaults to a regular 20° ring.
- The **current plan-specific reference** is **R07**: four actual projected R06 approach ribs (red), original **unshifted** R03 chapel bays and polygonal apse (orange), the **600-unit threshold**, and saved 7+7 inner/middle plan. The older experimental R04 plan's chapel shift of **817.49** and replacement 2400-unit connecting bay are explicitly rejected for this active plan.
- The *original old outer ambulatory* has been discarded as a working constraint. A new **low third-layer** study follows **7 major bays / 14 subsidiary lower vault cells**; this is a current design program/experimental development, not a certified or locked 3D vault system. Discarded L01–L14 polygons, rejected center-receiver and paired-entrance assumptions, and obsolete upper-window placements must not be reimposed.
- Historical sources, procedural mesh validity, surface intersections, render aesthetics and a preliminary core are each **insufficient** to establish approved bearing dimensions, historical authenticity, or structural capacity.
- **F5ZL-C bearing/support schedule missing** (unresolved); exact metres/native unit likewise unresolved.

### R07 axial plan — authoritative for *this handoff's visual alignment*, not an approved join

| Element | Native XY | Status |
|---|---|---|
| Preserved middle A4 receiving chord | X25382.510; Y±1098.813 | Original F5ZN-A plan reference |
| Four-rib R06 approach | X25382.510 → X28000; outer width reaches Y±1250 | Actual projected R06 experiment; not certified junction |
| Entrance threshold | X28000–28600 (600 deep); Y±1250 | Retained R03 design |
| Axial chapel Bay 1 | X28600–31000 (2400); Y±1250 | Retained orange R03 original footprint |
| Axial chapel Bay 2 | X31000–33400 (2400); Y±1250 | Retained orange R03 original footprint |
| Axial polygonal apse | X33400 → X34588.821 | Original R03 polygonal termination |

**R07 intentionally defers all height analysis.** Do not alter the R07 footprint while exploring three-chapel massing or buttress alternatives.

## 3 — Whole-cathedral proportional control

The **F5ZE corrected full cathedral grid** is an earlier full-scale *source reference* accompanying this handoff, not permission to replace any later localized approved design. It helps control the huge east-end scale:

| Element | Native plan dimensions / chain |
|---|---|
| West façade → crossing west | X−40013 → −2933; ten nave bays |
| Crossing | 5866 × 5866, centered (0,0) |
| Nave N1–N10 depths | 3744, 3672, 3600×5, 3744, 3888, 4032 |
| Choir Q1–Q5 depths | 4032, 3744, 3456, 3168, 2880; chevet center X20213 |
| Transept arms | 4032 + 3744 per arm, extrema Y±10709 |
| Main nave bands R0–R3 | 2933, 4085, 5429, 6965 |
| Three lateral aisle thicknesses | 1152 / 1344 / 1536 |
| Chevet-specific inner/middle guide radii | 2933 / 4085 / 5285: different from the nave's R2=5429 datum |

The MP-02 full-plan atlas identifies a **29-unit junction discrepancy** and Study D's former 7–7–9 outer chapel/window program. Study D's historical outer ellipse/chapel envelope is **not the current selected R07 geometry**. It may supply context for overall massing only. The full choirs' real high-wall/roof mesh and exact flyer receiving courses are not established by this 2D atlas.

## 4 — Three-chapel position conflict: preserve A and B

| Issue | Candidate A: 70°/90°/110° | Candidate B: 50°/90°/130° |
|---|---|---|
| Design origin | Adjoining/grouped entrance study near axial chapel; short shared-wall logic | Wider-spaced companions to preserve the sequence W–Ch–W–Axial Ch–W–Ch–W |
| Interior external-recess character | Tighter grouping; useful for testing combined fronts | More open shoulder recesses, easier space for pier/flyer organization |
| R21 **surface-pair** overlap subset | 9 intersecting wall/cheek object pairs | 0 tested wall/cheek object pairs |
| Architectural assessment | Still an independent, valuable grouped-junction test | **R21 recommended for architectural review**, NOT formally selected/locked |
| Limits | 9 pairs are not proof of 9 bad solid-volume collisions | 0 pairs are not a whole-cathedral collision pass |

The latest user preference for **moderately open**, shared-wall-at-front, progressively widening recesses is conceptually compatible with testing B. It does **not** license reusing A's axial/NE shared-pier polygons at B's angles without re-registration. **Do not silently choose chapel stations** in the absence of the actual new plan checks and user architectural acceptance.

The long axial sanctuary and two companions are *one design system*; testing stations should always assess their mutual silhouette, roof separations, axial entrance visibility, choir glazing, buttress towers and flyer landing zones together.

## 5 — Buttresses: plan/visual system versus receiving masonry

### A. Exterior skeletal crown / large freestanding towers

The freestanding towers and long flying arches are a preferred **visual system**: broad open gaps, strong distant Gothic rhythm, apparent width beyond chapel masonry. The **Eastern_Chapels_R01** source made an early render with two trial towers centered at **(30500, +2600)** and **(30500, −2600)**, trial maximum height **7000**, two flyer tiers per tower and simplified roof profiles. Those numbers are **not approved**. Its T3/T4/T5 chalet-like trial chapel footprints and apex X31474 do not match the **later R07** axial apse X34588.821: the R01 towers **must be repositioned experimentally** in any future unified plan. Do not transplant the R01 source mesh into R07 and call it fitted.

### B. Local rib/chapel receiving masonry

Separate from the freestanding outer towers are **wall-engaged, outward T-derived, or detached receiver proposals** for the low third-ring vault ribs at the chapel mouths. R27, based on candidate B, tested 6 receiver stations at **40°, 60°, 80°, 100°, 120°, 140°**, six variants each:

- **Wall-engaged preferred for further research:** 12/12 affected trial rib sweep contacts, 6/6 source trial wall intersections, 0/9 sampled passage sections narrowed.
- **T-derived:** same limited 12/12 contact and 0/9 narrowing, but the extra crosshead masonry has **no demonstrated structural need**.
- **Detached:** 0/12 direct rib contacts, 0/6 source connector-wall intersections; therefore requires a **separately engineered transfer/flyer** before it can serve as a support.

All R27 proposed masonry is **experimental**. Its retained baseline minimum of **1923.324** native units is a *sampled trial passage width*, **not** a continuous guaranteed clear passage nor a code-clearance result. R28 did not close the architectural junction: no accepted load-bearing 3D contact, legitimate spring-cluster bonding, or validated roof/vestibule solution. This is crucial: **a visually freestanding exterior tower does not imply the doorway's local receiving pier should also be detached**. The inner wall-engaged support and outer flying-buttress receiving mass are distinct levels/functions and must be designed together.

### C. Historical buttress reference—not dimensional authority

Historical study **F5ZP Buttress Three-Chapel Historical Comparison R02** examined **81 plates** and preserved nine particularly relevant source images. Priorities:

- Viollet-le-Duc IV p309 fig. 15: apse/chapel radial relationship; IV p313 fig. 18 and I p97 fig. 60: receiving support and flyer-plan treatments; I p98 fig. 61: two-level flyers; IV p192: thrust/receiving geometry.
- Ungewitter I p219 Plate XXXVI: integrated wall-buttress plans/sections; II p87 LXXXIV and p93 LXXXV: flying-arch forms/sections; II p109 Plate LXXXVII: intermediate flyer piers and associated analysis.
- Moore/Parker/Brandon/Collings: comparative external proportions and silhouette (not calibrated to F5ZP dimensions).

Historical plates are *research evidence*. They cannot supply construction dimensions for the cathedral without traced curves, correspondence and calibration. No source has solved F5ZL-C or proven load paths.

## 6 — Early visual-proportion guidelines (PROPOSED ONLY)

These are recovered **design brainstorming ratios** with W = an illustrative typical aisle/chapel frontage width. They are *not geometry locks, exact offsets, or measured dimensions*: 

| Feature | Proposed visual proportion |
|---|---:|
| Axial chapel projection | approximately 1.5–2.0 W |
| Near-axial companion chapel projection | approximately 1.0–1.25 W |
| More lateral chapel projection | approximately 0.6–0.9 W |
| Clear view/open exterior recess between companion apses | approximately 0.5–0.75 of a companion-apse width |
| Buttress framework projection: choir sides | approximately 0.5–0.75 W |
| Buttress framework projection: chevet shoulders | approximately 0.75–1.0 W |
| Buttress framework projection: near-axial | approximately 1.0–1.25 W |
| Buttress framework projection: principal axial flanks | approximately 1.25–1.5 W |

These must be compared against current R07 apse geometry, actual straight-choir wall/window rhythms and realistic flyer span. Never directly convert ratios into loaded receiving masonry.

## 7 — Roof and vertical design: preserve the decision, defer its use in the active plan

The older R03 sanctuary experiment had progressively higher boss/crown values (AMB 3620; chapel bays 4150/4400; apse 4550), while the later **user-accepted separate axial chapel design lock R01** selected **two equal-height bay bosses Z4250**, shared spring Z1800 for *that study*, and **one continuous roof** (eaves Z4400, ridge Z5100 west → Z5250 east) over the two rectangular chapel bays. The locked *design intent* is a chapel roof **visually subordinate to the main choir**; the underlying choir roof was **not actually checked** against it. The apse roof, companion roofs, drainage, flyers and 3D receiving supports are **not locked** by this file.

**R07 user instruction:** leave the chapels with the orange overlay and ignore heights for the active plan handoff. This does not erase the separately recorded design-lock document. Keep its numbers in the archive, but **do not drive R07 plan regeneration or buttress siting from an unverified elevation**. If elevations are resumed later, explicitly reconcile R03 old varying crowns, the later two-bay roof lock and R06 raised approach experiment before building junction masonry.

## 8 — The verified vs unverified boundary

**Actually verified in recorded sources (within limited scope):**

- Original saved F5ZN-A and R21/V03 files were inventoried with hashes; saved generator retained; only experiments were modified.
- R21 B/A alternative render and local surface comparisons were run: A 9, B 0 cross-chapel *object-pair* intersections, limited subset.
- R21 trial 14 web bodies passed recorded mesh topology and 13/13 trial half-cell seam tests; **not approved real bearing integration**.
- Eastern_Chapels_R01 preliminary objects, saved trial roof/towers and whole-context render exist; source explicitly disclaims full exterior cathedral context.
- Axial_NE Entrance R03 local 2D junction showed **13/13** topology checks passing; shared P–Q **574.809326**, proposed pier **320 × 208**, axial clear chord **2200**, NE clear **2020.392**. Clear-chord nonintersections of ~43.42 are **not** masonry clearance.
- Axial Chapel R04 corrected 1184 web/roof polygon windings (33 shell meshes); its geometry unchanged from R03 and 16/16 technical QA passed; **not** acceptance of roof or chapel architecture.
- R27 proposed receivers passed its limited contact/9 section checks; **no physical structural load tests**.
- Current R07 four-rib approach + orange R03 chapel floor plan geometry was extracted from saved 1:1 paths, not redrawn from an image. **It is the active PLAN visual reference, not a full proposed masonry footprint.**

**Unresolved and mandatory gates:** exact F5ZL-C receiving-face/support schedule; identity and validation of the approved working inner/middle producer; selected companion chapel *azimuth* and exact independent entrance/jamb cuts; preservation of the open recesses under any flyer/receiver alternative; honest whole-building high choir/window/roof clearance; precise flyer inner/outer landings, drainage and thrust path; actual chapel-to-ambulatory passage; foundation/capacity; 1:1 native-to-physical metre conversion; details of smaller chapels and choir-to-chevet transition. **No structural or architectural M01 milestone approval.**

## 9 — Safe next work sequence

1. **Hold R07 axial footprint and F5ZE whole-cathedral station chain as separate current plan references.** Use full building, not a cropped east-end only, in matched plan/elevation review. Avoid silently conflating the prototype R01 outer-massing and present R07 axial apse positions.
2. **Position B's companion chapels against the actual R07 axial body and protected F5ZN-A middle ring, on a distinct experimental layer.** Compare grouped A for shared entrance logic; assess recess widths, open sky angles, and choir windows. Preserve *both* candidates until approval.
3. **Coordinate an exterior freestanding tower/flyer reservation envelope** in plan and a conceptual silhouette diagram before making individual masonry piers. Gradually expand from choir shoulders to axial flanks; retain transparent recesses, axial roof visibility and an open skeleton. Verify actual external landing centers from trial models and source, don't inherit old (30500, ±2600) as fact.
4. **Test local inward wall-engaged receiver choices** from R27, then T-derived and detached as separate alternatives, against real ribs/portal openings; do not assume external freestanding towers can take inner portal rib loads directly. Make width/passage tests independent for all entrances.
5. **Only after the plan is coherent**, revisit section/elevations, actual high-choir receiving masonry, double-tier flyer geometry, roof/glazing overlap, drainage and structural-load plausibility. Preserve approved arches and generators; keep F5ZL-C unresolved if no source is found.
6. Deliver paired all-cathedral plan views, east-end side/axial viewpoints and inside/outside views, with separate geometric/architectural/historical/structural QA. Approval required to choose A vs B or change a protected baseline.

## 10 — Checkpoints and visual evidence bundled

See `SOURCE_REGISTER.csv`, `VARIANT_DECISION_MATRIX.csv`, `DIMENSION_REGISTER.csv`, `CONFLICTS_AND_GATES.md`. The ZIP includes source images showing the historic R20 chapel choice, selected R21 B massing, R07 orange chapel plan, R21 interface checks and F5ZE full plan numeric schedule. Source snapshots are **copies**, not updated authorities. MR COMPUTER retains the editable full Blender packages at original paths and a companion archive with additional read-only documents and preview images.

**Continuing instruction:** “Continue Cathedral F5ZP *three-chapel + buttress crown* from this handoff and R07. Preserve the two-outline exterior composition, the original unshifted axial chapel and 600-unit threshold, the broader companion-chapel/masonry/flyer program, and candidate B vs A distinction. No outer-ring restoration, no silent generator edits, no structural approval claims. Develop coordinated full-cathedral plan comparisons and measurable 2D registration before 3D remodeling.”


---

## 10 — Recovered chevet / chapel heights (R02 HEIGHT ANNEX)

The previously plan-only R07 orange overlay **remains plan-only**. This added schedule restores the separately evidenced vertical design references without modifying geometry, reviving the discarded outer ring, or asserting approval for the companion chapels.

| Scope | Height | Evidence status |
|---|---|---|
| Protected AMB-I + AMB-M low spring | Z3000 | F5ZK-C / F5ZN-A |
| Protected AMB-I + AMB-M bosses | Z4296 | F5ZK-C / F5ZN-A |
| Upper web / gallery soffit / gallery floor | Z4394 / 4425 / 4521 | Recorded chevet reference |
| Axial two rectangular chapel bosses | Z4250 both | Explicitly user-accepted separate axial design lock |
| Axial two-bay continuous roof | eaves Z4400; ridge west Z5100, east Z5250 | Explicitly user-accepted design targets |
| Old/new third lower ring | NO APPROVED NUMERIC HEIGHT | Discarded earlier ring; new 14-cell third-ring study dimensionless |
| NE + SE chapels, apse roof, smaller chapels, outer towers | NO APPROVED NUMERIC HEIGHT | Only isolated early trial values |

The old R03 progressive vault crowns and early freestanding-tower/companion-roof heights are **EXPERIMENTAL** and must remain separate. Source hashes, the 14-bay apex schedule, conflicts and all older trial heights are in [`06_height_recovery/HEIGHTS_RECOVERY_AND_AUTHORITY.md`](06_height_recovery/HEIGHTS_RECOVERY_AND_AUTHORITY.md) and CSV schedules in that folder. Missing F5ZL-C remains unresolved.
