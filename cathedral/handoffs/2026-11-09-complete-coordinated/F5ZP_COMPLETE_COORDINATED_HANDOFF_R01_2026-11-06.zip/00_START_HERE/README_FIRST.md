# F5ZP — COMPLETE COORDINATED CATHEDRAL HANDOFF — R01 (2026-11-06)

## Open these files first
1. `00_START_HERE/CURRENT_R07_ORANGE_CHAPEL_FLOOR_PLAN.png` — current axial R06 rib XY projection and **original R03 orange chapel arrangement**, not the rejected R04 relocation.
2. `00_START_HERE/CURRENT_R07_HANDOFF.md` — current XY plan basis, 600-unit threshold, limitations.
3. `00_START_HERE/CHEVET_CHAPELS_BUTTRESSES_HANDOFF_R02.md` — whole eastern chapels + freestanding buttress crown design intent and alternative comparisons.
4. `00_START_HERE/HEIGHTS_AUTHORITY_AUDIT.md` and `CHEVET_HEIGHT_SCHEDULE.csv` — design-lock vs source-reference vs experimental heights.
5. `00_START_HERE/F5ZE_FULL_CATHEDRAL_DIMENSIONS.csv` — complete nave/crossing/choir plan chain.

## What is included
This ZIP incorporates the **original verified ChatGPT-accessible F5ZP ZIP exports** with their contents intact, covering R07 plan, F5ZE dimensions, R01/R02 chevet-chapel-buttress design handoffs, M01 R15-R26 studies, older R11-R14 comparisons, and R02-R11 third-ambulatory experimental research. Each nested ZIP has passed its own test; they are not flattened, merged or silently revised. See `MANIFEST_SHA256.json` for file hashes.

## Source authority — NEVER automatically upgrade experimental files
- Protected or approved source context: F5ZK-C chevet footprint, F5ZN-A dimensional references, established 14 inner/middle ambulatory vaults, recorded Pass 6J, 1:1 native scale. No actual approved source geometry is modified by this package.
- Current experimental plan context: R07 orange axial chapel with R06 approach rib plan, chapel bays X28600–31000 and X31000–33400, 600-unit threshold X28000–28600, polygonal apse beyond X33400. No R04 817.49-unit chapel translation.
- Chevet chapel / buttress design objective: three major eastern chapels considered **together**, graduated volumes and expanded Gothic flying buttress/pier skyline framing enormous chevet. Compare R21 A (70°/90°/110°) and B (50°/90°/130°), B only a recommended *candidate*, never user-approved by inference. Local wall-engaged receivers from R27 are geometric proposals, not structurally proved. Older freestanding tower/flyer trial geometry belongs to a different setout; don't move it into current R07 blindly.
- Protected/documented inner/middle chevet height reference: spring Z3000, boss Z4296, web reference Z4394, gallery soffit Z4425, gallery floor Z4521. The later recorded axial two-bay **design lock**: boss Z4250 each, eaves Z4400, roof ridge Z5100–5250; other R03 and companion-chapel heights are experiments, not overrides.
- Third/outer ambulatory has a revised 14-low-vault design direction, not a finished approved vertical schedule. Older F5ZK-C 7-cell outer vertical dimensions are historical source values only; don't falsely promote.
- F5ZL-C full physical support schedule still unresolved. No verified physical metres-per-native-unit conversion, full roof/gallery coordination, historical correctness or structural capacity is supplied.

## Additional source-model archive on MR COMPUTER (not embedded in this portable ZIP)
`~/Desktop/F5ZP_CHEVET_CHAPEL_BUTTRESS_CROWN_SOURCE_ARCHIVE_R01.zip`
The 44-file original-source review archive is on the user's MR COMPUTER: Eastern Chapels R01 original plans/QA, R03 entrance junction, original R03 chapel design lock, R21 A/B studies, R27 wall-engaged receiver tests, R28 axial junction diagnostics, historical Viollet-le-Duc/Ungewitter contact sheet, current R07 plan and full F5ZE atlas. This separate remote archive has previously passed ZIP integrity testing. The active execution container does not have the bytes of that remote archive, so it is **not** falsely represented as included in this download.

Additional original source/checkpoint (MR COMPUTER): `~/Desktop/F5ZP_R07_FULL_CATHEDRAL_PLAN_ADDENDUM_R01.zip` includes the eight-page MP-02 atlas and corrected F5ZE original JSONs. Available portable F5ZE dimension CSV/JSON are included in the current ZIP.

## Validation and preservation
- No source files modified; only a new aggregate ZIP and manifest are created.
- SHA256 and size for each constituent file in `MANIFEST_SHA256.json`.
- Every nested ZIP archive passed zip integrity check before packaging.
- Final ZIP archive is validated for integrity.
- Original objects, V13 webs, approved generators, historical plates and Pass 6J are not promoted, replaced or rebuilt.

## Next modeling workflow
Recover live master checkpoint and compare current native Blender geometry before altering any junction. Work experimentally on copies only. Develop coordinated **whole-cathedral** R07 three-chapel + buttress-crown placement comparisons, and maintain a clear approval-gate matrix for companion chapel station selection, corridor clearances, flyer receiver contacts and silhouette. Do not infer an approved option from report recommendations.
